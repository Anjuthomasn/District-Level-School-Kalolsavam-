<?php
include 'connection.php';
session_start();
if (!(isset($_SESSION['l_id']))) {
    header('location:index.php');
}

$id = $_SESSION['l_id'];
?>

<?php
if (isset($_POST['submit1'])) {
    $email = $_POST["email"];
    $phone = $_POST["phone"];
    //$sqls="UPDATE `school_info` SET `email`='$email' AND `phone`='$phone' where l_id=$id";
    $s = "UPDATE school_info set email='$email' AND `phone`='$phone' where l_id=20";
    $query = mysqli_query($con, $s);
}


?>


<!DOCTYPE html>
<html>
    <head>
        <title>School Kalolsavam</title>

        <!-- meta -->
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- css -->
        <link rel="stylesheet" href="users/css/bootstrap.min.css">
        <link rel="stylesheet" href="users/css/ionicons.min.css">
        <link rel="stylesheet" href="users/css/font-awesome.min.css">
        <link rel="stylesheet" href="users/css/owl.carousel.css">
        <link rel="stylesheet" href="users/css/owl.theme.css">
        <link rel="stylesheet" href="users/css/owl.transitions.css">
        <link rel="stylesheet" href="users/css/animate.css">
        <link rel="stylesheet" href="users/css/custom.css">

        <!-- js -->
        <script src="users/js/jquery.min.js"></script>
        <script src="users/js/bootstrap.min.js"></script>
        <script src="users/js/owl.carousel.min.js"></script>
        <script src="users/js/isotope.pkgd.min.js"></script>
        <script src="users/js/script.js"></script>
        <script src="users/js/wow.min.js"></script>
        <script src="users/js/jquery.actual.min.js"></script>

        <link rel="stylesheet" href="css2/style4.css">

               <style>
            table {
                border-collapse: collapse;
                width:50%;
            }

            th, td {
                text-align: center;
                padding: 8px;
                font-size: 14px;
                font-weight: bold;
            }

            tr:nth-child(even){background-color: #f2f2f2}

            th {
                color: black;
                font-size: 16px;
                font-family: helvetica;
                font-weight: bolder;
            }
        </style>



    </head>

    <body>
        <div id="wrapper">
            <div id="overlay-1">
                <section id= "navigation">
                    <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
                        <div class="container-fluid">
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                                    <span class="ion-navicon"></span>
                                </button>
                                <a class="navbar-brand" href="#">School Kalolsavam </a>
                            </div>
                            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                <ul class="nav navbar-nav navbar-right">
                                    <li><a href="#starting">HOME</a></li>
                                    <li><a href="#profile">ACCOUNT INFORMETION</a></li>
                                    <li><a href="">STUDENT LIST OF PROGRAM</a></li>
                                    <li><a href="">RESULT</a></li>
                                    <li><a href="logout.php">LOGOUT</a></li>
                                </ul>
                            </div>	<!-- collapse navbar-collapse -->
                        </div>	<!-- container-fluid -->
                    </nav>	<!-- navbar -->
                </section>	<!-- #navigation -->
               
                <div id="bottom" class="bottom text-center">
                    <a href="#about"><i class="ion-ios7-arrow-down"></i></a>
                </div>
            </div><!-- overlay-1 -->
        </div>	<!-- wrapper -->		

        <!-- About Us -->
        <section id="profile">
            <div class="container">
                <div class="row text-center" id="heading">
                    <div class="col-md-6 col-md-offset-3 wow animated zoomInDown" id="heading-text">
                        <h3>EDIT DETAILS</h3>
                        <hr class="full">
                        <br/>
                    </div>
                </div>	<!-- row -->
                <div class="row about-us-text">
                    <div class="col-md-8 col-md-offset-2">
                        <p class="text-center">



<?php
$query = mysqli_query($con,"SELECT login.*,school_info.* FROM login,school_info WHERE login.l_id=$id AND school_info.l_id=$id");
while ($row = mysqli_fetch_array($query)) {
    ?><form action="#" method="post">
        
                            <center>                                 
                                <table border="16%"  width="100%">

                                    <label style="display:none ; color:red"  id="aa"></label>

                                   
                                    <tr>
                                        <td>EMAIL </td>
                                         <td><input class="txt" type="text" name="email" id="email" value="<?php echo $row['email']; ?>"  required</td>
                              </tr>
                                    <tr>
                                        <td>MOBILE </td>
                                       <td><input class="txt" type="text" name="phone" id="phone" value="<?php echo $row['phone']; ?>"  required</td>
                                 </tr>
                                 <tr>
                                        <td>Edit</td>
                                        <td><input type="submit" name="submit1" class="btn btn-inverse large" value="UPDATE"></td>
                                    </tr>
                                 



    <?php
}
?>

                                    


                            </table>

                            <br>  <a href="#change">Change Password</a>  </center>



                        </p>

                        <br><br>  <br><br>  <br><br>  <br><br>  <br><br>  <br><br>
                    </div>

                </div>
            </div>>
        </section>

        <!-- row -->
        <br><br>  <br><br><br><br>  <br><br>
         








                        <br><br>  <br><br>  <br><br>  <br><br>  <br><br>  <br><br>

                    </div>

                </div>
            </div>>
        </section><!-- row -->
       
        

                        <br><br>  <br><br>  <br><br>  <br><br>  <br><br>  <br><br>


        <br><br>  <br><br>
        <!-- footer -->
        <section id= "footer" class= "main-footer">
            <div class= "row">
                <div class= "logo text-center">
                    <h1>School Kalolsavam</h1>
                </div>
            </div>
            <div class= "row">
                <div class= "copyright text-center">
                </div>
            </div>
        </section><!-- footer -->

        <!-- js -->
        <script>
            $(document).ready(function () {
                $("#client-speech").owlCarousel({
                    autoPlay: 3000,
                    navigation: false, // Show next and prev buttons
                    slideSpeed: 700,
                    paginationSpeed: 1000,
                    singleItem: true
                });
            });
        </script>
        <script>
            new WOW().init();
        </script>
        <script>
            $(function () {
                // init Isotope
                var $container = $('.isotope').isotope
                        ({
                            itemSelector: '.element-item',
                            layoutMode: 'fitRows'
                        });


                // bind filter button click
                $('#filters').on('click', 'button', function ()
                {
                    var filterValue = $(this).attr('data-filter');
                    // use filterFn if matches value
                    $container.isotope({filter: filterValue});
                });

                // change is-checked class on buttons
                $('.button-group').each(function (i, buttonGroup)
                {
                    var $buttonGroup = $(buttonGroup);
                    $buttonGroup.on('click', 'button', function ()
                    {
                        $buttonGroup.find('.is-checked').removeClass('is-checked');
                        $(this).addClass('is-checked');
                    });
                });

            });
        </script>
        <script src="users/js/jquery-ui-1.10.3.min.js"></script>
        <script src="users/js/jquery.knob.js"></script>
        <script src="users/js/daterangepicker.js"></script>
        <script src="users/js/bootstrap3-wysihtml5.all.min.js"></script>
        <script src="users/js/dashboard.js"></script>


    </body>
</html>
