<?php
include 'connection.php';
//session_start();
if(isset($_POST['submits']))
    {
       // $targetFilePath = $targetDir . $fileName;
        $username=$_POST['names'];
        $studentname=strtoupper($_POST['sname']);
        $email= $_POST['email'];
        $phone=$_POST['phone'];
        $password=$_POST['password1'];
        $p=md5($password);
        $subdistrict_id=$_POST['subdistrict'];
        $school_id=$_POST['school'];
        $gender=strtoupper($_POST['gender']);
        $section=$_POST['section'];
        $image=$_POST['image'];
       // $file = $_FILES['image'];
        //$nams = $file['name'];
        //$path = "profileimage/" .$nams;
       // move_uploaded_file($file['tmp_name'], $path);
         $un="SELECT `username` FROM `kalolsavam_tb1_login` WHERE `username`='$username'";
         $r1=mysqli_query($con,$un);
         $row=mysqli_fetch_array($r1);
         $rr1=$row["username"];
         if($rr1==$username )
         {
             echo"<script>alert('Sorry  username is already in use..Please choose a different one..! ');</script>)";
         
             
         }
     
     else {
            $sql1="INSERT INTO `kalolsavam_tb1_login`(`username`, `password`,`role`,`status`) VALUES ('$username','$p',4,1)";
            $result1=mysqli_query($con,$sql1);
       
           $l_id="SELECT `l_id` FROM `kalolsavam_tb1_login` WHERE `username`='$username'";
            $result2=mysqli_query($con,$l_id);
            while($n=mysqli_fetch_array($result2))
            {
                
                 $a=$n["l_id"];
                 $sql="INSERT INTO `kalolsavam_tb2_user`(`l_id`,`email`,`phone`) VALUES($a,'$email','$phone')";
                 $result3=mysqli_query($con,$sql);
            }
            $user_id="SELECT `user_id`,`l_id` FROM `kalolsavam_tb2_user` WHERE `l_id`=$a";
            $result4=mysqli_query($con,$user_id);
            while($ids=mysqli_fetch_array($result4))
            {
                $uid=$ids["user_id"];
                $insert="INSERT INTO `kalolsavam_tb7_studentinfo`(`l_id`,`user_id`,`sclist_id`,`name`,`section`,`gender`,`image`) VALUES($a,$uid,$school_id,'$studentname','$section','$gender','$image')";
              
                $result5=mysqli_query($con,$insert);
              //  move_uploaded_file($_FILES["file"]["tmp_name"], $targetFilePath);
              
            }
            if($result5)
                    {
                        
                        
                         echo"<script> alert('Registration Successful,Please Login')
                         window.location.href = 'index.php';</script>";
                        
                    }
     }
//echo"<script>alert('Data Entered Successfully');</script>)";
           

        
        

        }

?>

<?php
include 'component/header.php';
?>

<!--  <script src="validation/jquery.min.js"> </script>
 <script src="validation/oh-autoval.js"></script>
 -->
 <br><br>
<div class="container register">
<div class="row">
<div class="col-md-3 register-left">
<img src="https://image.ibb.co/n7oTvU/logo_white.png" alt=""/>
<h3>Welcome</h3><br><br>
 <a  href="index.php" >LOGIN</a>
   <!--  <input type="submit" name="" value="Login"/><br/>
  --></div>
<div class="col-md-9 register-right">
<ul class="nav nav-tabs nav-justified" id="myTab" role="tablist">
</ul>
 <div class="tab-content" id="myTabContent">
<div class="tab-pane fade show active"  role="tabpanel" aria-labelledby="home-tab">
 <h3 class="register-heading">Student Registration</h3>

 <form method="post" name="studentreg" name="myform" onsubmit="return" class="oh-autoval-form"  >
    <div class="row register-form">
      <div class="col-md-6">
    <div class="form-group"> 
        <input type="text" class="form-control" placeholder="USER NAME *" name="names" id="names" onkeypress="return onlyAlphabets(event,this);" onchange="sname();" required />
         <label style="display:none ; color:red"  id="sname_l"></label>
    </div>
     <div class="form-group">
  <input type="password" class="form-control" placeholder="Password *" name="password1" id="password1" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters"  onchange="CheckPassword();"  required />
   <label style="display:none ; color:red"  id="pswrd_l"></label> 
     </div>
<div class="form-group">
  <input type="password" class="form-control"  placeholder="CONFIRM PASSWORD *" id="cnpwd"  onchange="pwdChek()" required />
 </div>
           <div class="form-group"> 
        <input type="text" class="form-control" placeholder="STUDENT NAME *" name="sname" id="sname"  onchange="sname2();" required />
         <label style="display:none ; color:red"  id="sname_2"></label>
    </div>
 <div class="form-group">
  <div class="maxl">
 <label class="radio inline"> 
  <input type="radio" name="gender" value="male" checked>
    <span> Male </span> 
     </label>
     <label class="radio inline"> 
     <input type="radio" name="gender" value="female">
         <span>Female </span> 
           </label>
      </div>
        </div>
           <div class="form-group">
         <select class="form-control" name="section" id="section">
         <option class="hidden"  selected disabled>Select your Section
        </option>
          <option>LP</option>
         <option>UP</option>
           <option>HS</option>
             <option>HSS</option>
           </select>
       </div>
    <img id="myImg" src="#" alt="your image"  height="120" width="120" />
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="email" class="form-control" placeholder="Your Email *" name="email"  id="email" onchange="return checkEmail();"  av-message="Error message" required />
                                        <label style="display:none ; color:red"  id="eml"></label>
                                        </div>
                                        <div class="form-group">
                                            <input type="text" minlength="10" maxlength="10" name="phone"  id="mobile" onchange="mob();" class="form-control" placeholder="Your Phone *" required />
                                        <label style="display:none ; color:red"  id="mobile_l"></label>
                                        </div>
                                        <!-- <div class="form-group">
                                            <select class="form-control">
                                                <option class="hidden"  selected disabled>Please select your Sequrity Question</option>
                                                <option>What is your Birthdate?</option>
                                                <option>What is Your old Phone Number</option>
                                                <option>What is your Pet Name?</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="Enter Your Answer *" value="" />
                                        </div> -->
 
                   <div class="form-group">
                       <select class="form-control" name="subdistrict" id="subdistrict" >
                           
          <option value=0>SELECT SUBDISTRICT </option>
        <?php
         $con = mysqli_connect("localhost", "root", "", "kalolsavam");
                                    if (!$con) {
                                        echo "Could not connect..Try again";
                                    } else {
                                        $sdselect = "SELECT * FROM `kalolsavm_tb4_subdistrict` WHERE sts=1";
                                        $sdresult = mysqli_query($con, $sdselect);
                                        //echo "";
                                        while ($sdrow = mysqli_fetch_array($sdresult)) {
                                            $stname = $sdrow['subdistrict'];
                                            $sid = $sdrow['sdt_id'];
                                            echo "<option value='$sid'>$stname</option>";
                                        }
                                    }
                                    mysqli_close($con);
                                    ?>
              </select>
                       </div>
                                                        
         <div class="form-group">
         <select class="form-control" name="school" id="school" >
       </option>
          <option>SELECT SCHOOL</option>
           </select>
       </div>
                        <script> 
      
                  
                   $("#subdistrict").on("change", function () {
                        $("#school").html("");
                        $dstate = $("#subdistrict").val();

                        // find courselevels
                        $.ajax({
                            url: 'data/data.php',
                            method: 'POST',
                            data: {'subdistrict': $dstate, "sts":"1"},
                            success: function (data)
                            {
                                // console.log(data);
                                $("#school").html(data);
                            }
                        });
                    });
                      function validate()
      {
            if (document.getElementById("subdistrict").selectedValue == 'SELECT SUBDISTRICT' )
            {
                 alert("Select Subdistrict");
            }
             else 
            
            if (document.getElementById("school").selectedIndex == 0){
             alert("Select School");
            }
        if (document.getElementById("section").selectedIndex == 0){
             alert("Select Section");
            }
            
    
       }
                </script>

 <div class="form-group">
     <LABEL>Upload Image</LABEL><input type="file"  accept="image/jpeg, image/png" onchange="readURL(this);" name="image" class="av-image" av-message="addimage" required />  
 </div>

 <input type="submit" class="btnRegister"  value="Register" id="submit" name="submits" onclick="javascript:validate();"/>
    </div>

   </div>
  </div>
   </form>
  <!--validation for image-->
 <script type="text/javascript">
                                $(function () {
    $(":file").change(function () {
        if (this.files && this.files[0]) {
            var reader = new FileReader();
            reader.onload = imageIsLoaded;
            reader.readAsDataURL(this.files[0]);
        }
    });
});
   function validate(){
    if (document.getElementById("subdistrict").selectedIndex == 0){
       alert("Select Subdistrict");
       
    }
    else {
       alert(document.getElementById("subdistrict").options[document.getElementById("subdistrict").selectedIndex].value);
    }
}
function imageIsLoaded(e) {
    $('#myImg').attr('src', e.target.result);
};
function onlyAlphabets(e, t) {
            try {
                if (window.event) {
                    var charCode = window.event.keyCode;
                }
                else if (e) {
                    var charCode = e.which;
                }
                else { return true; }
                if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123))
                    return true;
                else
                    return false;
            }
            catch (err) {
                alert(err.Description);
            }
        }
function mob()
	{
            var val = document.getElementById('mobile').value;
	    if (!val.match(/^[7-9][0-9]{9,9}$/))
	    {
		$("#mobile_l").html('Only Numbers are allowed and must contain 10 number..!').fadeIn().delay(3000).fadeOut();
		document.getElementById('mobile').value = "";
		mobile.focus();
	        return false;
	    }
	    return true;
	}
	function checkEmail()
	 {
             
             var email = document.getElementById('email');
   		 var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

   		 if (!filter.test(email.value)) {
                     email.value="";
                     
    		$("#eml").html('Please provide a valid email address').fadeIn().delay(3000).fadeOut();
                email.focus();
               // document.getElementById("email").addEventListener("focusin",checkemail());
   		 return false;
             
 
     		
	 }
    }
	function userName()
	{
	     var val = document.getElementById('username').value;
	    if (!val.match(/^[A-Za-z][A-Za-z""]{3,}$/)) 
	    {	
		$("#uname_l").html(' Only Alphabets allowed with minimum 4 characters without spacing').fadeIn().delay(3000).fadeOut();
		document.getElementById('username').value = "";
		username.focus();
	
    	return true;
		}
                
                if(document.myform.username.value.search(username)==-1)
                 {
                     	$("#uname_l").html(' Invalid Character Entered').fadeIn().delay(3000).fadeOut();
                      document.getElementById('username').value = "";
		username.focus();
                      
                      return false;
                    }
                           var x = document.getElementById('username').value;
                if(document.myform.username.value.count(username)<=11)
		{
                   	$("#uname_l").html('Name Must Not Exceed 11 Characters').fadeIn().delay(3000).fadeOut();
                      document.getElementById('username').value = "";
		username.focus();
                    
                   
                    return false;
                }
                
        }
        	function sname()
	{
	       var val = document.getElementById('names').value;
	    if (!val.match(/^[A-Za-z][A-Za-z""]{3,}$/)) 
	    {	
		$("#sname_l").html(' Only Alphabets allowed with minimum 4 characters without spacing').fadeIn().delay(3000).fadeOut();
		document.getElementById('name').value = "";
		sname.focus();
	
    	return true;
		}
                
                if(document.myform.username.value.search(sname)==-1)
                 {
                     	$("#sname_l").html(' Invalid Character Entered').fadeIn().delay(3000).fadeOut();
                      document.getElementById('sname').value = "";
		sname.focus();
                      
                      return false;
                    }
                           var x = document.getElementById('username').value;
                if(document.myform.username.value.count(username)<=11)
		{
                   	$("#sname_l").html('Name Must Not Exceed 11 Characters').fadeIn().delay(3000).fadeOut();
                      document.getElementById('sname').value = "";
		sname.focus();
                    
                   
                    return false;
                
		}
                
                if(document.myform.snames.value.search(sname)==-1)
                 {
                     	$("#sname_l").html(' Invalid Character Entered').fadeIn().delay(3000).fadeOut();
                      document.getElementById('sname').value = "";
		sname.focus();
                      
                      return false;
                    }
        }
 	function sname2()
	{
	       var val = document.getElementById('sname').value;
	    if (!val.match(/^[a-zA-Z ]{4,25}$/)) 
	    {	
		$("#sname_2").html(' Only Alphabets allowed with minimum 4 characters ').fadeIn().delay(3000).fadeOut();
		document.getElementById('name').value = "";
                sname.value="";
		sname.focus();
	
    	return true;
		}
                
                if(document.myform.username.value.search(sname)==-1)
                 {
                     	$("#sname_2").html(' Invalid Character Entered').fadeIn().delay(3000).fadeOut();
                      document.getElementById('sname').value = "";
                      sname.value="";
		sname.focus();
                      
                      return false;
                    }
                           var x = document.getElementById('username').value;
                if(document.myform.username.value.count(username)<=11)
		{
                   	$("#sname_2").html('Name Must Not Exceed 11 Characters').fadeIn().delay(3000).fadeOut();
                      document.getElementById('sname').value = "";
                      sname.value="";
		sname.focus();
                    
                   
                    return false;
                
		}
                
                if(document.myform.snames.value.search(sname)==-1)
                 {
                     	$("#sname_2").html(' Invalid Character Entered').fadeIn().delay(3000).fadeOut();
                      document.getElementById('sname').value = "";
		sname.focus();
                      
                      return false;
                    }
        }
	function CheckPassword()
	{


		var p=document.getElementById('password1').value;
		var passw=  /^[A-Za-z]\w{7,14}$/;
                var error = "";
                 var illegalChars = /[\W_]/; // allow only letters and numbers
 
                     if (p == "") {
                              $("#pswrd_l").html('You didnt enter a password.').fadeIn().delay(3000).fadeOut();
                               
                                 password1.value="";
                                 password1.focus();
                                    return false;
                        }
                        else if ((p.length < 7) || (p.value.length > 15)&& (p.search(/[a-zA-Z]+/)==-1) || (p.search(/[0-9]+/)==-1)) {
        
                              $("#pswrd_l").html('The password is the wrong length,minimum 8  and 15 charecter and The password must contain at least one numeral ').fadeIn().delay(3000).fadeOut();
           
         password1.value="";
                                 password1.focus();
      
        return false;
 
    } else if ( (p.search(/[a-zA-Z]+/)==-1) || (p.search(/[0-9]+/)==-1) ) {
        
                              $("#pswrd_l").html('The password must contain at least one numeral').fadeIn().delay(3000).fadeOut();
        
         password1.value="";
         password1.focus();
        return false;
 
    } else {
        p.style.background = 'White';
    }
   return true;
	}
	
		function pwdChek() 
		{														
			if(document.getElementById("password1").value == document.getElementById("cnpwd").value)
			{	
				return true;										
			}
			else
			{
                              $("#pswrd_2").html('***Password Mismatch***').fadeIn().delay(3000).fadeOut();
        
				
                                cnpwd.value="";
                                cnpwd.focus();
			  	document.getElementById("cnpwd").focus();
					return false;
			}
		}
			                  

	
        
		


</script>
 </div>
</div>
</div>

 </div>
 <?php
include 'component/footer.php';
?>