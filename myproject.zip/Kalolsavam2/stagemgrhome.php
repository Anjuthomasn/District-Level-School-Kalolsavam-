<?php
include 'connection.php';
include("dbconnection.php");
$db = new DbConnection;
session_start();
if (!(isset($_SESSION['l_id']))) {
    header('location:index.php');
}

$id = $_SESSION['l_id'];
?>

<?php
if (isset($_POST['submit1'])) {
    $email = $_POST["email"];
    $username = $_POST["username"];
    $phone = $_POST["phone"];
    //$sqls="UPDATE `school_info` SET `email`='$email' AND `phone`='$phone' where l_id=$id";
    $s = "UPDATE school_info set email='$email' AND `phone`='$phone' where l_id=20";
    $query = mysqli_query($con, $s);
}

if (isset($_POST['register'])) {

    $password = $_POST["password"];
    $p = md5($_POST["password"]);
    $newpassword = md5($_POST["newpassword"]);
    $sql = "select * from login where l_id='$id' and password='$password' or password='$p'";
    $exe = ($db->executeQuery($sql));
    $no = mysqli_num_rows($exe);
    if ($no > 0) {
        $sqll = "update login set password='$newpassword' where l_id='$id'";
        $up = ($db->executeNonQuery($sqll));
        if ($up) {
            ?>
            <script> alert("Password changed succesfully");</script>
            <?php
        } else {
            ?>
            <script> alert("Error!!");</script>
            <?php
        }
    } else {
        ?>
        <script> alert("Current password is wrong");</script>
        <?php
    }
}
?>


<!DOCTYPE html>
<html>
    <head>
        <title>School Kalolsavam</title>

        <!-- meta -->
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- css -->
        <link rel="stylesheet" href="users/css/bootstrap.min.css">
        <link rel="stylesheet" href="users/css/ionicons.min.css">
        <link rel="stylesheet" href="users/css/font-awesome.min.css">
        <link rel="stylesheet" href="users/css/owl.carousel.css">
        <link rel="stylesheet" href="users/css/owl.theme.css">
        <link rel="stylesheet" href="users/css/owl.transitions.css">
        <link rel="stylesheet" href="users/css/animate.css">
        <link rel="stylesheet" href="users/css/custom.css">

        <!-- js -->
        <script src="users/js/jquery.min.js"></script>
        <script src="users/js/bootstrap.min.js"></script>
        <script src="users/js/owl.carousel.min.js"></script>
        <script src="users/js/isotope.pkgd.min.js"></script>
        <script src="users/js/script.js"></script>
        <script src="users/js/wow.min.js"></script>
        <script src="users/js/jquery.actual.min.js"></script>

        <link rel="stylesheet" href="css2/style4.css">

               <style>
            table {
                border-collapse: collapse;
                width:50%;
            }

            th, td {
                text-align: center;
                padding: 8px;
                font-size: 14px;
                font-weight: bold;
            }

            tr:nth-child(even){background-color: #f2f2f2}

            th {
                color: black;
                font-size: 16px;
                font-family: helvetica;
                font-weight: bolder;
            }
        </style>



    </head>

    <body>
        <div id="wrapper">
            <div id="overlay-1">
                <section id= "navigation">
                    <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
                        <div class="container-fluid">
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                                    <span class="ion-navicon"></span>
                                </button>
                                <a class="navbar-brand" href="#">School Kalolsavam </a>
                            </div>
                            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                <ul class="nav navbar-nav navbar-right">
                                    <li><a href="#starting">HOME</a></li>
                                    <li><a href="#profile">ACCOUNT INFORMETION</a></li>
                                   <li><a href="logout.php">LOGOUT</a></li>
                                </ul>
                            </div>	<!-- collapse navbar-collapse -->
                        </div>	<!-- container-fluid -->
                    </nav>	<!-- navbar -->
                </section>	<!-- #navigation -->
                <section id="starting">
                    <div class="text-center starting-text">
                        <h1 class="rene">WELCOME</h1>
                        <h2></h2>
                    </div>
                </section>
                <div id="bottom" class="bottom text-center">
                    <a href="#about"><i class="ion-ios7-arrow-down"></i></a>
                </div>
            </div><!-- overlay-1 -->
        </div>	<!-- wrapper -->		

        <!-- About Us -->
        <section id="profile">
            <div class="container">
                <div class="row text-center" id="heading">
                    <div class="col-md-6 col-md-offset-3 wow animated zoomInDown" id="heading-text">
                        <h3>YOUR DETAILS</h3>
                        <hr class="full">
                        <br/>
                    </div>
                </div>	<!-- row -->
                <div class="row about-us-text">
                    <div class="col-md-8 col-md-offset-2">
                        <p class="text-center">



<?php
$query = mysqli_query($con, "SELECT * FROM stagemgr_info WHERE l_id=$id");
while ($row = mysqli_fetch_array($query)) {
    ?>
                            <center>                                 
                                <table border="16%"  width="100%">

                                    <label style="display:none ; color:red"  id="aa"></label>

                                    <tr>
                                        <td>STAGE </td>
                                        <td><?php echo $row['stage']; ?>  <br></td>
                                    </tr>
                                    
                                   
                                    <tr>
                                        <td>MOBILE </td>
                                        <td><?php echo $row['phone']; ?>  <br></td>
                                    </tr>



    <?php
}
?>
<?php
$query2 = mysqli_query($con, "SELECT username FROM login WHERE l_id=$id");
while ($row = mysqli_fetch_array($query2)) {
    ?>
                                    <tr>
                                        <td>USERNAME</td>
                                        <td><?php echo $row['username']; ?> </td></tr>
                                   


                                    <?php
                                }
                                ?>
                            </table>

                            <br>  <a href="#change">Change Password</a>  </center>



                        </p>

                        <br><br>  <br><br>  <br><br>  <br><br>  <br><br>  <br><br>
                    </div>

                </div>
            </div>>
        </section>

        <!-- row -->
        <br><br>  <br><br><br><br>  <br><br>
         <section id="change">
            <div class="container">
                <div class="row text-center" id="heading">
                    <div class="col-md-6 col-md-offset-3 wow animated zoomInDown" id="heading-text">
                        <h3>Change password</h3>  <br><br>

                        <br/>
                    </div>
                </div>	<!-- row -->
                <div class="row about-us-text">
                    <div class="col-md-8 col-md-offset-2">
                        <br><br>


                        <div class="signup__container">

                            <div class="container__child signup__form">

                                <form id="search-form"  method="post" name="form1" >



                                    <div class="form-group">
                                        <br><label>Current Password</label>
                                        <input type="password" name="password" id="password" class="form-control" required onChange="add();"/>
                                        <label style="display:none ; color:red"  id="aaa"></label>

                                    </div>
                                    <div class="form-group">
                                        <br><label>New Password</label>
                                        <input type="password" name="newpassword" id="npwd" class="form-control" required onChange="CheckPassword();"/>
                                        <label style="display:none ; color:red"  id="pswrd_l"></label>

                                    </div>
                                    <div class="form-group">
                                        <br><label>Retype</label>
                                        <input type="password" name="confirmpassword" id="cnpwd" class="form-control" required onChange="pwdChek()"/>
                                        <label style="display:none ; color:red"  id="pswrd_2"></label>

                                    </div>
                                    <div class="m-t-lg">
                                        <ul class="list-inline">
                                            <li>
                                                <input type="submit" class="btn btn--form" align="center" name="register" id="pin" value="Change">


                                            </li>

                                        </ul>
                                    </div>


                                </form>
                            </div>
                        </div>









                        <br><br>  <br><br>  <br><br>  <br><br>  <br><br>  <br><br>

                    </div>

                </div>
            </div>>
        </section><!-- row -->
       
        

                        <br><br>  <br><br>  <br><br>  <br><br>  <br><br>  <br><br>


        <br><br>  <br><br>
        <!-- footer -->
        <section id= "footer" class= "main-footer">
            <div class= "row">
                <div class= "logo text-center">
                    <h1>School Kalolsavam</h1>
                </div>
            </div>
            <div class= "row">
                <div class= "copyright text-center">
                </div>
            </div>
        </section><!-- footer -->

        <!-- js -->
        <script>
            $(document).ready(function () {
                $("#client-speech").owlCarousel({
                    autoPlay: 3000,
                    navigation: false, // Show next and prev buttons
                    slideSpeed: 700,
                    paginationSpeed: 1000,
                    singleItem: true
                });
            });
        </script>
        <script>
            new WOW().init();
        </script>
        <script>
            $(function () {
                // init Isotope
                var $container = $('.isotope').isotope
                        ({
                            itemSelector: '.element-item',
                            layoutMode: 'fitRows'
                        });


                // bind filter button click
                $('#filters').on('click', 'button', function ()
                {
                    var filterValue = $(this).attr('data-filter');
                    // use filterFn if matches value
                    $container.isotope({filter: filterValue});
                });

                // change is-checked class on buttons
                $('.button-group').each(function (i, buttonGroup)
                {
                    var $buttonGroup = $(buttonGroup);
                    $buttonGroup.on('click', 'button', function ()
                    {
                        $buttonGroup.find('.is-checked').removeClass('is-checked');
                        $(this).addClass('is-checked');
                    });
                });

            });
        </script>
        <script src="users/js/jquery-ui-1.10.3.min.js"></script>
        <script src="users/js/jquery.knob.js"></script>
        <script src="users/js/daterangepicker.js"></script>
        <script src="users/js/bootstrap3-wysihtml5.all.min.js"></script>
        <script src="users/js/dashboard.js"></script>
        <script>

            function CheckPassword()
            {


                var p = document.getElementById('npwd').value;
                var passw = /^[A-Za-z]\w{7,14}$/;
                var error = "";
                var illegalChars = /[\W_]/; // allow only letters and numbers

                if (p == "") {
                    $("#pswrd_l").html('You didnt enter a password.').fadeIn().delay(3000).fadeOut();

                    npwd.value = "";
                    npwd.focus();
                    return false;
                } else if ((p.length < 7) || (p.value.length > 15) && (p.search(/[a-zA-Z]+/) == -1) || (p.search(/[0-9]+/) == -1)) {

                    $("#pswrd_l").html('The password is the wrong length,minimum 8  and 15 charecter and The password must contain at least one numeral ').fadeIn().delay(3000).fadeOut();

                    npwd.value = "";
                    npwd.focus();

                    return false;

                } else if ((p.search(/[a-zA-Z]+/) == -1) || (p.search(/[0-9]+/) == -1)) {

                    $("#pswrd_l").html('The password must contain at least one numeral').fadeIn().delay(3000).fadeOut();

                    npwd.value = "";
                    npwd.focus();
                    return false;

                } else {
                    p.style.background = 'White';
                }
                return true;
            }

            function pwdChek()
            {
                if (document.getElementById("npwd").value == document.getElementById("cnpwd").value)
                {
                    return true;
                } else
                {
                    $("#pswrd_2").html('***Password Mismatch***').fadeIn().delay(3000).fadeOut();


                    cnpwd.value = "";
                    cnpwd.focus();
                    document.getElementById("cnpwd").focus();
                    return false;
                }
            }







        </script> 


    </body>
</html>
