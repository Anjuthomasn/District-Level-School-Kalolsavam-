
<?php
include 'connection.php';
session_start();
if (!(isset($_SESSION['l_id']))) {
    header('location:index.php');
}

$id = $_SESSION['l_id'];


if (isset($_POST['submitss'])) {

    $stagename=strtoupper($_POST['s']);
    $no=$_POST['sno'];
    $year=$_POST['ss'];
    $sd = "SELECT `stage_name` FROM `kalolsavam_tb8_stagelist` WHERE `stage_name`='$stagename' ";
    $re = mysqli_query($con, $sd);

    $row1 = mysqli_fetch_array($re);
    $rr2 = $row1["stage_name"];
    if ($rr2 == $stagename) {
        echo"<script>alert(' already added  ');</script>)";
    } else {



          $sql1 = "INSERT INTO `kalolsavam_tb8_stagelist`(`stage_name`,`stage_no`,`year`,sts) VALUES ('$stagename',$no,'$year',1)"; 
        $result1 = mysqli_query($con, $sql1);
        if($result1)
        {
            
        echo"<script>alert(' stagelist added  ');</script>)";
        }
    }
}
?>
<!DOCTYPE html>
<html>
    <head>
        <title>School Kalolsavam</title>

        <!-- meta -->
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- css -->
        <link rel="stylesheet" href="users/css/bootstrap.min_2.css">
        <link rel="stylesheet" href="users/css/ionicons.min.css">
        <link rel="stylesheet" href="users/css/font-awesome.min.css">
        <link rel="stylesheet" href="users/css/owl.carousel.css">
        <link rel="stylesheet" href="users/css/owl.theme.css">
        <link rel="stylesheet" href="users/css/owl.transitions.css">
        <link rel="stylesheet" href="users/css/animate.css">
        <link rel="stylesheet" href="users/css/custom.css">

        <!-- js -->
        <script src="users/js/jquery.min.js"></script>
        <script src="users/js/bootstrap.min.js"></script>
        <script src="users/js/owl.carousel.min.js"></script>
        <script src="users/js/isotope.pkgd.min.js"></script>
        <script src="users/js/script.js"></script>
        <script src="users/js/wow.min.js"></script>
        <script src="users/js/jquery.actual.min.js"></script>

        <link rel="stylesheet" href="css2/s8.css">
        <style>
            table {
                
          background-color: white;
            }
            th,td{
                 font-size: 14px;
                 padding: 0px;
                 font-weight: bold;
                 text-align: center
            }

        </style>
         

    </head>

    <body>
        <div id="wrapper">


            <section id= "navigation">
                <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
                    <div class="container-fluid">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                                <span class="ion-navicon"></span>
                            </button>
                            <a class="navbar-brand" href="#">School Kalolsavam </a>
                        </div>
                       <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                <ul class="nav navbar-nav navbar-right">
                                    <li><a href="adminhome.php">HOME</a></li>
                                   <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true"> <span class="nav-label">ADD</span> <span class="caret"></span></a>
                                        <ul class="dropdown-menu">
                                            <li><a href="Admin_add_subdistrict.php">ADD SUBDISTRICT</a></li>
                                            <li><a href="Admin_add_program.php">ADD PROGRAM LIST</a></li>
                                            <li> <a href="Admin_add_stagedetails.php">ADD STAGE DETAILS</a></li>



                                        </ul>
                                    </li>

                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true"> <span class="nav-label">BLOCK/UNBLOCK USERS</span> <span class="caret"></span></a>
                                        <ul class="dropdown-menu">
                                            <li><a href="Admin_view_usersd.php">SUBDISTRICT COORDINATOR</a></li>
                                            <li><a href="Admin_view_usersc.php">SCHOOL COORDINATOR</a></li>
                                            <li><a href="Admin_view_userstage.php">STAGE MANAGERS</a></li>



                                        </ul>
                                    </li>
                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true"> <span class="nav-label">VIEW & UPDATE </span> <span class="caret"></span></a>
                                        <ul class="dropdown-menu">
                                            <li><a href="Admin_view_program.php">PROGRAM LIST</a></li>
                                            <li><a href="Admin_view_registerprogrram.php">REGISTERD PROGRAMS</a></li>
                                          


                                        </ul>
                                    </li>

                                     <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true"> <span class="nav-label">CHEST NUMBER</span> <span class="caret"></span></a>
                                    <ul class="dropdown-menu">
                                        <li><a href="Admin_chestnogenerate.php">GENERATE CHEST NUMBER</a></li>
                                        <li><a href="Admin_view_chestno.php">VIEW CHEST NUMBER</a></li>
                                        
                                    



                                    </ul>
                                </li>
                                    
                                    <li><a href="logout.php">LOGOUT</a></li>
                                </ul>
                            </div>

                    </div>	<!-- container-fluid -->
                </nav>

                <!-- navbar -->
            </section>	<!-- #navigation -->

            <div class="row text-center" id="heading">
                <div class="col-md-6 col-md-offset-3 wow animated zoomInDown" id="heading-text">
                    <h3>ADD STAGE</h3>
                    <hr class="full">
                    <br/>
                </div>

            </div>




        </section><!-- row -->       


        <br><br><br><br>

        <div class="signup__container">

            <div class="container__child signup__form">

                <form id="search-form"  method="post" name="form1" >



                    <div class="form-group">
                        <br><label>STAGE</label>
                        <input type="text" name="s" id="s" class="form-control" required onChange="add();" onkeypress="return onlyAlphabets(event,this);"/>
                        <label style="display:none ; color:red"  id="aaa"></label>

                    </div>
                    <div class="form-group">
                        <br><label>STAGE NUMBER</label>
                        <input type="number" name="sno" id="sno" class="form-control" required  />
                       
                    </div>
                  
                   
                    <div class="form-group">
                        <br><label>year</label>
                         <select name="ss" id="section" class="form-control" required>
                            <option>2019</option>
                            <option>2020</option>
                            <option>2021</option>
                            <option>2021</option>

                        </select>
                        <label style="display:none ; color:red"  id="aaa"></label>

                    </div>
                   
                    <div class="m-t-lg">
                        <ul class="list-inline">
                            <li>
                                <input type="submit" class="btn btn--form" align="center" name="submitss" id="pin" value="Add">


                            </li>

                        </ul>
                    </div>


                </form>
            </div>
        </div>
        <?php
        include 'connection.php';
        if (isset($_POST['edit'])) {
            $sname=strtoupper($_POST['sname']);
            $times=$_POST['times'];
              $dates=$_POST['dat'];
            
            
            $id = $_POST['sdt'];

            $q = "UPDATE `kalolsavam_tb8_stagelist` SET `stage_name`='$sname' AND `stage_no`='$times'WHERE `stge_id`=$id";
            $query = mysqli_query($con, $q);
        }

//for deletion
        if (isset($_POST['delete'])) {
            $id = $_POST['stge_id'];
            $query = mysqli_query($con, "DELETE FROM `kalolsavam_tb8_stagelist` WHERE `stge_id`=$id");
        }
        ?>
        <center>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
 
            <?php 
            $qs = mysqli_query($con, "select * from kalolsavam_tb8_stagelist");
              if(mysqli_num_rows($qs) < 1)
              {?>
                   <br><br><br><br><br><br><br><br>
                        <label style="color:red;font-size:18px" >STAGE DETAILS NOT ADDED</label>
        <br><br><br><br><br><br><br><br>><br><br><br><br>
      
             <?php }
 else {
            ?>
            <table border="16%"  width="80%" background-color:="white">
                
                <tr>

                    <th >STAGE</th>
                    <th >STAGE NO</th>
                    <th >YEAR</th>
                    
                    <th></th>
                    <th>Update</th>

                    <th>Delete</th>




                </tr>
                <?php
                include 'connection.php';
                $querys = mysqli_query($con, "select * from kalolsavam_tb8_stagelist");
                while ($row = mysqli_fetch_array($querys)) {
                    ?><form action="#" method="post">
                        <tr>

                            <td><input class="txt" type="text" name="sname"  value="<?php echo $row['stage_name']; ?>"></td>
                            <td><input class="txt" type="text" name="times" value="<?php echo $row['stage_no']; ?>"></td>
                            
                            <td><input class="txt" type="text" name="dat"  value="<?php echo $row['year']; ?>"></td>
                            <td><input class="txt" type="hidden" name="sdt" hidden value="<?php echo $row['stge_id']; ?>"></td>
                            <td><input type="submit" name="edit" class="btn btn-inverse large" value="UPDATE"></td>
                            <td><input type="submit" name="delete" class="btn btn-inverse large" value="DELETE"></td>


                        </tr></form>
                    <?php
                }
                ?>
            </table>
   <?php
                }
                ?>
        </center>

        <br><br>  <br><br>  <br><br>  <br><br>  <br><br>  <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br>




        <br><br>  <br><br>  <br><br>  <br><br>  <br><br>  <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br>
        <!-- footer -->
        <section id= "footer" class= "main-footer">
            <div class= "row">
                <div class= "logo text-center">
                    <h1>School Kalolsavam</h1>
                </div>
            </div>
            <div class= "row">
                <div class= "copyright text-center">
                </div>
            </div>
        </section><!-- footer -->

        <!-- js -->
        <script>
            $(document).ready(function () {
                $("#client-speech").owlCarousel({
                    autoPlay: 3000,
                    navigation: false, // Show next and prev buttons
                    slideSpeed: 700,
                    paginationSpeed: 1000,
                    singleItem: true
                });
            });
        </script>
        <script>
            new WOW().init();
        </script>
        <script>
            function onlyAlphabets(e, t) {
            try {
                if (window.event) {
                    var charCode = window.event.keyCode;
                }
                else if (e) {
                    var charCode = e.which;
                }
                else { return true; }
                if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123))
                    return true;
                else
                    return false;
            }
            catch (err) {
                alert(err.Description);
            }
        }
            $(function () {
                // init Isotope
                var $container = $('.isotope').isotope
                        ({
                            itemSelector: '.element-item',
                            layoutMode: 'fitRows'
                        });


                // bind filter button click
                $('#filters').on('click', 'button', function ()
                {
                    var filterValue = $(this).attr('data-filter');
                    // use filterFn if matches value
                    $container.isotope({filter: filterValue});
                });

                // change is-checked class on buttons
                $('.button-group').each(function (i, buttonGroup)
                {
                    var $buttonGroup = $(buttonGroup);
                    $buttonGroup.on('click', 'button', function ()
                    {
                        $buttonGroup.find('.is-checked').removeClass('is-checked');
                        $(this).addClass('is-checked');
                    });
                });

            });
        </script>
        <script src="users/js/jquery-ui-1.10.3.min.js"></script>
        <script src="users/js/jquery.knob.js"></script>
        <script src="users/js/daterangepicker.js"></script>
        <script src="users/js/bootstrap3-wysihtml5.all.min.js"></script>
        <script src="users/js/dashboard.js"></script>
    </div>
    <script>
            function add()
            {
                var x = document.getElementById('s').value;


                if ((x === null) || (x.length <= 1))
                {


                    $("#aaa").html('Invalid Name').fadeIn().delay(3000).fadeOut();

                    s.value = "";
                    s.focus();
                    return false;
                }
                var fnam = /^[a-zA-Z ]{4,25}$/;
                if (document.form1.s.value.search(s) == -1)
                {

                    $("#aaa").html('Invalid Name').fadeIn().delay(3000).fadeOut();
                    s.value = "";
                    s.focus();

                    return false;
                }

            }
    </script>

</body>
</html>
