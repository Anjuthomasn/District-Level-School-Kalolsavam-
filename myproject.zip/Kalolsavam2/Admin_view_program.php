
<?php
include 'connection.php';
session_start();
if (!(isset($_SESSION['l_id']))) {
    header('location:index.php');
}

$id = $_SESSION['l_id'];
?>
<!DOCTYPE html>
<html>
    <head>
        <title>School Kalolsavam</title>

        <!-- meta -->
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- css -->
        <link rel="stylesheet" href="users/css/bootstrap.min_2.css">
        <link rel="stylesheet" href="users/css/ionicons.min.css">
        <link rel="stylesheet" href="users/css/font-awesome.min.css">
        <link rel="stylesheet" href="users/css/owl.carousel.css">
        <link rel="stylesheet" href="users/css/owl.theme.css">
        <link rel="stylesheet" href="users/css/owl.transitions.css">
        <link rel="stylesheet" href="users/css/animate.css">
        <link rel="stylesheet" href="users/css/custom.css">

        <!-- js -->
        <script src="users/js/jquery.min.js"></script>
        <script src="users/js/bootstrap.min.js"></script>
        <script src="users/js/owl.carousel.min.js"></script>
        <script src="users/js/isotope.pkgd.min.js"></script>
        <script src="users/js/script.js"></script>
        <script src="users/js/wow.min.js"></script>
        <script src="users/js/jquery.actual.min.js"></script>

        <link rel="stylesheet" href="css2/style3.css">
        <style>  
            table {
                border-collapse: collapse;
                  background-color: #f2f2f2;
               
                width:50%;
            }

            th, td {
                text-align: center;
                padding: 8px;
                font-size: 14px;
                font-weight: bold;
            }

            tr:nth-child(even){background-color: #f2f2f2}

            th {
                color: black;
                font-size: 16px;
                font-family: helvetica;
                font-weight: bolder;
            }
            tr{
                padding: 4px;
            }
        </style>

    </head>

    <body>
        <div id="wrapper">


            <section id= "navigation">
                <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
                    <div class="container-fluid">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                                <span class="ion-navicon"></span>
                            </button>
                            <a class="navbar-brand" href="#">School Kalolsavam </a>
                        </div>
 <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                <ul class="nav navbar-nav navbar-right">
                                    <li><a href="adminhome.php">HOME</a></li>
                                   <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true"> <span class="nav-label">ADD</span> <span class="caret"></span></a>
                                        <ul class="dropdown-menu">
                                            <li><a href="Admin_add_subdistrict.php">ADD SUBDISTRICT</a></li>
                                            <li><a href="Admin_add_program.php">ADD PROGRAM LIST</a></li>
                                            <li> <a href="Admin_add_stagedetails.php">ADD STAGE DETAILS</a></li>



                                        </ul>
                                    </li>

                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true"> <span class="nav-label">BLOCK/UNBLOCK USERS</span> <span class="caret"></span></a>
                                        <ul class="dropdown-menu">
                                            <li><a href="Admin_view_usersd.php">SUBDISTRICT COORDINATOR</a></li>
                                            <li><a href="Admin_view_usersc.php">SCHOOL COORDINATOR</a></li>
                                            <li><a href="Admin_view_userstage.php">STAGE MANAGERS</a></li>



                                        </ul>
                                    </li>
                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true"> <span class="nav-label">VIEW & UPDATE </span> <span class="caret"></span></a>
                                        <ul class="dropdown-menu">
                                            <li><a href="Admin_view_program.php">PROGRAM LIST</a></li>
                                            <li><a href="Admin_view_registerprogrram.php">REGISTERD PROGRAMS</a></li>
                                          


                                        </ul>
                                    </li>

                                     <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true"> <span class="nav-label">CHEST NUMBER</span> <span class="caret"></span></a>
                                    <ul class="dropdown-menu">
                                        <li><a href="Admin_chestnogenerate.php">GENERATE CHEST NUMBER</a></li>
                                        <li><a href="Admin_view_chestno.php">VIEW CHEST NUMBER</a></li>
                                        
                                    



                                    </ul>
                                </li>
                                    
                                    <li><a href="logout.php">LOGOUT</a></li>
                                </ul>
                            </div>
	<!-- container-fluid -->
                </nav>

                <!-- navbar -->
           

        <br><br><br><br>

<?php
if (isset($_POST['edit'])) {
    $section =strtoupper(ucfirst( $_POST['section']));
    $itemcode = $_POST['itemcode'];
    $itemname = strtoupper(ucfirst($_POST['itemname']));
    $gender = strtoupper($_POST['gender']);
    $type = strtoupper($_POST['type']);
    
   $id = $_POST['sid'];
    $id = $_POST['sid'];

    $q = "UPDATE `kalolsavam_tb11_program_list` SET `section`='$section', `item_code`='$itemcode', `item`='$itemname', `gender`='$gender', `category`='$type' WHERE `pgm_list_id`=$id";
    $query = mysqli_query($con, $q);
}

//for deletion
if (isset($_POST['delete'])) {
    $id = $_POST['sid'];
    $query = mysqli_query($con, "DELETE FROM `kalolsavam_tb11_program_list` WHERE `list_id`=$id");
}
?>
       

            <br>
            <?php
$s = mysqli_query($con, "select * from kalolsavam_tb11_program_list");
 $rs=mysqli_fetch_array($s);
               if(mysqli_num_rows($s)  < 1)
                   {?><br><br><br><br><br><br><br><br>
                        <label style="color:red;font-size:18px" >No entered programs</label>
        <br><br><br><br><br><br><br><br>><br><br><br><br>
              <?php }
 else {?>
         </section>	<!-- #navigation -->

            <div class="row text-center" id="heading">
                <div class="col-md-6 col-md-offset-3 wow animated zoomInDown" id="heading-text">
                    <h3>Program List</h3>
                    <hr class="full">
                    <br/>
                </div>

            </div>  </section><!-- row -->       

           <center>  <table border="16%"  width="40%" >
                
                <tr >

                    <th>SECTION</th>
                    <th>ITEM CODE</th>
                    <th>ITEM NAME</th>
                    <th>GENDER</th>
                    <th>ITEM TYPE</th>
                    <th> </th>

                    <th>Update</th>

                    <th>Delete</th>




                </tr>
<?php
$query = mysqli_query($con, "select * from kalolsavam_tb11_program_list");
while ($row = mysqli_fetch_array($query)) {
    ?><form action="#" method="post">
                        <tr>

                            <td><input class="txt" type="text" name="section" value="<?php echo $row['section'];  ?>" onkeypress="return onlyAlphabets(event,this);" required="" ></td>
                            <td><input class="txt" type="text" name="itemcode" value="<?php echo $row['item_code']; ?>" ></td>
                            <td><input class="txt" type="text" name="itemname" value="<?php echo $row['item']; ?>" onkeypress="return onlyAlphabets(event,this);" required=""></td>
                            <td><input class="txt" type="text" name="gender" value="<?php echo $row['gender']; ?>" onkeypress="return onlyAlphabets(event,this);" required="" ></td>
                            <td><input class="txt" type="text" name="type" value="<?php echo $row['category']; ?>" onkeypress="return onlyAlphabets(event,this);" required=""></td>
                            <td><input class="txt" type="hidden" name="sid" hidden value="<?php echo $row['pgm_list_id']; ?>"></td>
                            <td><input type="submit" name="edit" class="btn btn-inverse large" value="UPDATE"></td>
                            <td><input type="submit" name="delete" class="btn btn-inverse large" value="DELETE"></td>


                        </tr></form>
    <?php
}
?>
            </table> </center>
          <?php
}
?>

        

        <br><br>  <br><br>  <br><br>  <br><br>  <br><br>  <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br>




        <br><br>  <br><br>  <br><br>  <br><br>  <br><br>  <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br>
        <!-- footer -->
        <section id= "footer" class= "main-footer">
            <div class= "row">
                <div class= "logo text-center">
                    <h1>School Kalolsavam</h1>
                </div>
            </div>
            <div class= "row">
                <div class= "copyright text-center">
                </div>
            </div>
        </section><!-- footer -->

        <!-- js -->
        <script>
            $(document).ready(function () {
                $("#client-speech").owlCarousel({
                    autoPlay: 3000,
                    navigation: false, // Show next and prev buttons
                    slideSpeed: 700,
                    paginationSpeed: 1000,
                    singleItem: true
                });
            });
             function onlyAlphabets(e, t) {
            try {
                if (window.event) {
                    var charCode = window.event.keyCode;
                }
                else if (e) {
                    var charCode = e.which;
                }
                else { return true; }
                if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123))
                    return true;
                else
                    return false;
            }
            catch (err) {
                alert(err.Description);
            }
        }
        </script>
        <script>
            new WOW().init();
        </script>
        <script>
            $(function () {
                // init Isotope
                var $container = $('.isotope').isotope
                        ({
                            itemSelector: '.element-item',
                            layoutMode: 'fitRows'
                        });


                // bind filter button click
                $('#filters').on('click', 'button', function ()
                {
                    var filterValue = $(this).attr('data-filter');
                    // use filterFn if matches value
                    $container.isotope({filter: filterValue});
                });

                // change is-checked class on buttons
                $('.button-group').each(function (i, buttonGroup)
                {
                    var $buttonGroup = $(buttonGroup);
                    $buttonGroup.on('click', 'button', function ()
                    {
                        $buttonGroup.find('.is-checked').removeClass('is-checked');
                        $(this).addClass('is-checked');
                    });
                });

            });
        </script>
        <script src="users/js/jquery-ui-1.10.3.min.js"></script>
        <script src="users/js/jquery.knob.js"></script>
        <script src="users/js/daterangepicker.js"></script>
        <script src="users/js/bootstrap3-wysihtml5.all.min.js"></script>
        <script src="users/js/dashboard.js"></script>
    </div>
    <script>
            function add()
            {
                var x = document.getElementById('subdistricts').value;


                if ((x === null) || (x.length <= 1))
                {


                    $("#aaa").html('Invalid Name').fadeIn().delay(3000).fadeOut();

                    subdistricts.value = "";
                    subdistricts.focus();
                    return false;
                }
                var fnam = /^[a-zA-Z ]{4,25}$/;
                if (document.form1.subdistricts.value.search(subdistricts) == -1)
                {

                    $("#aaa").html('Invalid Name').fadeIn().delay(3000).fadeOut();
                    subdistricts.value = "";
                    subdistricts.focus();

                    return false;
                }

            }
    </script>

</body>
</html>
