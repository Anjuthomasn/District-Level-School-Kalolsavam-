<?php
include 'student_header2.php';
include 'connection.php';

$id = $_SESSION['l_id'];

?>
<?php

    $qry="select * from kalolsavam_tb7_studentinfo where l_id=$id";
     $ans = mysqli_query($con, $qry);
     
     $r=mysqli_fetch_array($ans);
     $section=$r['section'];
     $gen=$r['gender'];
     $sdid=$r['student_id'];
     $studid=$r['student_id'];
     if(isset($_POST['submit']))
    {
         
         
          $c = $_POST['pgid'];
          foreach($c as $pgmid)
            {
                       
         $pgmsid=$pgmid;
         if($pgmsid==NULL)
         {
              echo"<script> alert('Please select Program ')
                         window.location.href = 'studentprofile.php';</script>";

         }
 else {
             
         
      $check="select * from kalolsavam_tb12_registerd_program where student_id=$sdid and pgm_list_id='$pgmsid' ";
       $checkans= mysqli_query($con, $check);
      $ch=mysqli_fetch_array($checkans);
     if(mysqli_num_rows($checkans) < 1)
     {
         $time=date("h:i:s");
         $date=date("d/m/Y");
         $registration="insert into `kalolsavam_tb12_registerd_program`(`student_id`,`pgm_list_id`,`reg_date`,`time`,`status`) values($studid,'$pgmsid','$date','$time',1) ";
         $regresult=mysqli_query($con,$registration);
            
         if($regresult)
                    {
                        
                        
                         echo"<script> alert('Registration Successful')
                         window.location.href = 'studentprofile.php';</script>";
                        
                    }
            }
 else {
     echo"<script> alert('You alredy Registerd ')
                         window.location.href = 'studentprofile.php';</script>";
 }
 }
           }
    }
     
     
?>

  <center>

        <?php
            $s = mysqli_query($con, "select * from kalolsavam_tb11_program_list");
            $rs=mysqli_fetch_array($s);
           if(mysqli_num_rows($s) < 1)
           {?>
 
                        <label style="color:red;font-size:18px" >No Program for to register</label>
        
      
            <?php   
           }
          else {
        ?>
                        <form action="#" method="post" name="form2">
            <table border="1">
               
         <label style="display:none ; color:red"  id="aa"></label>
                
              <tr>      <th>Program</th>

                    <th>Program Code</th>

                    <th>Time Limit</th>
                    <th>Select</th>




                </tr>
<?php
$query = mysqli_query($con, "select * from `kalolsavam_tb11_program_list` where section='$section' and gender='$gen'");
while ($row = mysqli_fetch_array($query)) {
    ?>
                        <tr>

                            <td><input class="txt" type="text" name="sdtname" id="sdt"  value="<?php echo $row['item']; ?>" disabled /></td>
                            <td><input class="txt" type="text" name="sdt"  value="<?php echo $row['item_code']; ?>"  disabled></td>
                             <td><input class="txt" type="text" name="time"  value="<?php echo $row['time_limit']; ?>"  disabled></td>
                             <td><input class="txt" type="checkbox" name="pgid[]" id="pgid" value="<?php echo $row['pgm_list_id']; ?>"  ></td>

                        </tr>
                       
   
                    <?php
                }
                ?>
            </table>
                            <br>     <input type="submit" value="Register" name="submit" onclick="uncheck();">
                       
                             </form>
            <?php
                }
                ?>
        </center>
<script>
function uncheck() {
    document.getElementById("pgid").checked = false;
    alert('Please slect');
}
</script>

<?php
include 'student_footer.php';
?>      


