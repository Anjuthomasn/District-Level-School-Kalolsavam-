
<?php
include 'adminheader.php';
?>
 <section id="starting">
                    <div class="text-center starting-text">
                        <h1 class="rene">WELCOME</h1>
                        <h2></h2>
                    </div>
                </section>
<?php
include 'adminfooter.php';
?>  