<?php
include 'connection.php';
session_start();
if (!(isset($_SESSION['l_id']))) {
    header('location:index.php');
}

$id = $_SESSION['l_id'];
 $query ="SELECT `school` FROM `school_info` WHERE `l_id`='$id' ";
    $r1=mysqli_query($con,$query);
    $row=mysqli_fetch_array($r1);
    $sc=$row["school"];
?>

<!DOCTYPE html>
<html>
    <head>
        <title>School Kalolsavam</title>

        <!-- meta -->
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- css -->
        <link rel="stylesheet" href="users/css/bootstrap.min.css">
        <link rel="stylesheet" href="users/css/ionicons.min.css">
        <link rel="stylesheet" href="users/css/font-awesome.min.css">
        <link rel="stylesheet" href="users/css/owl.carousel.css">
        <link rel="stylesheet" href="users/css/owl.theme.css">
        <link rel="stylesheet" href="users/css/owl.transitions.css">
        <link rel="stylesheet" href="users/css/animate.css">
        <link rel="stylesheet" href="users/css/custom.css">

        <!-- js -->
        <script src="users/js/jquery.min.js"></script>
        <script src="users/js/bootstrap.min.js"></script>
        <script src="users/js/owl.carousel.min.js"></script>
        <script src="users/js/isotope.pkgd.min.js"></script>
        <script src="users/js/script.js"></script>
        <script src="users/js/wow.min.js"></script>
        <script src="users/js/jquery.actual.min.js"></script>

        <link rel="stylesheet" href="css2/style4.css">

        <style>
            table {
                border-collapse: collapse;
                width:50%;
                background-color: white;
            }

            th, td {
                text-align: center;
                padding: 8px;
                font-size: 14px;
                font-weight: bold;
            }

            tr:nth-child(even){background-color: #f2f2f2}

            th {
                color: black;
                font-size: 16px;
                font-family: helvetica;
                font-weight: bolder;
            }
        </style>



    </head>

    <body>
        <div id="wrapper">
            <div id="overlay-1">
                <section id= "navigation">
                    <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
                        <div class="container-fluid">
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                                    <span class="ion-navicon"></span>
                                </button>
                                <a class="navbar-brand" href="#">School Kalolsavam </a>
                            </div>
                            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                <ul class="nav navbar-nav navbar-right">
                                    <li><a href="#starting">HOME</a></li>
                                    <li><a href="#profile">ACCOUNT INFORMETION</a></li>
                                    <li><a href="">STUDENT LIST OF PROGRAM</a></li>
                                    <li><a href="logout.php">LOGOUT</a></li>
                                </ul>
                            </div>	<!-- collapse navbar-collapse -->
                        </div>	<!-- container-fluid -->
                    </nav>	<!-- navbar -->
                </section>	<!-- #navigation -->

               	<!-- #navigation -->

                
                    <center>
                    <?php
              $ss = mysqli_query($con, "select program_reg.*,chestnumber.* from program_reg,chestnumber where program_reg.school='$sc' and program_reg.pg_id=chestnumber.pg_id ");
               $rs=mysqli_fetch_array($ss);
               if(mysqli_num_rows($ss)  < 1)
                   {?><br><br><br><br><br><br><br><br>
                        <label style="color:red;font-size:18px" > Student details not enter</label>
        <br><br><br><br><br><br><br><br>><br><br><br><br>
              <?php }
               else
               {
         
        
                ?><div class="row text-center" id="heading">
                    <div class="col-md-6 col-md-offset-3 wow animated zoomInDown" id="heading-text">
                        <h3>Student  List</h3>
                        <hr class="full">
                        <br/>
                    </div>
                    
                </div> 
                        <table border="16%"  width="50%"  bgcolor="white">
                  
                    <tr>

                        <th>ITEM</th>
                        <th>STUDENT NAME</th>
                        <th>SECTION</th>
                        <th>CHEST NUMBER</th>
                       

              


                    </tr>
                    <?php
                    $query = mysqli_query($con, "select program_reg.*,chestnumber.* from program_reg,chestnumber where program_reg.school='$sc' and program_reg.pg_id=chestnumber.pg_id ");
                    while ($row = mysqli_fetch_array($query)) {
                        ?><form action="#" method="post">
                            <tr>

                               <td><?php echo $row['item']; ?></td>
                                <td><?php echo $row['studentname']; ?></td>
                                <td><?php echo $row['section']; ?></td>
                                
                                <td><?php echo $row['chestno']; ?></td>
                                

                            </tr></form>
                        <?php
                    }
                    ?>
                </table>
                <?php
                }?>
                </center>


                <br><br><br><br>


                <br><br>  <br><br>  <br><br>  <br><br>  <br><br>  <br><br>


                <br><br>  <br><br>
                <!-- footer -->
                <section id= "footer" class= "main-footer">
                    <div class= "row">
                        <div class= "logo text-center">
                            <h1>School Kalolsavam</h1>
                        </div>
                    </div>
                    <div class= "row">
                        <div class= "copyright text-center">
                        </div>
                    </div>
                </section><!-- footer -->

                <!-- js -->
                <script>
                    $(document).ready(function () {
                        $("#client-speech").owlCarousel({
                            autoPlay: 3000,
                            navigation: false, // Show next and prev buttons
                            slideSpeed: 700,
                            paginationSpeed: 1000,
                            singleItem: true
                        });
                    });
                </script>
                <script>
                    new WOW().init();
                </script>
                <script>
                    $(function () {
                        // init Isotope
                        var $container = $('.isotope').isotope
                                ({
                                    itemSelector: '.element-item',
                                    layoutMode: 'fitRows'
                                });


                        // bind filter button click
                        $('#filters').on('click', 'button', function ()
                        {
                            var filterValue = $(this).attr('data-filter');
                            // use filterFn if matches value
                            $container.isotope({filter: filterValue});
                        });

                        // change is-checked class on buttons
                        $('.button-group').each(function (i, buttonGroup)
                        {
                            var $buttonGroup = $(buttonGroup);
                            $buttonGroup.on('click', 'button', function ()
                            {
                                $buttonGroup.find('.is-checked').removeClass('is-checked');
                                $(this).addClass('is-checked');
                            });
                        });

                    });
                </script>
                <script src="users/js/jquery-ui-1.10.3.min.js"></script>
                <script src="users/js/jquery.knob.js"></script>
                <script src="users/js/daterangepicker.js"></script>
                <script src="users/js/bootstrap3-wysihtml5.all.min.js"></script>
                <script src="users/js/dashboard.js"></script>
                <script>




                </script> 


                </body>
                </html>
