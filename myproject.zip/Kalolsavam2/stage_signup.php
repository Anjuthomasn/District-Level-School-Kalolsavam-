<?php

include 'connection.php';
// session_start();


    if(isset($_POST['submits']))
    {
        
        $subdistrict=$_POST['subdistrict'];
        $username=$_POST['username'];
        $email= $_POST['email'];
        $phone=$_POST['phone'];
        $password=$_POST['password1'];
        $p=md5($password);
        $password1=$_POST['password2'];
         
         $un="SELECT `username` FROM `kalolsavam_tb1_login` WHERE `username`='$username'";
         $r1=mysqli_query($con,$un);
         $sd="SELECT `stge_id` FROM `kalolsavam_tb9_stagemgr_info` WHERE `stge_id`='$subdistrict'";
         $r2=mysqli_query($con,$sd);
         $row=mysqli_fetch_array($r1);
         $rr1=$row["username"];
         $row1=mysqli_fetch_array($r2);
         $rr2=$row1["stge_id"];
         if($rr1==$username)
         {
             echo"<script>alert('Sorry  username is already in use..Please choose a different one..! ');</script>)";
         
             
         }
         elseif ($rr2==$subdistrict) {
             echo"<script>alert('Sorry you alredy registerd, pleas login! ');</script>)";
     }
     else {
         
        
           $sql1="INSERT INTO `kalolsavam_tb1_login`(`username`, `password`,`role`,`status`) VALUES ('$username','$p',3,1)";
            $result1=mysqli_query($con,$sql1);
       
           $l_id="SELECT `l_id` FROM `kalolsavam_tb1_login` WHERE `username`='$username'";
            $result2=mysqli_query($con,$l_id);
            while($row=mysqli_fetch_array($result2))
            {

                 $a=$row["l_id"];
                 $ssn="INSERT INTO `kalolsavam_tb2_user`(`l_id`,`email`,`phone`) VALUES($a,'$email','$phone')";
                 $re=mysqli_query($con,$ssn);
                 
            }
              $u_id="SELECT `user_id` FROM `kalolsavam_tb2_user` WHERE `l_id`='$a'";
            $r2=mysqli_query($con,$u_id);
             while($ru=mysqli_fetch_array($r2))
            {
                 $u=$ru['user_id'];
                 $sql="INSERT INTO `kalolsavam_tb9_stagemgr_info`(`l_id`,`user_id`,`stge_id`) VALUES($a,$u,$subdistrict)";

               //  echo $sql;
                  $result3=mysqli_query($con,$sql);
            }
            if($result3)
                    {
                        
                        
                         echo"<script> alert('Registration Successful,Please Login')
						 window.location.href = 'index.php';</script>";
                        
                    }
     }
//echo"<script>alert('Data Entered Successfully');</script>)";
           

        
        

        }

                
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>

<?php
include 'component/header.php';
?>

<!--  <script src="validation/jquery.min.js"> </script>
 <script src="validation/oh-autoval.js"></script>
 -->
 <br><br>
<div class="container register">
<div class="row">
<div class="col-md-3 register-left">
<img src="https://image.ibb.co/n7oTvU/logo_white.png" alt=""/>
<h3>Welcome</h3><br><br>
 <a  href="index.php" >LOGIN</a>
   <!--  <input type="submit" name="" value="Login"/><br/>
  --></div>
<div class="col-md-9 register-right">
<ul class="nav nav-tabs nav-justified" id="myTab" role="tablist">
</ul>
 <div class="tab-content" id="myTabContent">
<div class="tab-pane fade show active"  role="tabpanel" aria-labelledby="home-tab">
 <h3 class="register-heading">SUBDISTRICT COORDINATOR REGISTRATION</h3>

 <form method="post" name="studentreg" name="myform" >
    <div class="row register-form">
      <div class="col-md-6">
    <div class="form-group"> 
        <input  type="text" class="form-control" placeholder="USER NAME *" name="username" id="username" onkeypress="return onlyAlphabets(event,this);" onchange="userName();"  required />
<!--        <input type="text" class="form-control" placeholder="USER NAME *" name="username" id="username" onChange="userName();"   required />-->
        <label style="display:none ; color:red"  id="uname_l"></label>
    </div>
     <div class="form-group">
         <input type="password" class="form-control" placeholder="PASSWORD *" name="password1" id="password1" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters"  onchange="CheckPassword();" required />
   </div>
<div class="form-group">
    <input type="password" class="form-control"  placeholder="CONFIRM PASSWORD*" name="password2" id="cnpwd" onChange="pwdChek()" required />
 </div>
 
          
   
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="email" class="form-control" placeholder="YOUR EMAIL *" name="email" id="email"   onChange="return checkEmail();" required />
                                        </div>
                                        <div class="form-group">
                                            <input type="text" minlength="10" maxlength="10" name="phone" class="form-control" placeholder="YOUR MOBILE *" id="mobile" onChange="mob();" required />
                                        </div>
                                        <!-- <div class="form-group">
                                            <select class="form-control">
                                                <option class="hidden"  selected disabled>Please select your Sequrity Question</option>
                                                <option>What is your Birthdate?</option>
                                                <option>What is Your old Phone Number</option>
                                                <option>What is your Pet Name?</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="Enter Your Answer *" value="" />
                                        </div> -->
 
                   <div class="form-group">
                       <select class="form-control" name="subdistrict" id="subdistrict" >
                  
          
        <?php
         $con = mysqli_connect("localhost", "root", "", "kalolsavam");
                                    if (!$con) {
                                        echo "Could not connect..Try again";
                                    } else {
                                        $sdselect = "SELECT * FROM `kalolsavam_tb8_stagelist` WHERE sts=1";
                                        $sdresult = mysqli_query($con, $sdselect);
                                        echo "<option value=-1>SELECT STAGE</option>";
                                        while ($sdrow = mysqli_fetch_array($sdresult)) {
                                            $stname = $sdrow['stage_name'];
                                            $sid = $sdrow['stge_id'];
                                            echo "<option value='$sid'>$stname</option>";
                                        }
                                    }
                                    mysqli_close($con);
                                    ?>
              </select>
                       </div>
                       <br>                                   
         
                        <script> 
      
              
                      function validate()
      {
            if (document.getElementById("subdistrict").selectedValue == 'SELECT SUBDISTRICT' )
            {
                 alert("Select Subdistrict");
            }
             else 
            
            if (document.getElementById("school").selectedIndex == 0){
             alert("Select School");
            }
            
    
       }
                </script>

 

 <input type="submit" class="btnRegister"  value="Register" id="submit" name="submits" onclick="javascript:validate();"/>
    </div>

   </div>
  </div>
   </form>
   </div>
</div>
</div>

 </div>


 
        <script> 
      var myInput = document.getElementById("password1");
      function validate(){
    if (document.getElementById("subdistrict").selectedIndex == 0){
       alert("Select Subdistrict");
       
    }
    else {
       alert(document.getElementById("subdistrict").options[document.getElementById("subdistrict").selectedIndex].value);
    }
}
function onlyAlphabets(e, t) {
            try {
                if (window.event) {
                    var charCode = window.event.keyCode;
                }
                else if (e) {
                    var charCode = e.which;
                }
                else { return true; }
                if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123))
                    return true;
                else
                    return false;
            }
            catch (err) {
                alert(err.Description);
            }
        }
function userName()
	{
	     var val = document.getElementById('username').value;
	    if (!val.match(/^[A-Za-z][A-Za-z""]{3,}$/)) 
	    {	
		$("#uname_l").html(' Only Alphabets allowed with minimum 4 characters without spacing').fadeIn().delay(3000).fadeOut();
		document.getElementById('username').value = "";
		username.focus();
	
    	return true;
		}
                
                if(document.myform.username.value.search(username)==-1)
                 {
                     	$("#uname_l").html(' Invalid Character Entered').fadeIn().delay(3000).fadeOut();
                      document.getElementById('username').value = "";
		username.focus();
                      
                      return false;
                    }
                           var x = document.getElementById('username').value;
                if(document.myform.username.value.count(username)<=11)
		{
                   	$("#uname_l").html('Name Must Not Exceed 11 Characters').fadeIn().delay(3000).fadeOut();
                      document.getElementById('username').value = "";
		username.focus();
                    
                   
                    return false;
                }
                
        }
    function mob()
	{

		var mbnumbr=document.getElementById('mobile').value;
     if(isNaN(mbnumbr))
     {
         confirm("****only numbers allowed");
         phone.value="";
          phone.focus();
		 return false;
     }


       		 var x = document.getElementById('mobile').value;
	 	// var x=document.mobile.value;
        	if(isNaN(x)|| x.indexOf(" ")!=-1){
              alert("Enter numeric value");
            mobile.value="";  
             mobile.focus();
            return false; }
       		 if (x.length > 10 || x.length < 10 ){
                alert("enter 10  digits"); 
                mobile.focus();
                
            return false;
          }
       // if (x.charAt(0)!="9" || x.charAt(0)!="2"){
               // alert("it should start with 9 or 2 ");
                //return false
           //}
	}
	function checkEmail()
	 {
 
     		var email = document.getElementById('email');
   		 var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

   		 if (!filter.test(email.value)) {
                     email.value="";
                     
    		alert('Please provide a valid email address');
                email.focus();
               // document.getElementById("email").addEventListener("focusin",checkemail());
   		 return false;
	 }
    }

	function CheckPassword()
	{


		var p=document.getElementById('password1').value;
		var passw=  /^[A-Za-z]\w{7,14}$/;
                var error = "";
                 var illegalChars = /[\W_]/; // allow only letters and numbers
 
                     if (p == "") {
                                error = "You didn't enter a password.\n";
                                password1.focus();
                                 alert(error);
                                    return false;
                        }
                        else if ((p.length < 7) || (p.value.length > 15)&& (p.search(/[a-zA-Z]+/)==-1) || (p.search(/[0-9]+/)==-1)) {
        error = "The password is the wrong length,minimum 8  and 15 charecter and The password must contain at least one numeral \n";
        
        alert(error);
         password1.value="";
        password1.focus();
        return false;
 
    } else if ( (p.search(/[a-zA-Z]+/)==-1) || (p.search(/[0-9]+/)==-1) ) {
        error = "The password must contain at least one numeral.\n";
                 password1.value="";
        password1.focus();
        alert(error);
        return false;
 
    } else {
        p.style.background = 'White';
    }
   return true;
}

                
		
	
	
		function pwdChek() 
		{														
			if(document.getElementById("password1").value == document.getElementById("cnpwd").value)
			{	
				return true;										
			}
			else
			{
				alert("***Password Mismatch***");
                                cnpwd.value="";
                                cnpwd.focus();
			  
					return false;
			}
		}
			                  

	
        
		


</script> 
   

 <?php
include 'component/footer.php';
?>