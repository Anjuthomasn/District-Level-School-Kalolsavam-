<?php
include 'connection.php';
$d= date("d/m/Y");

?>
