<?php
require('fpdf.php');
include '../connection.php';
include("../dbconnection.php");
$db = new DbConnection;
session_start();
if (!(isset($_SESSION['l_id']))) {
    header('location:index.php');
}

$id = $_SESSION['l_id'];
$qury="select * from kalolsavam_tb7_studentinfo  where l_id=$id";
     $a = mysqli_query($con, $qury);
     $rest=mysqli_fetch_array($a);
     $student_id=$rest['student_id'];
     $school=$rest['sclist_id'];
  
$qry="SELECT * FROM kalolsavam_tb12_registerd_program as pg,kalolsavam_tb11_program_list as lis,kalolsavam_tb7_studentinfo as stud,kalolsavam_tb5_schoollist sc,kalolsavam_tb13_chestno as ch where pg.student_id=$student_id AND stud.student_id=$student_id AND sc.sclist_id=$school AND pg.pgm_list_id=lis.pgm_list_id AND pg.pgm_reg_id=ch.pgm_reg_id";
$ex= mysqli_query($con,$qry);
$row=mysqli_fetch_array($ex);
$name=$row["name"];
$img=$row["image"];
$sc=$row["school"];
$section=$row["section"];
$gender=$row["gender"];
$sd=$row["sdt_id"];
$qr2="SELECT * FROM kalolsavm_tb4_subdistrict where sdt_id=$sd ";
$ex2= mysqli_query($con,$qr2);
$row2=mysqli_fetch_array($ex2);
$subdt=$row2["subdistrict"];
$path = '../uploads/';
$imgs=$path.$img;
class PDF extends FPDF
{
// Page header
function Header()
{
    // Logo
    $this->Image('logo.png',5,6,30);
    // Arial bold 15
    $this->SetFont('Arial','B',15);
    // Move to the right
    $this->Cell(80);
    // Title
    $this->Cell(30,10,'IDENTIFICATION CERTIFICATE',0,0,'C');
    // Line break
    $this->Ln(20);
}

// Page footer
function Footer()
{
    // Position at 1.5 cm from bottom
    $this->SetY(-15);
    // Arial italic 8
    $this->SetFont('Arial','I',8);
    // Page number
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}

}

// Instanciation of inherited class
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Times','',12);
$pdf->Image($imgs,130,20,50,40);
$pdf->Cell(0,10,'',0,1);
$pdf->Cell(0,10,'',0,1);
$pdf->Cell(0,10,'',0,1);
$pdf->Cell(0,10,"                                       Name            :     $name",0,1);
$pdf->Cell(0,10,"                                       School          :     $sc",0,1);
$pdf->Cell(0,10,"                                       Subdistrict    :     $subdt",0,1);
$pdf->Cell(0,10,"                                       Section         :     $section",0,1);
$pdf->Cell(0,10,"                                       Gender         :     $gender",0,1);
//for($i=1;$i<=40;$i++)
//$pdf->Cell(0,10,'Srl.No',1,1,'C');
//$pdf->Cell(0,10,'Item',1,0,'C');

//$pdf->Cell(50,10,"PROGRAM",1,0,'C');
//$pdf->Cell(50,10,"CHEST_NO",1,1,'C');

$pdf->Cell(0,10,'',0,1);
$pdf->Cell(0,10,'',0,1);
$width_cell=array(50,50,50);
$pdf->SetFillColor(193,229,252); // Background color of header 
// Header starts /// 

$pdf->Cell($width_cell[0],10,'Sl.No',1,0,'C',true); // First header column 
$pdf->Cell($width_cell[1],10,'PROGRAM',1,0,'C',true); // Second header column
$pdf->Cell($width_cell[2],10,'CHEST NUMBER',1,1,'C',true); // Third header column 
//// header is over ///////
$i=1;
//$det= mysqli_query($con,"SELECT * FROM `kalolsavam_tb12_registerd_program` where student_id=");
while ($row3 = mysqli_fetch_array($ex)) {
  $pgm=$row3["item"];
  $chestno=$row3["chest_no"];
  $pdf->Cell($width_cell[0],10,"$i",1,0,'C',true); // First header column 
$pdf->Cell($width_cell[1],10,"$pgm",1,0,'C',true); // Second header column
$pdf->Cell($width_cell[2],10,"$chestno",1,1,'C',true); // Third header column 

$i++;
}
$pdf->Output();



?>
<!-- shuffle($photos) -->