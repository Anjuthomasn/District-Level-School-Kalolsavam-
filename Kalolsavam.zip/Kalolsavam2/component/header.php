<?php

include 'connection.php';
session_start();
if (isset($_POST['submit']))
{
   //echo"hai";
   $username=$_POST["username"];   //username value from the form
   $pass=$_POST["psw"];
   $password=md5($_POST["psw"]);
   $un="SELECT `username`,`password` FROM `kalolsavam_tb1_login` WHERE `username`='$username' and password='$password' or password='$pass'";
         $r1=mysqli_query($con,$un);
         $row=mysqli_fetch_array($r1);
 $rr1=$row["username"];
 $rr2=$row["password"];
 if ($rr1!=$username && $rr2!=$password )
 {
     echo"<script>alert('Username or password is wrong ');</script>)";
 }
 else {
     
//password value from the form
   $sql="select * from kalolsavam_tb1_login where username='$username' and password='$password' or password='$pass'or password='$pass'"; //value querried from the table
         //echo $sql;
   $res=mysqli_query($con,$sql); 
   //query executing function

   if($res)
   {
     if($fetch=mysqli_fetch_array($res)) // role means user , for admin set to 0 and for user set to
     {
      		if($fetch['role']==0 AND $fetch['status']==1)   
		{
			 $_SESSION['l_id']=$fetch['l_id'];	// setting username as session variable
                  header("location:adminhome.php");	//home page or the dashboard page to be redirected
            	}

     else if($fetch['role']==1 AND $fetch['status']==1) // role means user , for admin set to 0 and for user set to
     {
       $_SESSION['l_id']=$fetch['l_id'];	// setting username as session variable
                  header("location:sdhome.php");	//home page or the dashboard page to be redirected
      }

  else if($fetch['role']==2 AND $fetch['status']==1) // role means user , for admin set to 0 and for user set to
     {
       $_SESSION['l_id']=$fetch['l_id'];	// setting username as session variable
                  header("location:schome.php");	//home page or the dashboard page to be redirected
      }
        else if($fetch['role']==3 AND $fetch['status']==1) // role means user , for admin set to 0 and for user set to
     {
       $_SESSION['l_id']=$fetch['l_id'];	// setting username as session variable
                  header("location:stagemgrhome.php");	//home page or the dashboard page to be redirected
      }
      else if($fetch['role']==4 AND $fetch['status']==1) // role means user , for admin set to 0 and for user set to
     {
       $_SESSION['l_id']=$fetch['l_id'];	// setting username as session variable
                  header("location:studentprofile.php");	//home page or the dashboard page to be redirected
      }
      
      }
     


      }
	else
	{
             echo"<script>window.alert('Username or password is wrong ');</script>)";
	}
 }
	
}

?>
<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <title>District Level School Kalolsavam</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="" name="keywords">
        <meta content="" name="description">

        <!-- Favicons -->
        <link href="img/logo.png" rel="icon">
        <link href="img/logo.png" rel="apple-touch-icon">

        <!-- Google Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800" rel="stylesheet">

        <!-- Bootstrap CSS File -->
        <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

        <!-- Libraries CSS Files -->
        <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <link href="lib/animate/animate.min.css" rel="stylesheet">
        <link href="lib/venobox/venobox.css" rel="stylesheet">
        <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
<link rel="stylesheet" href="plugins/bootstrap/bootstrap.min.css">
        <!-- Main Stylesheet File -->
        <link href="css/style.css" rel="stylesheet">

        <!-- =======================================================
          Theme Name: TheEvent
          Theme URL: https://bootstrapmade.com/theevent-conference-event-bootstrap-template/
          Author: BootstrapMade.com
          License: https://bootstrapmade.com/license/
        ======================================================= -->
        
       
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
<link href="css/reg.css" rel="stylesheet">
<!--
 <link rel="stylesheet" type="text/css" href="validation/oh-autoVal-style.css">
 <link rel="stylesheet" type="text/css" href="https://rawgit.com/ozonhub/oh-autoVal/master/css/oh-autoval-style.css">
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"> </script>
<script type="text/javascript" src="https://rawgit.com/ozonhub/oh-autoVal/master/js/oh-autoval-script.js"></script>

  <link rel="stylesheet" type="text/css" href="https://rawgit.com/ozonhub/oh-autoVal/master/css/oh-autoval-style.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"> </script>
    <script src="https://rawgit.com/ozonhub/oh-autoVal/master/js/oh-autoval-script.js"></script>-->
    

    </head>

    <body>

        <!--==========================
          Header
        ============================-->
        <header id="header">
            <div class="container">

                <div id="logo" class="pull-left">
                    <!-- Uncomment below if you prefer to use a text logo -->
                    <!-- <h1><a href="#main">C<span>o</span>nf</a></h1>-->
                    <a href="#intro" class="scrollto"><img src="img/logo1.png" alt="" title=""></a>
                </div>

                <nav id="nav-menu-container">
                    <ul class="nav-menu">
                        <li class="menu-active"><a href="index.php">HOME</a></li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true"> <span class="nav-label">SIGNUP</span> <span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li><a href="sd_signup.php">SUBDISTRICT</a></li>
                                <li><a href="sc_signup.php">SCHOOL</a></li>
                                <li><a href="stage_signup.php">STAGE</a></li>
                                <li><a href="st_signup.php">STUDENT</a></li>


                            </ul>
                        </li>
                        <!-- <li class="buy-tickets"><button onclick="document.getElementById('id01').style.display='block'" style="width:auto;">LOGIN</button></li> -->
                       <li> <a class="text-uppercase text-color p-sm-2 py-2 px-0 d-inline-block" href="#" data-toggle="modal" data-target="#loginModal">login</a> </li>
                    </ul>
                </nav><!-- #nav-menu-container -->
            </div>
        </header><!-- #header -->


<!-- Modal -->
<div class="modal fade" id="loginModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content rounded-0 border-0 p-4">
            <div class="modal-header border-0">
               <center> <h3>LOGIN</h3></center>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form  class="row" method="post">
                    <div class="col-12">
                        <input type="text" class="form-control mb-3" id="loginName" name="username" placeholder="User Name" required>
                    </div>
                    <div class="col-12">
                        <input type="password" class="form-control mb-3" id="loginPassword" name="psw" placeholder="Password" required>
                    </div>
                    <div class="col-12">
                        <button type="submit" name="submit" class="btn btn-primary">LOGIN</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


        <a href="#" class="back-to-top"><i class="fa fa-angle-up"></i></a>

        <!-- JavaScript Libraries -->
        <script src="lib/jquery/jquery.min.js"></script>
        <script src="lib/jquery/jquery-migrate.min.js"></script>
        <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="lib/easing/easing.min.js"></script>
        <script src="lib/superfish/hoverIntent.js"></script>
        <script src="lib/superfish/superfish.min.js"></script>
        <script src="lib/wow/wow.min.js"></script>
        <script src="lib/venobox/venobox.min.js"></script>
        <script src="lib/owlcarousel/owl.carousel.min.js"></script>

        <!-- Contact Form JavaScript File -->
        <script src="contactform/contactform.js"></script>

        <!-- Template Main Javascript File -->
        <script src="js/main.js"></script>