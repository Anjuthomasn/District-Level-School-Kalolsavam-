        <!--==========================
          Footer
        ============================-->
        <br><br><br><br><br><br>
        <footer id="footer">
            <div class="footer-top">
                <div class="container">
                    <div class="row">

                        <div class="col-lg-3 col-md-6 footer-info">
                            <img src="img/logo.png" alt="TheEvenet">
                        </div>

                        <div class="col-lg-3 col-md-6 footer-links">
                            <h4>Useful Links</h4>
                            <ul>
                                <li><i class="fa fa-angle-right"></i> <a href="index.php">Home</a></li>
                                <li><i class="fa fa-angle-right"></i> <a href="index.php">About us</a></li>
                                <li><i class="fa fa-angle-right"></i> <a href="#">Services</a></li>
                                <li><i class="fa fa-angle-right"></i> <a href="#">Terms of service</a></li>
                                <li><i class="fa fa-angle-right"></i> <a href="#">Privacy policy</a></li>
                            </ul>
                        </div>

                        <div class="col-lg-3 col-md-6 footer-links">
                            <h4>Useful Links</h4>
                            <ul>
                                <li><i class="fa fa-angle-right"></i> <a href="index.php">Home</a></li>
                                <li><i class="fa fa-angle-right"></i> <a href="#">About us</a></li>
                                <li><i class="fa fa-angle-right"></i> <a href="#">Services</a></li>
                                <li><i class="fa fa-angle-right"></i> <a href="#">Terms of service</a></li>
                                <li><i class="fa fa-angle-right"></i> <a href="#">Privacy policy</a></li>
                            </ul>
                        </div>

                        <div class="col-lg-3 col-md-6 footer-contact">
                            <h4>Contact Us</h4>
                            <p>
                                Anju thomas <br>
                                
                                <strong>Phone:</strong> 9526194454<br>
                                <strong>Email:</strong> anjuthomas@gmail.com<br>
                            </p>

                            <div class="social-links">
                                <a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
                                <a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
                                <a href="#" class="instagram"><i class="fa fa-instagram"></i></a>
                                <a href="#" class="google-plus"><i class="fa fa-google-plus"></i></a>
                                <a href="#" class="linkedin"><i class="fa fa-linkedin"></i></a>
                            </div>

                        </div>

                    </div>
                </div>
            </div>

            <div class="container">
                <div class="copyright">
                   <strong></strong>
                </div>
                <div class="credits">
                    <!--
                      All the links in the footer should remain intact.
                      You can delete the links only if you purchased the pro version.
                      Licensing information: https://bootstrapmade.com/license/
                      Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=TheEvent
                    -->
                     <a href="https://bootstrapmade.com/"></a>
                </div>
            </div>
        </footer><!-- #footer -->

        <a href="#" class="back-to-top"><i class="fa fa-angle-up"></i></a>

        
         <script> 
      
                  
                   $("#subdistrict").on("change", function () {
                        $("#school").html("");
                        $dstate = $("#subdistrict").val();

                        // find courselevels
                        $.ajax({
                            url: 'data/data.php',
                            method: 'POST',
                            data: {'subdistrict': $dstate, "status":"1"},
                            success: function (data)
                            {
                                // console.log(data);
                                $("#school").html(data);
                            }
                        });
                    });
                
      
      function validate()
      {
            if (document.getElementById("subdistrict").selectedIndex == 0)
            {
                 alert("Select Subdistrict");
            }
             else 
            
            if (document.getElementById("school").selectedIndex == 0){
             alert("Select School");
            }
            
    
       }
        function mob()
	{

		var mbnumbr=document.getElementById('mobile').value;
                if(isNaN(mbnumbr))
                 {
                     confirm("****only numbers allowed");
                    mobile.value="";
                       mobile.focus();
		 return false;
                }


       		 var x = document.getElementById('mobile').value;
	 	// var x=document.mobile.value;
        	if(isNaN(x)|| x.indexOf(" ")!=-1)
                {
                    alert("Enter numeric value");
                    mobile.value="";
                     mobile.focus();
                    return false; }
       		 if (x.length > 10 || x.length < 10 )
                 {
                    alert("enter 10  digits"); return false;
                   mobile.value="";
                     mobile.focus(); 
                 }
       // if (x.charAt(0)!="9" || x.charAt(0)!="2"){
               // alert("it should start with 9 or 2 ");
                //return false
           //}
	}
	function checkEmail()
	 {
 
     		var email = document.getElementById('email');
   		 var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

   		 if (!filter.test(email.value))
                 {
                    alert('Please provide a valid email address');
                     email.value="";
                     email.focus();
                     return false;
                }
         }
	function userName()
	{
	      var x = document.getElementById('username').value;
               
                if((x===null)||(x.length<=1))
		{
                    
                    alert("Invalid Name");
                    username.value="";
                    username.focus();
                    return false;
                }
                var fnam=/^[a-zA-Z ]{4,25}$/;
                if(document.myform.username.value.search(username)==-1)
                 {
                      alert("Invalid Character Entered");
                        username.value="";
                      username.focus();
                      
                      return false;
                    }
                if((x>15))
		{
                   
                    alert("Name Must Not Exceed 24 Characters");
                      username.value="";
                      username.focus();
                   
                    return false;
                }
       
        }
	function CheckPassword()
	{


		var p=document.getElementById('password1').value;
		var passw=  /^[A-Za-z]\w{7,14}$/;
                var error = "";
                 var illegalChars = /[\W_]/; // allow only letters and numbers
 
                     if (p == "") {
                                error = "You didn't enter a password.\n";
                               password1.value="";
                        password1.focus();
                                 alert(error);
                                    return false;
                        }
                        else if ((p.length < 7) || (p.value.length > 15)&& (p.search(/[a-zA-Z]+/)==-1) || (p.search(/[0-9]+/)==-1)) {
        error = "The password is the wrong length,minimum 8  and 15 charecter and The password must contain at least one numeral \n";
        
        alert(error);
         password1.value="";
                        password1.focus();
        return false;
 
    } else if ( (p.search(/[a-zA-Z]+/)==-1) || (p.search(/[0-9]+/)==-1) ) {
        error = "The password must contain at least one numeral.\n";
        
        alert(error);
         password1.value="";
                        password1.focus();
        return false;
 
    } else {
        p.style.background = 'White';
    }
   return true;
	}
	
		function pwdChek() 
		{														
			if(document.getElementById("password1").value == document.getElementById("cnpwd").value)
			{	
				return true;										
			}
			else
			{
				alert("***Password Mismatch***");
                                 cnpsw.value="";
                                cnpsw.focus();
			  	document.getElementById("cnpwd").focus();
					return false;
			}
		}
			                  

	
        
		


</script> 
        
    </body>
</html>
