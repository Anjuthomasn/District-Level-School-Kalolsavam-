<?php
include 'connection.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title  -->
    <title>School Kalolsavam </title>

    <!-- Favicon  -->
    <link rel="icon" href="img/core-img/favicon.ico">

    <!-- Core Style CSS -->
    <link rel="stylesheet" href="css/core-style.css">
    <link rel="stylesheet" href="style.css">

</head>

<body>
      <?php
                    $a="select pgm.*,stud.*,pgmlist.* from kalolsavam_tb12_registerd_program as pgm,kalolsavam_tb7_studentinfo as stud,kalolsavam_tb11_program_list as pgmlist where pgm.student_id=stud.student_id  and  pgm.pgm_list_id=pgmlist.pgm_list_id";
              $ss = mysqli_query($con,$a );
               $rs=mysqli_fetch_array($ss);
               ?>
    <!-- Search Wrapper Area Start -->
    
    <!-- Search Wrapper Area End -->

    <!-- ##### Main Content Wrapper Start ##### -->
    <div class="main-content-wrapper d-flex clearfix">

        <!-- Mobile Nav (max width 767px)-->
        <div class="mobile-nav">
            <!-- Navbar Brand -->
            <div class="amado-navbar-brand">
                <a href="index.html"><img src="img/core-img/logo.png" alt=""></a>
            </div>
            <!-- Navbar Toggler -->
            <div class="amado-navbar-toggler">
                <span></span><span></span><span></span>
            </div>
        </div>

        <!-- Header Area Start -->
        <header class="header-area clearfix">
            <!-- Close Icon -->
            <div class="nav-close">
                <i class="fa fa-close" aria-hidden="true"></i>
            </div>
            <!-- Logo -->
            <div class="logo">
                <a href="../adminhome.php">School Kalolsavam</a>
            </div>
            <!-- Amado Nav -->
            <nav class="amado-nav">
                <ul>
                    <li class="active"><a href="../adminhome.php">Home</a></li>
                    <br><br>
                   <li class="active">
                       
                        <form action="#" method="get">
                           
                                  <select class="form-control" name="item" id="item" >
                           
                                      <option value=0 hidden >SELECT PROGRAM</option>
        <?php
         $con = mysqli_connect("localhost", "root", "", "kalolsavam");
                                    if (!$con) {
                                        echo "Could not connect..Try again";
                                    } else {
                                        $sdselect = "SELECT * FROM `kalolsavam_tb11_program_list` ";
                                        $sdresult = mysqli_query($con, $sdselect);
                                        //echo "";
                                        while ($sdrow = mysqli_fetch_array($sdresult)) {
                                            $stname = $sdrow['item'];
                                            $gender=$sdrow['gender'];
                                            $section=$sdrow['section'];
                                            $sid = $sdrow['pgm_list_id'];
                                            echo "<option value='$sid'>$stname - $gender - $section</option>";
                                        }
                                    }
                                    mysqli_close($con);
                                    ?>
              </select>
                            <button type="submit" width="50%"><img src="img/core-img/search.png" alt=""></button>
                        </form>
                   </li>
                </ul>
            </nav>
          
            <!-- Button Group -->
          
            <!-- Cart Menu -->
          
            <!-- Social Button -->
          
        </header>
        <!-- Header Area End -->

                 
       <!-- Product Catagories Area Start -->
        <div class="products-catagories-area clearfix">
            <div class="amado-pro-catagory clearfix">
                <?php    
           
                  while ($row = mysqli_fetch_array($ss)) {
                      
             
                ?>

                <!-- Single Catagory -->
                <div class="single-products-catagory clearfix">
                    <a href="shop.html" title="Student Details">
                       
                        <img src="../uploads/<?php echo $row['image']; ?>" alt="" height="130" width="130" >
                        <!-- Hover Content -->
                        <div class="hover-content">
                            <div class="line"></div>
                            <p><?php echo $row['name']; ?></p>
                            <h4><?php echo $row['item']; ?></h4>
                        </div>
                    </a>
                </div>

               <?php 
                    }
           
               ?>
            </div>
        </div>
    </div>
    
        <!-- Product Catagories Area End -->
   
    <!-- ##### Main Content Wrapper End ##### -->



    <!-- ##### jQuery (Necessary for All JavaScript Plugins) ##### -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Plugins js -->
    <script src="js/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>

</body>

</html>