
<?php
include 'stagemgr_header.php';
include 'connection.php';	
$id=$_SESSION['l_id'];

if (isset($_POST['ss'])) {

    $item=$_POST['item'];
   $list = "SELECT * FROM kalolsavam_tb13_chestno as ch,kalolsavam_tb12_registerd_program as pgm WHERE ch.pgm_reg_id=pgm.pgm_reg_id AND pgm.pgm_list_id=$item and pgm.status=1 ";
    $results = mysqli_query($con,$list);
}

if (isset($_POST['result'])) {
    $item=$_POST['item'];
     $studentid=$_POST['studentid'];
     $chestno=$_POST['ch'];
    $mark=$_POST['mark'];
    $grade=$_POST['grade'];
    $ap="attented";
    $regid=$_POST['regid'];
    $u="UPDATE `kalolsavam_tb12_registerd_program` SET `status`=2 WHERE pgm_reg_id=$regid";
    $u2=mysqli_query($con,$u);
    $ex=mysqli_query($con,"SELECT * FROM `kalolsavam_tb7_studentinfo` where student_id=$studentid");
      $qryt="INSERT INTO `kalolsavam_tb20_result`(`chest_no`, `pgm_list_id`, `student_id`, `mark`, `grade`, `status`) VALUES ($chestno,$item,$studentid,$mark,'$grade','$ap')";
  $qry2=mysqli_query($con,$qryt);
    $qry3="SELECT * FROM `kalolsavam_tb7_studentinfo` where student_id=$studentid";
  $r3 = mysqli_query($con,$qry3);
  $row3 = mysqli_fetch_array($r3);
  $sd=$row3['sdt_id']; 
  $sc=$row3['sclist_id'];
  $stud_id=$row3['student_id'];
  //subdistrict calculation
  $search="SELECT * FROM `kalolsavam_tb21_subdistrictresult` WHERE sdt_id=$sd";
  $sre=mysqli_query($con,$search);
     if(mysqli_num_rows($sre) < 1)
     {
      $update=mysqli_query($con,"INSERT INTO `kalolsavam_tb21_subdistrictresult`( `sdt_id`, `mark`) VALUES ($sd,$mark)");   
     }
 else {
     $rs=mysqli_fetch_array($sre); 
     $crntmark=$rs['mark']; 
     $total=$crntmark+$mark;
     $update=mysqli_query($con,"UPDATE `kalolsavam_tb21_subdistrictresult` SET `mark`=$total WHERE sdt_id=$sd " );
     }
     //school calculation
      $search2="SELECT * FROM `kalolsavam_tb22_schoolresult` WHERE sclist_id=$sc";
  $sre2=mysqli_query($con,$search2);
     if(mysqli_num_rows($sre2) < 1)
     {
      $update2=mysqli_query($con,"INSERT INTO `kalolsavam_tb22_schoolresult`( `sclist_id`, `mark`) VALUES ($sc,$mark)");   
     }
 else {
     $rs2=mysqli_fetch_array($sre2); 
     $crntmark2=$rs['mark']; 
     $total2=$crntmark2+$mark;
     $update2=mysqli_query($con,"UPDATE `kalolsavam_tb22_schoolresult` SET `mark`=$total2 WHERE sclist_id=$sc " );
     }
     //idividual mark calculation
      $search3="SELECT * FROM `kalolsavam_tb23_individualresult` WHERE student_id=$stud_id";
  $sre3=mysqli_query($con,$search3);
     if(mysqli_num_rows($sre3) < 1)
     {
      $update3=mysqli_query($con,"INSERT INTO `kalolsavam_tb23_individualresult`( `student_id`, `mark`) VALUES ($stud_id,$mark)");   
     }
 else {
     $rs3=mysqli_fetch_array($sre3); 
     $crntmark3=$rs['mark']; 
     $total3=$crntmark3+$mark;
     $update3=mysqli_query($con,"UPDATE `kalolsavam_tb23_individualresul` SET `mark`=$total2 WHERE student_id=$stud_id " );
     }
$list = "SELECT * FROM kalolsavam_tb13_chestno as ch,kalolsavam_tb12_registerd_program as pgm WHERE ch.pgm_reg_id=pgm.pgm_reg_id AND pgm.pgm_list_id=$item  and pgm_status=1";
    $results = mysqli_query($con,$list);
    
    
}

if (isset($_POST['notatt'])) {
    $item=$_POST['item'];
     $studentid=$_POST['studentid'];
     $chestno=$_POST['ch'];
    $mark=0;
    $grade="F";
    $ap="Not attented";
      $qryt="INSERT INTO `kalolsavam_tb20_result`(`chest_no`, `pgm_list_id`, `student_id`, `mark`, `grade`, `status`) VALUES ($chestno,$item,$studentid,$mark,'$grade','$ap')";
  $qry2=mysqli_query($con,$qryt);
  
$list = "SELECT * FROM kalolsavam_tb13_chestno as ch,kalolsavam_tb12_registerd_program as pgm WHERE ch.pgm_reg_id=pgm.pgm_reg_id AND pgm.pgm_list_id=$item and pgm_status=1 ";
    $results = mysqli_query($con,$list);
    
}
if (isset($_POST['dis'])) {
    $item=$_POST['item'];
     $studentid=$_POST['studentid'];
     $chestno=$_POST['ch'];
    $mark=0;
    $grade=F;
    $ap="qisqualify";
      $qryt="INSERT INTO `kalolsavam_tb20_result`(`chest_no`, `pgm_list_id`, `student_id`, `mark`, `grade`, `status`) VALUES ($chestno,$item,$studentid,$mark,'$grade','$ap')";
  $qry2=mysqli_query($con,$qryt);
$list = "SELECT * FROM kalolsavam_tb13_chestno as ch,kalolsavam_tb12_registerd_program as pgm WHERE ch.pgm_reg_id=pgm.pgm_reg_id AND pgm.pgm_list_id=$item and pgm.status=1";
    $results = mysqli_query($con,$list);
    
}
        ?> 
<center>
<table class="container" >
               
              
                <tr>

                    <th>CHESTNO</th>

                    <th>MARK</th>

                    <th>GRADE</th><th></th><th></th><th></th><th></th>
                    <th>RESULTS</th>
                    <th>DISQUALIFY/ NOT ATTEND</th>




                </tr>
<?php
while ($row = mysqli_fetch_array($results)) {
    ?>    <form  method="post" name="form2" action="#">

                        <tr>

                            <td><input class="txt" type="text" name="chestno" id="sdt"  value="<?php echo $row['chest_no']; ?>"  disabled /></td>
                            <td><input class="txt" type="number" name="mark" required ></td>
                            <td><input class="txt" type="text" name="grade" required></td>  
                         <td><input  type="hidden" name="item" value="<?php echo $row['pgm_list_id']; ?>" ></td>
                         <td><input  type="hidden" name="studentid" value="<?php echo $row['student_id']; ?>" ></td>
                         <td><input  type="hidden" name="regid" value="<?php echo $row['pgm_reg_id']; ?>" ></td>
                         <td><input  type="hidden" name="ch" value="<?php echo $row['chest_no']; ?>" ></td>
                         <td>
     <input type="submit" class="btn btn--form" align="center" name="result" id="pin" value="RESULT"></td>
                         <td> <input type="submit" class="btn btn--form" align="center" name="notatt" id="pin" value="NOT ATTENT">
                             <input type="submit" class="btn btn--form" align="center" name="dis" id="pin" value="DISQUALIFY">
                         </td>

                        </tr>
    </form>
     
                    <?php
                }
                ?>
    </form>
            </table>
        
        <?php 
        


        ?>

</center>
<?php
if (isset($_POST['result'])) {
    
}
 ?>
