
<?php
include 'stagemgr_header.php';
include 'connection.php';	
$id=$_SESSION['l_id'];
$qry="select * from kalolsavam_tb8_stagelist as st,kalolsavam_tb9_stagemgr_info as info where info.l_id=$id and st.stge_id=info.stge_id";
     $ans = mysqli_query($con, $qry);
     $r=mysqli_fetch_array($ans);
     $stgnm=$r['stage_name'];
     $stid=$r['stge_id'];
?>
<br><br>
        <div class="signup__container">

            <div class="container__child signup__form">

                <form id="search-form"  method="post"  name="form1" action="stagemgr_addresultlist.php">
                       
                     <div class="form-group">
                         <br><br>     
                          <select class="form-control" name="item" id="item" >
                           
                              <option value=0 hidden="" >SELECT PROGRAM</option>
        <?php
         $con = mysqli_connect("localhost", "root", "", "kalolsavam");
                                    if (!$con) {
                                        echo "Could not connect..Try again";
                                    } else {
                                        $sdselect = "SELECT li.* FROM kalolsavam_tb11_program_list as li,kalolsavam_tb14_stage_events ev where ev.stage_id=$stid and ev.pgm_list_id=li.pgm_list_id ";
                                        $sdresult = mysqli_query($con, $sdselect);
                                        //echo "";
                                        while ($sdrow = mysqli_fetch_array($sdresult)) {
                                            $stname = $sdrow['item'];
                                            $gender=$sdrow['gender'];
                                            $section=$sdrow['section'];
                                            $sid = $sdrow['pgm_list_id'];
                                            echo "<option value='$sid'>$stname - $gender - $section</option>";
                                        }
                                    }
                                    mysqli_close($con);
                                    ?>
              </select>
                        <label style="display:none ; color:red"  id="mails"></label>

                        <br>
                    <div class="m-t-lg">
                        <ul class="list-inline">
                            <li>
                               <input type="submit" class="btn btn--form" align="center" name="ss" id="pin" value="VIEW STUDENT LIST">


                            </li>

                        </ul>
                    </div>
 </div>

                </form>
           
        </div>
        </div>
<?php
if (isset($_POST['ss'])) {
  $item=$_POST['item'];
   $list = "SELECT ch.chest_no FROM kalolsavam_tb13_chestno as ch,kalolsavam_tb12_registerd_program as pgm WHERE ch.pgm_reg_id=pgm.pgm_reg_id AND pgm.pgm_list_id=$item";
    $results = mysqli_query($con,$list);

        ?>    
<center>
    <form  method="post" name="form2">
<table class="container" >
               
              
                <tr>

                    <th>CHESTNO</th>

                    <th>MARK</th>

                    <th>GRADE</th>
                    <th>RESULTS</th>
                    <th>DISQUALIFY/ NOT ATTEND</th>




                </tr>
<?php
while ($row = mysqli_fetch_array($results)) {
    ?>
                        <tr>

                            <td><input class="txt" type="text" name="chestno" id="sdt"  value="<?php echo $row['chest_no']; ?>"  disabled /></td>
                            <td><input class="txt" type="number" name="mark"  ></td>
                         <td><input class="txt" type="text" name="grade" ></td>
                         <td>
     <input type="submit" class="btn btn--form" align="center" name="reslut" id="pin" value="RESULT"></td>
                         <td> <input type="submit" class="btn btn--form" align="center" name="reslut" id="pin" value="NOT ATTENT">
                             <input type="submit" class="btn btn--form" align="center" name="reslut" id="pin" value="DISQUALIFY">
                         </td>

                        </tr>
     
                    <?php
                }
                ?>
            </table>
        </form>
        <?php 
        
} 

        ?>

</center>

