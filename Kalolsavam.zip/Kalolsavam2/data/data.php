//select ddistrict on dstate
<?php
 $con = mysqli_connect("localhost", "root", "", "kalolsavam");

if(isset($_POST['status'])&&$_POST['status']=="1")
{
  $dstate = $_POST['subdistrict'];
  $query = "SELECT `sclist_id`,`school` FROM `kalolsavam_tb5_schoollist` WHERE `sdt_id` = '$dstate' AND `sts` = '1'";
  $result=mysqli_query($con,$query);
  echo "<option  >SELECT SCHOOL  </option>";
  while($row=mysqli_fetch_array($result))
  {
    echo "<option value='".$row['sclist_id']."'>".$row['school']."</option>";
  }

}
?>



