//select ddistrict on dstate
<?php
 $con = mysqli_connect("localhost", "root", "", "kalolsavam");

if(isset($_POST['status'])&&$_POST['status']=="1")
{
  $dstate = $_POST['subdistrict'];
  $query = "SELECT * FROM `kalolsavam_tb11_program_list`  WHERE `pgm_list_id = '$dstate' ";
  $result=mysqli_query($con,$query);
  echo "<option  >SELECT  </option>";
  while($row=mysqli_fetch_array($result))
  {
    echo "<option value='".$row['pgm_lis_id']."'>".$row['section']."</option>";
  }

}
?>




