<?php
include 'connection.php';
?>
<html>
    <head>
        <script src="js/jquery.min.js"> </script>
<script type="text/javascript" language="javascript">

$( document ).ready(function() {

$('.item').change(function () {
    var id =  $(this).val();
   
    $.ajax({
        type: 'POST',
        url: 'getres.php',
        data: {
            'id': id
        },
        success: function (data) {
            // the next thing you want to do 
            $(list).html(data);
            }

            
        
    });

});
});



    </script>

    </head>
    <body>
                     <select class="form-control" name="item" id="item" >
                           
                              <option value=0 hidden="" >SELECT PROGRAM</option>
        <?php
         $con = mysqli_connect("localhost", "root", "", "kalolsavam");
                                    if (!$con) {
                                        echo "Could not connect..Try again";
                                    } else {
                                        $sdselect = "SELECT li.* FROM kalolsavam_tb11_program_list as li,kalolsavam_tb14_stage_events ev where ev.stage_id=1 and ev.pgm_list_id=li.pgm_list_id ";
                                        $sdresult = mysqli_query($con, $sdselect);
                                        //echo "";
                                        while ($sdrow = mysqli_fetch_array($sdresult)) {
                                            $stname = $sdrow['item'];
                                            $gender=$sdrow['gender'];
                                            $section=$sdrow['section'];
                                            $sid = $sdrow['pgm_list_id'];
                                            echo "<option value='$sid'>$stname - $gender - $section</option>";
                                        }
                                    }
                                    mysqli_close($con);
                                    ?>
              </select>
    </body>
</html>