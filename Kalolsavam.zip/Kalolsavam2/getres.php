<?php
include 'connection.php';

$id=$_POST["id"];
 $list = "SELECT ch.chest_no FROM kalolsavam_tb13_chestno as ch,kalolsavam_tb12_registerd_program as pgm WHERE ch.pgm_reg_id=pgm.pgm_reg_id AND pgm.pgm_list_id=$id";
    $results = mysqli_query($con,$list);
?>
<center>
    <form  method="post" name="form2">
<table class="container" >
               
              
                <tr>

                    <th>CHESTNO</th>

                    <th>MARK</th>

                    <th>GRADE</th>
                    <th>RESULTS</th>
                    <th>DISQUALIFY/ NOT ATTEND</th>




                </tr>
<?php
while ($row = mysqli_fetch_array($results)) {
    ?>
                        <tr>

                            <td><input class="txt" type="text" name="chestno" id="sdt"  value="<?php echo $row['chest_no']; ?>"  disabled /></td>
                            <td><input class="txt" type="number" name="mark"  ></td>
                         <td><input class="txt" type="text" name="grade" ></td>
                         <td>
     <input type="submit" class="btn btn--form" align="center" name="reslut" id="pin" value="RESULT"></td>
                         <td> <input type="submit" class="btn btn--form" align="center" name="reslut" id="pin" value="NOT ATTENT">
                             <input type="submit" class="btn btn--form" align="center" name="reslut" id="pin" value="DISQUALIFY">
                         </td>

                        </tr>
     
                    <?php
                }
                ?>
            </table>
        </form>
      

</center>