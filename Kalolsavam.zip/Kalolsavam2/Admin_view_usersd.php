
<?php
include 'connection.php';
session_start();
if (!(isset($_SESSION['l_id'])) ) {
    header('location:index.php');
}

$id = $_SESSION['l_id'];
?>
<!DOCTYPE html>
<html>
    <head>
        <title>School Kalolsavam</title>

        <!-- meta -->
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- css -->
        <link rel="stylesheet" href="users/css/bootstrap.min_2.css">
        <link rel="stylesheet" href="users/css/ionicons.min.css">
        <link rel="stylesheet" href="users/css/font-awesome.min.css">
        <link rel="stylesheet" href="users/css/owl.carousel.css">
        <link rel="stylesheet" href="users/css/owl.theme.css">
        <link rel="stylesheet" href="users/css/owl.transitions.css">
        <link rel="stylesheet" href="users/css/animate.css">
        <link rel="stylesheet" href="users/css/custom.css">

        <!-- js -->
        <script src="users/js/jquery.min.js"></script>
        <script src="users/js/bootstrap.min.js"></script>
        <script src="users/js/owl.carousel.min.js"></script>
        <script src="users/js/isotope.pkgd.min.js"></script>
        <script src="users/js/script.js"></script>
        <script src="users/js/wow.min.js"></script>
        <script src="users/js/jquery.actual.min.js"></script>

        <link rel="stylesheet" href="css2/style2.css">


        <style>
            table {
               background-color: white;
            }

            th, td {
                text-align: left;
                padding: 8px;
                font-size: 14px;
                font-weight: bold;
            }

            tr:nth-child(even){background-color: #f2f2f2}

            th {
                color: black;
                font-size: 16px;
                font-family: helvetica;
                font-weight: bolder;
            }
        </style>

    </head>

    <body>
        <div id="wrapper">


            <section id= "navigation">
                <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
                    <div class="container-fluid">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                                <span class="ion-navicon"></span>
                            </button>
                            <a class="navbar-brand" href="#">School Kalolsavam </a>
                        </div>
                        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                <ul class="nav navbar-nav navbar-right">
                                    <li><a href="adminhome.php">HOME</a></li>
                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true"> <span class="nav-label">ADD</span> <span class="caret"></span></a>
                                        <ul class="dropdown-menu">
                                            <li><a href="Admin_add_subdistrict.php">ADD SUBDISTRICT</a></li>
                                            <li><a href="Admin_add_program.php">ADD PROGRAM LIST</a></li>
                                            <li> <a href="mails/Admin_add_stagedetails.php">ADD STAGE DETAILS</a></li>



                                        </ul>
                                    </li>

                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true"> <span class="nav-label">BLOCK/UNBLOCK USERS</span> <span class="caret"></span></a>
                                        <ul class="dropdown-menu">
                                            <li><a href="Admin_view_usersd.php">SUBDISTRICT COORDINATOR</a></li>
                                            <li><a href="Admin_view_usersc.php">SCHOOL COORDINATOR</a></li>
                                            <li><a href="Admin_view_userstage.php">STAGE MANAGERS</a></li>



                                        </ul>
                                    </li>
                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true"> <span class="nav-label">VIEW & UPDATE </span> <span class="caret"></span></a>
                                        <ul class="dropdown-menu">
                                            <li><a href="Admin_view_program.php">PROGRAM LIST</a></li>
                                           


                                        </ul>
                                    </li>

                                     <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true"> <span class="nav-label">CHEST NUMBER</span> <span class="caret"></span></a>
                                    <ul class="dropdown-menu">
                                        <li><a href="Admin_chestnogenerate.php">GENERATE CHEST NUMBER</a></li>
                                        <li><a href="Admin_view_chestno.php">VIEW CHEST NUMBER</a></li>
                                        
                                    



                                    </ul>
                                </li>
                                    
                                    <li><a href="logout.php">LOGOUT</a></li>
                                </ul>
                            </div>

                    </div>	<!-- container-fluid -->
                </nav>

                <!-- navbar -->
            </section>	<!-- #navigation -->

            <div class="row text-center" id="heading">
                <div class="col-md-6 col-md-offset-3 wow animated zoomInDown" id="heading-text">
                    <h3 >SUBDISTRICT COORDINATORS USERS</h3>
                    <hr class="full">
                    <br/>
                </div>
               

                <div style="margin-left: 400px;max-width: 200px;">
<?php
if (isset($_POST['delete'])) {

    $lns = $_POST["l_id"];

    $sql2 = "UPDATE `kalolsavam_tb1_login` SET `status`=0 WHERE `l_id`=$lns and role=1 ";
    $result2 = mysqli_query($con, $sql2);
   
    if($result2)
    {
         echo"<script> alert('Blocking successfull')
                         window.location.href = 'Admin_view_usersd.php';</script>";
    }
//    echo "<script> alert('Blocking successfull');</script>";
//    header("location:Admin_view_usersd.php");
}
?> 
                              
<?php
$an="select l.l_id,s.sdt_id,u.email,u.phone,su.subdistrict from kalolsavam_tb1_login as l,kalolsavam_tb2_user as u,kalolsavam_tb10_subdistrct_info as s,kalolsavm_tb4_subdistrict as su where l.l_id=u.l_id and l.l_id=s.l_id and u.user_id=s.user_id and l.role=1 and l.status=1 and s.sdt_id=su.sdt_id";
$aa=mysqli_query($con,$an);
$a2=mysqli_fetch_array($aa);
$a3=$a2['sdt_id'];
//$ba=mysqli_query($con,"select * from kalolsavam_tb6_schoolinfo where l_id=$id");
//$b2=mysqli_fetch_array($ba);
//$b3=$a2['sclist_id'];

 $q="select * from kalolsavam_tb1_login where role=1 and status=1 ";
$display = mysqli_query($con,$q);
if(mysqli_num_rows($aa) >= 1)
{ ?>
                      <center>    <table border="10%"  width="50%">
                        

                            <th>Subdistrict</th>
                            <th>Mail id</th>
                            <th>Mobile Number</th>

                            <th></th>
                            <th>Block</th>
                        </tr>
                        <?php
         
while ($row = mysqli_fetch_array($aa)) {
    ?><form  method="post">
                                <tr>

                                    <td><?php echo $row['subdistrict']; ?></td>
                                    <td><?php echo $row['email']; ?></td>
                                    <td><?php echo $row['phone']; ?></td>

                                    <td><input class="txt" type="hidden" name="l_id" value="<?php echo $row['l_id']; ?>"></td>
                                    <td><input type="submit" name="delete" class="btn btn-inverse large" value="BLOCK"></td>


                                </tr></form>
    <?php
} ?> </table> </center> 
<?php
}
 else{ ?>
                        <center> <br><br><br><br><br><br><br><br>
                        <label style="color:white;font-size:18px" >NO ONE UNBLOCKED/ REGISTERD</label>
                        <br><br><br><br><br><br><br><br>><br><br><br><br></center>
      
    
<?php }

?>
                    

                </div>
                <br><br>  <br><br>
                <center><h1><a href="#unblock">UNBLOCK</a></h1></center>

                <br><br>  <br><br>   <br><br>  <br><br>  <br><br>  <br><br>  <br><br>  <br><br>  <br><br>
                <section id="unblock">
                    <div style="margin-left: 400px;max-width: 200px;">
                        <div class="col-md-6 col-md-offset-3 wow animated zoomInDown" id="heading-text">
                            <h3>UnBlock</h3>
                            <hr class="full">
                            <br/>
                        </div>
<?php
$bn="select l.l_id,s.sdt_id,u.email,u.phone,su.subdistrict from kalolsavam_tb1_login as l,kalolsavam_tb2_user as u,kalolsavam_tb10_subdistrct_info as s,kalolsavm_tb4_subdistrict as su where l.l_id=u.l_id and l.l_id=s.l_id and u.user_id=s.user_id and l.role=1 and l.status=0 and s.sdt_id=su.sdt_id ";
$ba=mysqli_query($con,$bn);
$b2=mysqli_fetch_array($ba);
$b3=$a2['sdt_id'];
//$qry="select * from login,role where login.role_id=role.role_id";
$qry = "select * from kalolsavam_tb1_login where role=1 and status=0";
$res = mysqli_query($con, $qry);
if (isset($_POST['add'])) {

    $l = $_POST["userid"];
    

    $sql3 = "UPDATE `kalolsavam_tb1_login` SET `status`=1 WHERE `l_id`=$l and role=1";
    $result3 = mysqli_query($con, $sql3);
  if($result3)
  {
      echo"<script> alert('UnBlocking successfull')
                         window.location.href = 'Admin_view_usersd.php';</script>";
  }
}
?>
                        <?php if(mysqli_num_rows($res)>=1)
                        { ?>
   
                        <table >
                            <tr>
                                <td >&nbsp;</td>
                                <td >
                            <tr>

                                <th>Subdistrict</th>
                                <th>Mail Id</th>
                                <th>Mobile Number</th>

                                <th></th>
                                <th></th>

                            </tr>
<?php
while ($rown = mysqli_fetch_array($ba)) {
    ?><form action="#" method="post">
                                    <tr>

                                        <td><?php echo $rown['subdistrict']; ?></td>
                                        <td><?php echo $rown['email']; ?></td>
                                        <td><?php echo $rown['phone']; ?></td>
                                        <td><input class="txt" type="hidden" name="userid" value="<?php echo $rown['l_id']; ?>"></td>
                                        <td><input type="submit" name="add" class="btn btn-inverse large" value="UNBLOCK"></td>


                                    </tr></form>
    <?php
} ?>  </table>
 <?php }
 else {
 ?>  <br><br><br><br><br><br><br><br>
                   <center>     <label style="color:white;font-size:18px" >NO ONE BLOCKED</label></center>
                        <br><br><br><br><br><br><br><br>><br><br><br><br>
  <?php }
 
?>
                       

                    </div>
               
                </section>
                 <center><h1><a href="#heading">BLOCK</a></h1></center>


              




                </p>

                <br><br>  <br><br>  <br><br>  <br><br>  <br><br>  <br><br>
            </div>


            <br><br>  <br><br>  <br><br>  <br><br>  <br><br>  <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br>




            <br><br>  <br><br>  <br><br>  <br><br>  <br><br>  <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br>
            <!-- footer -->
            <section id= "footer" class= "main-footer">
                <div class= "row">
                    <div class= "logo text-center">
                        <h1>School Kalolsavam</h1>
                    </div>
                </div>
                <div class= "row">
                    <div class= "copyright text-center">
                    </div>
                </div>
            </section><!-- footer -->

            <!-- js -->
            <script>
                $(document).ready(function () {
                    $("#client-speech").owlCarousel({
                        autoPlay: 3000,
                        navigation: false, // Show next and prev buttons
                        slideSpeed: 700,
                        paginationSpeed: 1000,
                        singleItem: true
                    });
                });
            </script>
            <script>
                new WOW().init();
            </script>
            <script>
                $(function () {
                    // init Isotope
                    var $container = $('.isotope').isotope
                            ({
                                itemSelector: '.element-item',
                                layoutMode: 'fitRows'
                            });


                    // bind filter button click
                    $('#filters').on('click', 'button', function ()
                    {
                        var filterValue = $(this).attr('data-filter');
                        // use filterFn if matches value
                        $container.isotope({filter: filterValue});
                    });

                    // change is-checked class on buttons
                    $('.button-group').each(function (i, buttonGroup)
                    {
                        var $buttonGroup = $(buttonGroup);
                        $buttonGroup.on('click', 'button', function ()
                        {
                            $buttonGroup.find('.is-checked').removeClass('is-checked');
                            $(this).addClass('is-checked');
                        });
                    });

                });
            </script>
            <script src="users/js/jquery-ui-1.10.3.min.js"></script>
            <script src="users/js/jquery.knob.js"></script>
            <script src="users/js/daterangepicker.js"></script>
            <script src="users/js/bootstrap3-wysihtml5.all.min.js"></script>
            <script src="users/js/dashboard.js"></script>
        </div>
    </body>
</html>

