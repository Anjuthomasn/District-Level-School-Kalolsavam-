<?php
session_start();
include 'connection.php';
use PHPMailer\PHPMailer\PHPMailer;


if(isset($_POST['submit']))
{
    $email = $_POST['email'];
    $result = mysqli_query($con,"SELECT * FROM kalolsavam_tb2_user where email='$email'");
    $row = mysqli_fetch_array($result);
	$l_id=$row['l_id'];
        $e=$row['email'];
        echo $e;
//         $result2 = mysqli_query($con,"SELECT * FROM kalolsavam_tb1_login where l_id=$l_id ");
//    $row2 = mysqli_fetch_array($result2);
//	$p=$row2['password'];
	if($email==$e) {
                            require_once"PHPMailer/PHPMailer.php";
                            require_once"PHPMailer/Exception.php";
                            $mail=new PHPMailer();
                            $mail->addAddress("$e");
                            $mail->setFrom("anjuthomas4454@gmail.com", "Anju");
                                    //setFrom(address:"anjuthomas4454gmail.com", name:"Anju");
                            $mail->Subject="Reset Password";
                            
                            $mail->Body=" 
                                    Haiii
                                        reaset yor password";
                            if($mail->send())
                            {
                                echo"<script> alert('Mail send to your email')
                         window.location.href = 'forgot.php';</script>";
                        
                            }
			}
				else{
					echo 'invalid userid';
				}
}
?>
<!DOCTYPE HTML>
<html>
<head>
<style type="text/css">
 input{
 border:1px solid olive;
 border-radius:5px;
 }
 h1{
  color:darkgreen;
  font-size:22px;
  text-align:center;
 }

</style>
</head>
<body>
<h1>Forgot Password<h1>
<form action='' method='post'>
<table cellspacing='5' align='center'>
<tr><td>user id:</td><td><input type='email' name='email'/></td></tr>
<tr><td></td><td><input type='submit' name='submit' value='Submit'/></td></tr>
</table>
</form>
</body>
</html>

