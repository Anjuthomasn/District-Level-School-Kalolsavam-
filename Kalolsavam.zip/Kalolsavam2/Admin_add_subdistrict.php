
<?php
include 'connection.php';
session_start();
if (!(isset($_SESSION['l_id'])) ) {
    header('location:index.php');
}

$id = $_SESSION['l_id'];
$dt_id=1;

?>
<!DOCTYPE html>
<html>
    <head>
        <title>School Kalolsavam</title>

        <!-- meta -->
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- css -->
        <link rel="stylesheet" href="users/css/bootstrap.min_2.css">
        <link rel="stylesheet" href="users/css/ionicons.min.css">
        <link rel="stylesheet" href="users/css/font-awesome.min.css">
        <link rel="stylesheet" href="users/css/owl.carousel.css">
        <link rel="stylesheet" href="users/css/owl.theme.css">
        <link rel="stylesheet" href="users/css/owl.transitions.css">
        <link rel="stylesheet" href="users/css/animate.css">
        <link rel="stylesheet" href="users/css/custom.css">

        <!-- js -->
        <script src="users/js/jquery.min.js"></script>
        <script src="users/js/bootstrap.min.js"></script>
        <script src="users/js/owl.carousel.min.js"></script>
        <script src="users/js/isotope.pkgd.min.js"></script>
        <script src="users/js/script.js"></script>
        <script src="users/js/wow.min.js"></script>
        <script src="users/js/jquery.actual.min.js"></script>

        <link rel="stylesheet" href="css2/s3.css">
        <style>
            table {
                border-collapse: collapse;
                width:50%;
            }

            th, td {
                text-align: center;
                padding: 8px;
                font-size: 14px;
                font-weight: bold;
            }

            tr:nth-child(even){background-color: #f2f2f2}

            th {
                color: black;
                font-size: 16px;
                font-family: helvetica;
                font-weight: bolder;
            }
        </style>

    </head>

    <body>
        <div id="wrapper">


            <section id= "navigation">
                <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
                    <div class="container-fluid">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                                <span class="ion-navicon"></span>
                            </button>
                            <a class="navbar-brand" href="#">School Kalolsavam </a>
                        </div>
                        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                <ul class="nav navbar-nav navbar-right">
                                    <li><a href="adminhome.php">HOME</a></li>
                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true"> <span class="nav-label">ADD</span> <span class="caret"></span></a>
                                        <ul class="dropdown-menu">
                                            <li><a href="Admin_add_subdistrict.php">ADD SUBDISTRICT</a></li>
                                            <li><a href="Admin_add_program.php">ADD PROGRAM LIST</a></li>
                                            <li> <a href="mails/Admin_add_stagedetails.php">ADD STAGE DETAILS</a></li>



                                        </ul>
                                    </li>

                                    
                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true"> <span class="nav-label">VIEW & UPDATE </span> <span class="caret"></span></a>
                                        <ul class="dropdown-menu">
                                            <li><a href="Admin_view_program.php">PROGRAM LIST</a></li>
                                           

                                        </ul>
                                    </li>

                                     <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true"> <span class="nav-label">CHEST NUMBER</span> <span class="caret"></span></a>
                                    <ul class="dropdown-menu">
                                        <li><a href="Admin_chestnogenerate.php">GENERATE CHEST NUMBER</a></li>
                                        <li><a href="Admin_view_chestno.php">VIEW CHEST NUMBER</a></li>
                                        
                                    



                                    </ul>
                                </li>
                                    
                                    <li><a href="logout.php">LOGOUT</a></li>
                                </ul>
                            </div>
                    </div>	<!-- container-fluid -->
                </nav>

                <!-- navbar -->
            </section>	<!-- #navigation -->
        

            <div class="row text-center" id="heading">
                <div class="col-md-6 col-md-offset-3 wow animated zoomInDown" id="heading-text">
                    <h3>Add Subdistrict</h3>
                    <hr class="full">
                    <br/>
                </div>

            </div>




        </section><!-- row -->       
<?php
if (isset($_POST['submit'])) {

    $subdistrict =strtoupper($_POST['subdistrict']);
    $a=ucfirst($subdistrict);
    $sd = "SELECT `subdistrict` FROM `kalolsavm_tb4_subdistrict` WHERE `subdistrict`='$subdistrict'";
    $re = mysqli_query($con, $sd);

  
    $row1 = mysqli_fetch_array($re);
    $rr2 = $row1["subdistrict"];
    if ($rr2 == $subdistrict) {
            echo"<script> alert('Alredy added ')
                         window.location.href = 'Admin_add_subdistrict.php';</script>";
       // <script>alert(' already added  ');</script>
    } 
    else {



        $sql1 = "INSERT INTO `kalolsavm_tb4_subdistrict`(`dt_id`,`subdistrict`,`sts`) VALUES ($dt_id,'$subdistrict',1)";
        $result1 = mysqli_query($con, $sql1);
    }
}

?>

        <br><br><br><br>

        <div class="signup__container">

            <div class="container__child signup__form">

                <form id="search-form"  method="post" name="form1" >



                    <div class="form-group">
                        <br><label>SubDistrict</label>
                        <input type="text" name="subdistrict" id="subdistricts" class="form-control"  onchange="add();" onkeypress="return onlyAlphabets(event,this);" required/>
                        <label style="display:none ; color:red"  id="aaa"></label>

                    </div>
                    <div class="m-t-lg">
                        <ul class="list-inline">
                            <li>
                                <input type="submit" class="btn btn--form" align="center" name="submit" id="pin" value="Add">


                            </li>

                        </ul>
                    </div>


                </form>
            </div>
        </div>
<?php
if (isset($_POST['edit'])) {
    
    $subdname =strtoupper($_POST['sdtname']);
    $id = $_POST['sdt'];
    $sdnm=ucfirst($subdname);
    $q = "UPDATE `kalolsavm_tb4_subdistrict` SET `subdistrict`='$subdname' WHERE `sdt_id`=$id";
    $query = mysqli_query($con, $q);
}

//for deletion
if (isset($_POST['delete'])) {
    $id = $_POST['sdt'];
    $ms="DELETE FROM `kalolsavm_tb4_subdistrict` WHERE `sdt_id`=$id";
    $query = mysqli_query($con,$ms);
}
?>

        <center>

            <br><br><br><br><br><br><br><br><?php
            $s = mysqli_query($con, "select * from kalolsavm_tb4_subdistrict");
            $rs=mysqli_fetch_array($s);
           if(mysqli_num_rows($s) < 1)
           {?>
               <br><br><br><br><br><br><br><br>
                        <label style="color:red;font-size:18px" >SUBDISTRICT NOT ADDED</label>
        <br><br><br><br><br><br><br><br>><br><br><br><br>
      
            <?php   
           }
          else {
        ?>
            <table>
                
         <label style="display:none ; color:red"  id="aa"></label>
                <tr>
                    <td >&nbsp;</td>
                    <td ></td>
                <tr>

                    <th>SUBDISTRICT</th>
                    <th></th>

                    <th>UPDATE</th>

                    <th>DELETE</th>




                </tr>
<?php
$query = mysqli_query($con, "select * from kalolsavm_tb4_subdistrict");
while ($row = mysqli_fetch_array($query)) {
    ?><form action="#" method="post" name="form2">
                        <tr>

                            <td><input class="txt" type="text" name="sdtname" id="sdt" onchange="adds();" value="<?php echo $row['subdistrict']; ?>"  onkeypress="return onlyAlphabets(event,this);" required /></td>
                            <td><input class="txt" type="hidden" name="sdt" hidden value="<?php echo $row['sdt_id']; ?>"></td>
                            <td><input type="submit" name="edit" class="btn btn-inverse large"  value="UPDATE"></td>
                            <td><input type="submit" name="delete" class="btn btn-inverse large" value="DELETE"></td>


                        </tr></form>
                    <?php
                }
                ?>
            </table>
            <?php
                }
                ?>
        </center>

        <br><br>  <br><br>  <br><br>  <br><br>  <br><br>  <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br>




        <br><br>  <br><br>  <br><br>  <br><br>  <br><br>  <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br>
        <!-- footer -->
        <section id= "footer" class= "main-footer">
            <div class= "row">
                <div class= "logo text-center">
                    <h1>School Kalolsavam</h1>
                </div>
            </div>
            <div class= "row">
                <div class= "copyright text-center">
                </div>
            </div>
        </section><!-- footer -->

        <!-- js -->
        </div>
        <script>
            $(document).ready(function () {
                $("#client-speech").owlCarousel({
                    autoPlay: 3000,
                    navigation: false, // Show next and prev buttons
                    slideSpeed: 700,
                    paginationSpeed: 1000,
                    singleItem: true
                });
            });
            function onlyAlphabets(e, t) {
            try {
                if (window.event) {
                    var charCode = window.event.keyCode;
                }
                else if (e) {
                    var charCode = e.which;
                }
                else { return true; }
                if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123))
                    return true;
                else
                    return false;
            }
            catch (err) {
                alert(err.Description);
            }
        }
        </script>
        <script>
            new WOW().init();
        </script>
        <script>
            $(function () {
                // init Isotope
                var $container = $('.isotope').isotope
                        ({
                            itemSelector: '.element-item',
                            layoutMode: 'fitRows'
                        });


                // bind filter button click
                $('#filters').on('click', 'button', function ()
                {
                    var filterValue = $(this).attr('data-filter');
                    // use filterFn if matches value
                    $container.isotope({filter: filterValue});
                });

                // change is-checked class on buttons
                $('.button-group').each(function (i, buttonGroup)
                {
                    var $buttonGroup = $(buttonGroup);
                    $buttonGroup.on('click', 'button', function ()
                    {
                        $buttonGroup.find('.is-checked').removeClass('is-checked');
                        $(this).addClass('is-checked');
                    });
                });

            });
        </script>
        <script src="users/js/jquery-ui-1.10.3.min.js"></script>
        <script src="users/js/jquery.knob.js"></script>
        <script src="users/js/daterangepicker.js"></script>
        <script src="users/js/bootstrap3-wysihtml5.all.min.js"></script>
        <script src="users/js/dashboard.js"></script>
    </div>
    <script>

            function add()
            {
                var x = document.getElementById('subdistricts').value;


                if ((x === null) || (x.length <= 4))
                {


                    $("#aaa").html('Invalid Name').fadeIn().delay(3000).fadeOut();

                    subdistricts.value = "";
                    subdistricts.focus();
                    return false;
                }
                var fnam = /^[a-zA-Z ]{4,25}$/;
                if (document.form1.subdistricts.value.search(subdistricts) == -1)
                {

                    $("#aaa").html('Invalid Name').fadeIn().delay(3000).fadeOut();
                    subdistricts.value = "";
                    subdistricts.focus();

                    return false;
                }

            }
            function adds()
            {
                var x = document.getElementById('sdt').value;


                if ((x === null) || (x.length <= 4))
                {


                    $("#aa").html('Invalid Name').fadeIn().delay(3000).fadeOut();

                  //  sdt.value = "";
                   sdt.focus();
                    return false;
                }
                var fnam = /^[a-zA-Z ]{4,25}$/;
                if (document.form2.sdt.value.search(sdt) == -1)
                {

                    $("#aa").html('Invalid Name').fadeIn().delay(3000).fadeOut();
                   // sdt.value = "";
                    sdt.focus();

                    return false;
                }

            }
    </script>

</body>
</html>
