
<?php
include 'stagemgr_header.php';
include 'connection.php';	
$id=$_SESSION['l_id'];

if (isset($_POST['ss'])) {

    $item=$_POST['item'];
   $list = "SELECT MAX(mark),re.mark,re.chest_no,re.grade,st.* FROM kalolsavam_tb20_result as re,kalolsavam_tb7_studentinfo as st WHERE re.pgm_list_id=$item and re.grade='A' and st.student_id=re.student_id";
    $results = mysqli_query($con,$list);
    $l2="SELECT MAX(mark),re.mark,re.chest_no,re.grade,st.* FROM kalolsavam_tb20_result as re,kalolsavam_tb7_studentinfo as st WHERE re.pgm_list_id=$item  and st.student_id=re.student_id AND re.mark = (SELECT MAX(mark) FROM kalolsavam_tb20_result WHERE mark < (SELECT MAX(mark) FROM kalolsavam_tb20_result))";
    $results2 = mysqli_query($con,$l2);
    
    // SELECT * FROM `kalolsavam_tb20_result` WHERE pgm_list_id=5 and  mark = (SELECT MAX(mark) FROM kalolsavam_tb20_result WHERE mark < (SELECT MAX(mark) FROM kalolsavam_tb20_result))

}

        ?> 
<center>
<table class="container" >
               
              
                <tr>
                    <th>NAME</th>
                    <th>CHESTNO</th>

                    <th>MARK</th>

                    <th>GRADE</th> 
                    <th>RESULTS</th>
                  




                </tr>
<?php
$rs="FIRST";
$rs2="SECOND";
$row = mysqli_fetch_array($results);
$row2 = mysqli_fetch_array($results2);
    ?>    <form  method="post" name="form2" action="#">

                        <tr>
<td><?php echo $row['name']; ?></td>
                            <td><?php echo $row['chest_no']; ?>  </td>
                            <td><?php echo $row['mark']; ?></td>
                            <td><?php echo $row['grade']; ?></td> 
                            <td><?php echo $rs; ?></td>
 

                        </tr>
                                                <tr>
<td><?php echo $row2['name']; ?></td>
                            <td><?php echo $row2['chest_no']; ?>  </td>
                            <td><?php echo $row2['mark']; ?></td>
                            <td><?php echo $row2['grade']; ?></td> 
                            <td><?php echo $rs2; ?></td>
 

                        </tr>
    </form>
     
                    <?php
                
                ?>
    </form>
            </table>
        
        <?php 
        


        ?>

</center>
<?php
if (isset($_POST['result'])) {
    
}
 ?>
