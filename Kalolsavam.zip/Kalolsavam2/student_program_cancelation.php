<?php
include 'student_header2.php';
include 'connection.php';

$id = $_SESSION['l_id'];

?>
<?php

    $qry="select * from kalolsavam_tb7_studentinfo where l_id=$id";
     $ans = mysqli_query($con, $qry);
     
     $r=mysqli_fetch_array($ans);
     $section=$r['section'];
     $gen=$r['gender'];
     $sdid=$r['student_id'];
     $studid=$r['student_id'];
   
     
     
?>

  <center>

        <?php
            $s = mysqli_query($con, "select * from `kalolsavam_tb12_registerd_program`  where `student_id`='$studid'");
            $rs=mysqli_fetch_array($s);
           if(mysqli_num_rows($s) < 1)
           {?>
 
                        <label style="color:red;font-size:18px" >No Program cancelation</label>
        
      
            <?php   
           }
          else {
        ?>
                        <form  method="post" name="form2">
            <table class="container" border="1">
               
         <label style="display:none ; color:red"  id="aa"> PROGRAM CANCELATION</label>
                <thead>
              <tr>      <th>Program</th>

                   
                  
                    <th>Select</th>




              </tr></thead>
<?php
$n="select pgm.*,pgmlist.* from kalolsavam_tb12_registerd_program as pgm,kalolsavam_tb11_program_list as pgmlist where pgm.student_id=$studid and pgm.pgm_list_id=pgmlist.pgm_list_id ";
$qs2 = mysqli_query($con, $n);
while ($row = mysqli_fetch_array($qs2)) {
    ?>
                <tbody>                  <tr>
                            <td><?php echo $row['item']; ?></td>
                <td> <a href="student_pgm_cancel.php?ids=<?php echo $row['pgm_reg_id']; ?>" ><input type="button" value="Cancel" name="delete"  style="backgroundcolor:black;color:white;width:200px;height:40px;" ></a></td>
<!--                             <td><input class="txt" type="submit" name="delete" value="Cancel" id="pgid"   ></td>-->

                        </tr></tbody>
                       
   
                    <?php
                }
                ?>
            </table>
<!--                            <br>     <input type="submit" value="Register" name="submit" onclick="uncheck();">-->
                       
                             </form>
            <?php
                }
                ?>
        </center>
<script>
function uncheck() {
    document.getElementById("pgid").checked = false;
    alert('Please slect');
}
</script>

<?php
include 'student_footer.php';
?>      


