<?php
include 'student_header2.php';
include 'connection.php';

$id = $_SESSION['l_id'];
$qry="select * from kalolsavam_tb7_studentinfo where l_id=$id";
     $ans = mysqli_query($con, $qry);
     $r=mysqli_fetch_array($ans);
     $studid=$r['student_id'];
$q1="select * from kalolsavam_tb20_result where student_id=$studid ";
$ex1 = mysqli_query($con, $q1);
if(mysqli_num_rows($ex1) < 1)
     {?>
    <marquee><label style="color:white;font-size:18px" >RESULT NOT PUBLISHED  </label></marquee>
    <?php }
 else {
 ?>
    <table class="container" >
        <thead>
               
             <tr>      <th><h1>Chest No</h1></th>
                         <th><h1>Mark</h1></th>
                         <th><h1>Grade</h1></th>
             </tr>
        </thead>
        <?php 
        while ($row = mysqli_fetch_array($ex1)) {
    ?>
                    <tbody><tr>
                            <td><?php echo $row['chest_no']; ?></td> 
                             <td><?php echo $row['mark']; ?></td>
                              <td><?php echo $row['grade']; ?></td>
        </tr></tbody><?php } ?>
    </table>
<?php    
 }
?>


<?php
include 'student_footer.php';
?>  