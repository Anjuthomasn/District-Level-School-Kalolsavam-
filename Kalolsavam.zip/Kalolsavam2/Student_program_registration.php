<?php
include 'student_header2.php';
include 'connection.php';

$id = $_SESSION['l_id'];
  $dts="PROGRAM REGISTRATION";
        // $d=26; $m=3; $y=2019;
         $dts1="SELECT * FROM `tbl_dates` WHERE `npgm_name`='$dts' ";
          $dts2 = mysqli_query($con,$dts1);
           $dts3=mysqli_fetch_array($dts2);
                   $da=$dts3["dts"];
                   
          
          
?>
<marquee><label style="color:white;font-size:18px" >PROGRAM REGISTRATION END <?php echo $da?> </label></marquee>
<?php

    $qry="select * from kalolsavam_tb7_studentinfo where l_id=$id";
     $ans = mysqli_query($con, $qry);
     $r=mysqli_fetch_array($ans);
     $section=$r['section'];
     $gen=$r['gender'];
     $sdid=$r['student_id'];
     $studid=$r['student_id'];
   
     if(isset($_POST['submit']))
    {
         
         
          $c = $_POST['pgid'];
          foreach($c as $pgmid)
            {
                       
         $pgmsid=$pgmid;
//         if($pgmsid==0)
//         {
//              echo"<script> alert('Please select Program ')
//                         window.location.href = 'studentprofile.php';</script>";
//
//         }
// else {
//             
         
      $check="select * from kalolsavam_tb12_registerd_program where student_id=$sdid and pgm_list_id='$pgmsid' ";
       $checkans= mysqli_query($con, $check);
      $ch=mysqli_fetch_array($checkans);
     if(mysqli_num_rows($checkans) < 1)
     {
         $time=date("h:i:s");
         $date=date("d/m/Y");
         
         
         //$now="26/3/2019";
//         if($d <$dt && $m < $mt && $yr < $y)
//         {
         $registration="insert into `kalolsavam_tb12_registerd_program`(`student_id`,`pgm_list_id`,`reg_date`,`time`,`status`) values($studid,'$pgmsid','$date','$time',0) ";
         $regresult=mysqli_query($con,$registration);
            
         if($regresult)
                    {
                        
                        
                         echo"<script> alert('Registration Successful')
                         window.location.href = 'student_program_cancelation.php';</script>";
                        
                    }
            
     }
 
 else {
     echo"<script> alert('You alredy Registerd ')
                         window.location.href = 'student_program_cancelation.php';</script>";
 }
// }
           }
    }
     
     
?>
  <center>

        <?php
        $dt=date("d/m/Y");
       //echo $dt;
         $mt=date("m");
         $yr=date("Y");
         
         $pg="PROGRAM REGISTRATION";
        // $d=26; $m=3; $y=2019;
         $s="SELECT * FROM `tbl_dates` WHERE `npgm_name`='$pg' and `dts` >$dt";
          $sa = mysqli_query($con,$s);
          // echo $sa;
        
            $rsa=mysqli_fetch_array($sa);
            $uns = "SELECT * FROM `kalolsavam_tb13_chestno`";

$cre = mysqli_query($con, $uns);
           if(mysqli_num_rows($sa) < 1 || mysqli_num_rows($cre) > 0)
           {?>
 
      <br><br>   <label style="color:red;font-size:18px" >Registration Closed</label>
        
      
            <?php   
           }
 else {
           //select list.*,reg.* from kalolsavam_tb11_program_list as list,kalolsavam_tb12_registerd_program as reg where list.section='$section' and list.gender='$gen' and list.category='Single' and reg.student_id!=$sdid 
              $qsr="select * from kalolsavam_tb11_program_list as list,kalolsavam_tb16_comb_details as comb  where comb.student_id=$sdid and comb.status=1 and comb.pgm_list_id=list.pgm_list_id and list.section='$section' and list.gender='$gen' and list.category='Single'";
           $qsr2 = mysqli_query($con,$qsr);
           if(mysqli_num_rows($qsr2) < 1){
               ?>
 
                        <label style="color:red;font-size:18px" >No Program </label>
            <?php
           }  
                  
          else {
        ?>
                        <form action="#" method="post" name="form2">
            <table class="container">
               
         <label style="display:none ; color:red"  id="aa"></label>
         <thead>
               
             <tr>      <th><h1>Program</h1></th>

                    <th><h1>Program Code</h1></th>

                    <th><h1>Time Limit</h1></th>
                    <th><h1>Select</h1></th>




                </tr>
         </thead>
<?php
$sample="select * from kalolsavam_tb12_registerd_program where student_id=$sdid ";
$sample2 = mysqli_query($con,$sample);
$a='Single';

$mn="select * from kalolsavam_tb11_program_list as list,kalolsavam_tb16_comb_details as comb  where comb.student_id=$sdid and comb.status=1 and comb.pgm_list_id=list.pgm_list_id and list.section='$section' and list.gender='$gen' and list.category='Single' ";
$q2 = mysqli_query($con,$mn);
// $t=$row['pgm_list_id'];
//                    $tst="select * from kalolsavam_tb11_program_list where pgm_list_id > $t  ";
//                    $qt = mysqli_query($con,$tst);
//                    $qst = mysqli_fetch_array($qt);
//                    $count=$qst['pgm_list_id'];


while ($row = mysqli_fetch_array($q2)) {
    ?>
                    <tbody>     <tr>

                            <td><?php echo $row['item']; ?></td>
                            <td><?php echo $row['item_code']; ?></td>
                             <td><?php echo $row['time_limit']; ?></td>
                             <td><input class="txt" type="checkbox" name="pgid[]" id="pgid" value="<?php echo $row['pgm_list_id']; ?>"  ></td>

                        </tr></tbody>
                       
   
                    <?php
                   
                   
                    
                }
                              
 


                ?>
            </table>
                            <br>     <input type="submit" value="REGISTER" name="submit" id="reset" style="backgroundcolor:black;color:white;width:200px;height:40px;" >
                       
                             </form>
            <?php
  
          }
 }
                ?>
        </center>


<?php
//select lists.* from kalolsavam_tb11_program_list AS lists,kalolsavam_tb12_registerd_program AS pgm  where lists.section='LP' and lists.gender='FEMALE' and lists.category='Single' AND pgm.student_id=4 AND lists.pgm_list_id!=pgm.pgm_list_id
include 'student_footer.php';
?>      


