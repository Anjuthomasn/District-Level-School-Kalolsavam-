//select ddistrict on dstate
<?php
 $con = mysqli_connect("localhost", "root", "", "kalolsavam");

if(isset($_POST['status'])&&$_POST['status']=="1")
{
  $item = $_POST['dstate'];
  $query = "SELECT `list_id`,`section` FROM `program_list` WHERE `item_name` = '$item' AND `status` = '1'";
  $result=mysqli_query($con,$query);
  echo "<option value = >  </option>";
  while($row=mysqli_fetch_array($result))
  {
    echo "<option value='".$row['list_id']."'>".$row['section']."</option>";
  }

}
?>


