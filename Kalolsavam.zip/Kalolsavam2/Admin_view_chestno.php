<?php
include 'connection.php';
session_start();
if (!(isset($_SESSION['l_id'])) ) {
    header('location:index.php');
}

$id = $_SESSION['l_id'];
?>
<!DOCTYPE html>
<html>
    <head>
        <title>School Kalolsavam</title>

        <!-- meta -->
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- css -->
        <link rel="stylesheet" href="users/css/bootstrap.min_2.css">
        <link rel="stylesheet" href="users/css/ionicons.min.css">
        <link rel="stylesheet" href="users/css/font-awesome.min.css">
        <link rel="stylesheet" href="users/css/owl.carousel.css">
        <link rel="stylesheet" href="users/css/owl.theme.css">
        <link rel="stylesheet" href="users/css/owl.transitions.css">
        <link rel="stylesheet" href="users/css/animate.css">
        <link rel="stylesheet" href="users/css/custom.css">

        <!-- js -->
        <script src="users/js/jquery.min.js"></script>
        <script src="users/js/bootstrap.min.js"></script>
        <script src="users/js/owl.carousel.min.js"></script>
        <script src="users/js/isotope.pkgd.min.js"></script>
        <script src="users/js/script.js"></script>
        <script src="users/js/wow.min.js"></script>
        <script src="users/js/jquery.actual.min.js"></script>

        <link rel="stylesheet" href="css/s7.css">

        <style>  
            table {
                 border-collapse: collapse;
    border-spacing: 0;
    width: 300%;
    border: 1px solid #ddd;
            }

            th, td {
                text-align: center;
                padding: 8px;
                font-size: 14px;
                font-weight: bold;
            }

            tr:nth-child(even){background-color: #f2f2f2}

            th {
                color: black;
                font-size: 16px;
                font-family: helvetica;
                font-weight: bolder;
            }
            td{
                 background-color: #f2f2f2;
            }
            tr
            {
                 background-color: #f2f2f2;
            }
        </style>

    </head>

    <body>
        <div id="wrapper">


            <section id= "navigation">
                <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
                    <div class="container-fluid">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                                <span class="ion-navicon"></span>
                            </button>
                            <a class="navbar-brand" href="#">School Kalolsavam </a>
                        </div>
                            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                <ul class="nav navbar-nav navbar-right">
                                    <li><a href="adminhome.php">HOME</a></li>
                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true"> <span class="nav-label">ADD</span> <span class="caret"></span></a>
                                        <ul class="dropdown-menu">
                                            <li><a href="Admin_add_subdistrict.php">ADD SUBDISTRICT</a></li>
                                            <li><a href="Admin_add_program.php">ADD PROGRAM LIST</a></li>
                                            <li> <a href="mails/Admin_add_stagedetails.php">ADD STAGE DETAILS</a></li>



                                        </ul>
                                    </li>

                                 
                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true"> <span class="nav-label">VIEW & UPDATE </span> <span class="caret"></span></a>
                                        <ul class="dropdown-menu">
                                            <li><a href="Admin_view_program.php">PROGRAM LIST</a></li>
                                            


                                        </ul>
                                    </li>

                                     <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true"> <span class="nav-label">CHEST NUMBER</span> <span class="caret"></span></a>
                                    <ul class="dropdown-menu">
                                        <li><a href="Admin_chestnogenerate.php">GENERATE CHEST NUMBER</a></li>
                                        <li><a href="Admin_view_chestno.php">VIEW CHEST NUMBER</a></li>
                                        
                                    



                                    </ul>
                                </li>
                                    
                                    <li><a href="logout.php">LOGOUT</a></li>
                                </ul>
                            </div>
	<!-- collapse navbar-collapse -->
                    </div>	<!-- container-fluid -->
                </nav>

                <!-- navbar -->
            </section>	<!-- #navigation -->

            <div class="row text-center" id="heading">
                <div class="col-md-6 col-md-offset-3 wow animated zoomInDown" id="heading-text">
                    <h3>VIEW CHEST NUMBER</h3>
                    <hr class="full">
                    <br/>
                </div>

            </div>




       <!-- row -->       


        <br><br><br><br><br><br>


        <div class="signup__container">

            <div class="container__child signup__form">
                <?php
                 $uns = "SELECT * FROM `kalolsavam_tb13_chestno`";

$results = mysqli_query($con, $uns);

    if (mysqli_num_rows($results)== 0)
    {
        ?>
                           <label style="color:white;font-size:18px" >CHEST NUMBER NOT GENERATED</label>
                           <?PHP
    }
 else {
?>
                           <form id="search-form"  method="post" name="form1" action="Admin_view_chest_no.php" >



                    <div class="form-group">
                        <br>   <label for="item">PROGRAM</label> 
                        <br>     <select class="form-control" name="item" id="item" >
                           
                              <option value=0 hidden="" >SELECT PROGRAM</option>
        <?php
         $con = mysqli_connect("localhost", "root", "", "kalolsavam");
                                    if (!$con) {
                                        echo "Could not connect..Try again";
                                    } else {
                                        $sdselect = "SELECT * FROM `kalolsavam_tb11_program_list` ";
                                        $sdresult = mysqli_query($con, $sdselect);
                                        //echo "";
                                        while ($sdrow = mysqli_fetch_array($sdresult)) {
                                            $stname = $sdrow['item'];
                                            $gender=$sdrow['gender'];
                                            $section=$sdrow['section'];
                                            $sid = $sdrow['pgm_list_id'];
                                            echo "<option value='$sid'>$stname - $gender - $section</option>";
                                        }
                                    }
                                    mysqli_close($con);
                                    ?>
              </select>
                        <label style="display:none ; color:red"  id="aaa"></label>

                    </div>
                   
                    <div class="m-t-lg">
                        <ul class="list-inline">
                            <li>
                                <input type="submit" class="btn btn--form" align="center" name="submits" id="pin" value="View Chest Number" >


                            </li>

                        </ul>
                    </div>


                </form>
        <?php
 }
 ?>
                           
            </div>
        </div>
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>

        <div style="margin-left: 400px;max-width: 200px;">
              
                         
                
            <table>
              
                
                 <?php
                if (isset($_POST['submits'])) {
                     $item = $_POST['item'];
                    $sqs="select * from kalolsavam_tb13_chestno as c,kalolsavam_tb11_program_list as list,kalolsavam_tb12_registerd_program as reg,kalolsavam_tb7_studentinfo as stud,kalolsavam_tb5_schoollist as sc,kalolsavm_tb4_subdistrict as sd where c.pgm_reg_id=reg.pgm_reg_id and reg.pgm_list_id=$item and reg.pgm_list_id=list.pgm_list_id and reg.student_id=stud.student_id and stud.sclist_id=sc.sclist_id and sc.sdt_id=sd.sdt_id ";
                   // $sql = "select c.*,list.*,reg.*,stud.*,sc.*,sd.* from kalolsavam_tb13_chestno as c,kalolsavam_tb11_program_list as list,kalolsavam_tb12_registerd_program as reg,kalolsavam_tb7_studentinfo as stud,kalolsavam_tb5_schoollist as sc,kalolsavm_tb4_subdistrict as sd where reg.pgm_list_id='$item'  AND list.section='$section' AND list.gender='$gender' AND list.pgm_list_id=$item AND reg.pgm_reg_id=c.pgm_reg_id AND reg.student_id=stud.student_id AND stud.sclist_id=sc.sclist_id AND sc.sdt_id=sd.sdt_id ";
             
                    $q = mysqli_query($con, $sqs);
                    ?>
                <tr>

                    <th>STUDENT NAME</th>
                    <th>CHEST NO</th> 
                    <th>SCHOOL</th>
                    <th>SUBDISTRICT</th>

                </tr>
                
                 <?php
                    
                 while ($row = mysqli_fetch_array($q)) {
           
                        ?>
                            <tr>
                                  <td><?php echo $row['name']; ?></td>
                                
                                <td><?php echo $row['chest_no']; ?></td>
                                <td><?php echo $row['school']; ?></td>
                                <td><?php echo $row['subdistrict']; ?></td>
                              
                                



                            </tr>
                        <?php
                }
                }
                    
                    ?>
                
                
            </table>
            

            
        </div>
        


            <br>


            <br><br>  <br><br>  <br><br>  <br><br>  <br><br>  <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br>




            <br><br>  <br><br>  <br><br>  <br><br>  <br><br>  <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br>
            <!-- footer -->
            <section id= "footer" class= "main-footer">
                <div class= "row">
                    <div class= "logo text-center">
                        <h1>School Kalolsavam</h1>
                    </div>
                </div>
                <div class= "row">
                    <div class= "copyright text-center">
                    </div>
                </div>
            </section><!-- footer -->

            <!-- js -->
            <script>
                $(document).ready(function () {
                    $("#client-speech").owlCarousel({
                        autoPlay: 3000,
                        navigation: false, // Show next and prev buttons
                        slideSpeed: 700,
                        paginationSpeed: 1000,
                        singleItem: true
                    });
                });
            </script>
            <script>
                new WOW().init();
            </script>
            <script>
                $(function () {
                    // init Isotope
                    var $container = $('.isotope').isotope
                            ({
                                itemSelector: '.element-item',
                                layoutMode: 'fitRows'
                            });


                    // bind filter button click
                    $('#filters').on('click', 'button', function ()
                    {
                        var filterValue = $(this).attr('data-filter');
                        // use filterFn if matches value
                        $container.isotope({filter: filterValue});
                    });

                    // change is-checked class on buttons
                    $('.button-group').each(function (i, buttonGroup)
                    {
                        var $buttonGroup = $(buttonGroup);
                        $buttonGroup.on('click', 'button', function ()
                        {
                            $buttonGroup.find('.is-checked').removeClass('is-checked');
                            $(this).addClass('is-checked');
                        });
                    });

                });
            </script>
            <script src="users/js/jquery-ui-1.10.3.min.js"></script>
            <script src="users/js/jquery.knob.js"></script>
            <script src="users/js/daterangepicker.js"></script>
            <script src="users/js/bootstrap3-wysihtml5.all.min.js"></script>
            <script src="users/js/dashboard.js"></script>
        </div>
        <script>
                function add()
                {
                    var x = document.getElementById('subdistricts').value;


                    if ((x === null) || (x.length <= 1))
                    {


                        $("#aaa").html('Invalid Name').fadeIn().delay(3000).fadeOut();

                        subdistricts.value = "";
                        subdistricts.focus();
                        return false;
                    }
                    var fnam = /^[a-zA-Z ]{4,25}$/;
                    if (document.form1.subdistricts.value.search(subdistricts) == -1)
                    {

                        $("#aaa").html('Invalid Name').fadeIn().delay(3000).fadeOut();
                        subdistricts.value = "";
                        subdistricts.focus();

                        return false;
                    }

                }
           
        </script>

</body>
</html>
