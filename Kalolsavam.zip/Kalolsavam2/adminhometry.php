<?php
include 'adminheader.php';
include 'connection.php';

$id = $_SESSION['l_id'];
?>
</section>
<?php
include 'student_footer.php';
?> 