<?php
include 'student_header2.php';
include 'connection.php';

$id = $_SESSION['l_id'];
  $dts="PROGRAM REGISTRATION";
        // $d=26; $m=3; $y=2019;
         $dts1="SELECT * FROM `tbl_dates` WHERE `npgm_name`='$dts' ";
          $dts2 = mysqli_query($con,$dts1);
           $dts3=mysqli_fetch_array($dts2);
                   $da=$dts3["dts"];
                   
          
          
?>
<?php

    $qry="select * from kalolsavam_tb7_studentinfo where l_id=$id";
     $ans = mysqli_query($con, $qry);
     $r=mysqli_fetch_array($ans);
     $section=$r['section'];
     $gen=$r['gender'];
     $sdid=$r['student_id'];
     $studid=$r['student_id'];
     $school=$r['sclist_id'];
     $ct=1;
     $regid=0;
     $a=$_GET['ids'];
  
       
       $f1="select * from kalolsavam_tb11_program_list where pgm_list_id=$a";
       $fs1 = mysqli_query($con, $f1);
       $rs=mysqli_fetch_array($fs1);
        $no=$rs["max_participent"];
       $check="select * from kalolsavam_tb12_registerd_program where student_id=$sdid and pgm_list_id=$a ";
       $checkans= mysqli_query($con, $check);
      $ch=mysqli_fetch_array($checkans);
     if(mysqli_num_rows($checkans)>0)
     {
         ?><center><?php echo"You alredy Registerd  "; ?></center>
         <?php
     }
 else {
     ?>
         <center>
             <div class="container-contact1">
             	<div class="contact1-pic js-tilt" data-tilt>
				<img src="img/img-01.png" alt="IMG">
			</div>

                 
				<span class="contact1-form-title">
					PARTICIPATING STUDENTS  NAME
				</span>
                            
                     <input type="hidden" name="ct" value="<?php echo $no ?>" >
                     <input type="hidden" name="std" value="<?php echo $studid ?>" >
                     <input type="hidden" name="as" value="<?php echo $a ?>" >
                     <?php $i=1; while($i<=$no){  ?><form class="contact1-form validate-form" method="post">
                     <div class="wrap-input1 validate-input" data-validate = "Name is required">
					<input class="input1" type="text" name="<?php echo $i; ?>" id="nms" placeholder="Student Name" required>
					<span class="shadow-input1"></span>
				</div></form>
                            <?php $i++; }?>
                     
                     <div class="container-contact1-form-btn">
                         <input type="submit"  name="submits" class="contact1-form-btn" value="Enter Student list" >
<!--                                    <input type="submit" name="submits" class="contact1-form-btn" value="Enter Student list" >-->
					<i class="fa fa-long-arrow-right" aria-hidden="true"></i>
				</div>
                                    

				
			
		</div>
         </center>
         
        
         
    <?php }
     
       
       
       
    
     if(isset($_POST['submits']))
    {   
         $c1=1;
         $n=$_POST['ct'];
      
          $std=$_POST['std'];
          $as=$_POST['as'];
     
         $time=date("h:i:s");
         $date=date("d/m/Y");
         
         
         //$now="26/3/2019";
//         if($d <$dt && $m < $mt && $yr < $y)
//         {
         $registration="insert into `kalolsavam_tb12_registerd_program`(`student_id`,`pgm_list_id`,`reg_date`,`time`,`status`) values($std,'$as','$date','$time',0) ";
         $regresult=mysqli_query($con,$registration);
            
         if($regresult)
         { 
             $x="select * from kalolsavam_tb12_registerd_program where student_id=$studid and pgm_list_id=$a ";
             $xx=mysqli_query($con,$x);
                  $xxx=mysqli_fetch_array($xx);
     $regid=$xxx['pgm_reg_id'];
        while($c1<=$n)
         {
         $n1=$_POST["$c1"];
//          $n2=$_POST['n2'];
//          $n3=$_POST['n3'];
//          $n4=$_POST['n4'];
//          $n5=$_POST['n5'];
//          $n6=$_POST['n6'];
//          $n7=$_POST['n7'];
//          $n8=$_POST['n8'];
          $registration2="INSERT INTO `kalolsavam_tb15_grouplist`(`pgm_reg_id`, `n1`) VALUES ($regid,'$n1')";
       
         $c1++;
         }
     
     $regresult2=mysqli_query($con,$registration2);
         if($regresult2)
         {
             echo"<script> alert('Registration Successful')
                         window.location.href = 'student_program_cancelation.php';</script>";
                        
                    }
         }
                    
                    
     
             
             
                
            
     
 
 
// }
                     $ct++;
           
    }
     
     
?>
