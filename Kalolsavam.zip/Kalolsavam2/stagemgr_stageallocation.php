<?php
include 'stagemgr_header.php';
include 'connection.php';	
$id=$_SESSION['l_id'];
//function doesExist($sql)
//{
//    //require "connect.php";
//    $res = mysqli_query($con, $sql);
//    //no errors in query and returns min. a row
//    if($res && mysqli_num_rows($res) > 0)
//    {
//        return false;
//       // echo"<script>alert('Sorry  email is already in use..Please choose a different one..! ');</script>)";
//    }
//    return true;
//}
//if(isset($_POST['item']));
//{
//     $item = $_POST['item'];
//    $sql = "SELECT * FROM `kalolsavam_tb14_stage_events` where pgm_list_id=$item";
//    if(doesExist($sql)){
//        echo '0';
//    }else{
//            echo '1';
//    }
//}
$qry="select * from kalolsavam_tb8_stagelist as st,kalolsavam_tb9_stagemgr_info as info where info.l_id=$id and st.stge_id=info.stge_id";
     $ans = mysqli_query($con, $qry);
     $r=mysqli_fetch_array($ans);
     $stgnm=$r['stage_name'];
     $stid=$r['stge_id'];
if(isset($_POST['submits']))
    {
    $std= $_POST['stdid'];
     $pgmid= $_POST['item'];
     $times=$_POST['times'];
     $dates=$_POST['dates'];
     $q=mysqli_query($con,"SELECT * FROM `kalolsavam_tb14_stage_events`");
     $r=mysqli_fetch_array($q);
     $pgid=$r['pgm_list_id'];
     if($pgmid==$pgid)
     {
          echo"<script> alert('Sorry Program alredy alocated')
                         window.location.href = 'tagemgr_stageallocation.php';</script>";
                        
     }
 else {
         
     
     $qry="INSERT INTO `kalolsavam_tb14_stage_events`( `pgm_list_id`, `stage_id`, `time`, `date`) VALUES('$pgmid','$std','$times','$dates')";
     $ex= mysqli_query($con,$qry);
    }
    }
?>
<marquee><label style="color:white;font-size:18px" > UPLOAD STAGE DETAILS <?php echo $stgnm ?> </label></marquee>
<form method="post">
<table class="container" >
 <tbody> 
        <tr>
            <td>PROGRAM</td>
 <input type="hidden" name="stdid" value="<?php echo $stid ?>">
            <td>  <select class="form-control" name="item" id="item" style="width: 250px;" onblur="myFunction()">
                           
                    <option value=0  hidden>SELECT PROGRAM</option>
        <?php
         $con = mysqli_connect("localhost", "root", "", "kalolsavam");
                                    if (!$con) {
                                        echo "Could not connect..Try again";
                                    } else {
                                        $sdselect = "SELECT list.* FROM kalolsavam_tb11_program_list as list,kalolsavam_tb14_stage_events as ev where list.pgm_list_id!=ev.pgm_list_id ";
                                        $sdresult = mysqli_query($con, $sdselect);
                                        //echo "";
                                        while ($sdrow = mysqli_fetch_array($sdresult)) {
                                            $stname = $sdrow['item'];
                                            $gender=$sdrow['gender'];
                                            $section=$sdrow['section'];
                                            $sid = $sdrow['pgm_list_id'];
                                            echo "<option value='$sid'>$stname - $gender - $section</option>";
                                        }
                                    }
                                    mysqli_close($con);
                                    ?>
              </select>
                </td>
     
        <label style="display:none ; color:red"  id="eml"></label>
            <td>Time</td>
            <td><input type="time" name="times" id="times" required></td>
            <td>Date</td>
            <td><input type="date" name="dates" id="dates" min="05/15/2019" max="05/26/2019" required></td>
            
            <td rowspan="2"> <input type="submit" name="submits" value="UPLOAD" style="backgroundcolor:black;color:black;width:200px;height:40px;"></td>
            
            
        </tr>
        </tbody>
  
</table>
</form>
<script>
    var mydate = document.getElementById('dates'),
        mydateError = document.getElementById('mydate_error');

    mydate.addEventListener('input', function() {
        if (!mydate.value.match(/\d{4}-\d{1,2}-\d{1,2}/)) {
            mydateError.innerHTML = 'Please specify a valid date in the form 1990-02-22';
            mydateError.style.display = 'inherit';
        } else {
            var value = new Date(mydate.value),
                min = new Date(mydate.min),
                max = new Date(mydate.max);
            if (value < min || value > max) {
                mydateError.innerHTML = 'Date has to be between ' + min.toDateString() + ' and ' + max.toDateString();
                mydateError.style.display = 'inherit';
            } else {
                mydateError.style.display = 'none';
            }
        }
    });
</script>
<script>
function myFunction() {
  var x = document.getElementById("item");
 // x.value = x.value.toUpperCase();
  var item = $("#item").val();
                    $('#item').addClass('disabled');
                    if(email != ''){
                        $.ajax({
                            url: stagemgr_stageallocation.php',
                            type: 'post',
                            data: {'item':item},
                            success: function(response){
                                // console.log(response);
                                if(response > 0){
                                    $("#item").val('');
                                    $('#item').removeClass('disabled');
                                    $("#eml").html("<p>Email Already taken</p>").fadeIn().delay('1000').fadeOut();
                                }

                            }
                        });

                    }else{
                        $("#eval").hide();
                    }

}
</script>