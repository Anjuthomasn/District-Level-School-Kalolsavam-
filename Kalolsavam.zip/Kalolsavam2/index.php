<?php

include 'connection.php';
session_start();
if (isset($_POST['submit']))
{
   //echo"hai";
   $username=$_POST["username"];   //username value from the form
   $pass=$_POST["psw"];
   $password=md5($_POST["psw"]);
   $un="SELECT `username`,`password` FROM `kalolsavam_tb1_login` WHERE `username`='$username' and status=1 and password='$password' or password='$pass'";
         $r1=mysqli_query($con,$un);
         $row=mysqli_fetch_array($r1);
 $rr1=$row["username"];
 $rr2=$row["password"];
 if ($rr1!=$username && $rr2!=$password )
 {
      echo"<script> alert('Invalid username or password ')
                         window.location.href = 'index.php';</script>";}
 else {
     
//password value from the form
   $sql="select * from kalolsavam_tb1_login where username='$username' and password='$password' or password='$pass'or password='$pass'"; //value querried from the table
         //echo $sql;
   $res=mysqli_query($con,$sql); 
   //query executing function

   if($res)
   {
     if($fetch=mysqli_fetch_array($res)) // role means user , for admin set to 0 and for user set to
     {
      		if($fetch['role']==0 AND $fetch['status']==1)   
		{
			 $_SESSION['l_id']=$fetch['l_id'];
                          $_SESSION['role']=$fetch['role'];// setting username as session variable
                         header("location:adminhome.php");	//home page or the dashboard page to be redirected
            	}

     else if($fetch['role']==1 AND $fetch['status']==1) // role means user , for admin set to 0 and for user set to
     {
       $_SESSION['l_id']=$fetch['l_id'];
        $_SESSION['role']=$fetch['role'];// setting username as session variable
                  header("location:sdhome.php");	//home page or the dashboard page to be redirected
      }

  else if($fetch['role']==2 AND $fetch['status']==1) // role means user , for admin set to 0 and for user set to
     {
       $_SESSION['l_id']=$fetch['l_id'];
        $_SESSION['role']=$fetch['role'];// setting username as session variable
                  header("location:schome.php");	//home page or the dashboard page to be redirected
      }
        else if($fetch['role']==3 AND $fetch['status']==1) // role means user , for admin set to 0 and for user set to
     {
       $_SESSION['l_id']=$fetch['l_id'];	// setting username as session variable
       $_SESSION['role']=$fetch['role'];           
       header("location:stagemgr_stageallocation.php");	//home page or the dashboard page to be redirected
      }
      else if($fetch['role']==4 AND $fetch['status']==1) // role means user , for admin set to 0 and for user set to
     {
       $_SESSION['l_id']=$fetch['l_id'];
       // setting username as session variable
                  header("location:studentprofile.php");	//home page or the dashboard page to be redirected
      }
      
      }
     


      }
	else
	{
             echo"<script>window.alert('Username or password is wrong ');</script>)";
	}
 }
	
}

?>

<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <title>District Level School Kalolsavam</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="" name="keywords">
        <meta content="" name="description">

        <!-- Favicons -->
        <link href="img/logo.png" rel="icon">
        <link href="img/logo.png" rel="apple-touch-icon">

        <!-- Google Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800" rel="stylesheet">

        <!-- Bootstrap CSS File -->
        <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

        <!-- Libraries CSS Files -->
        <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <link href="lib/animate/animate.min.css" rel="stylesheet">
        <link href="lib/venobox/venobox.css" rel="stylesheet">
        <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
<link rel="stylesheet" href="plugins/bootstrap/bootstrap.min.css">
        <!-- Main Stylesheet File -->
        <link href="css/style.css" rel="stylesheet">

        <!-- =======================================================
          Theme Name: TheEvent
          Theme URL: https://bootstrapmade.com/theevent-conference-event-bootstrap-template/
          Author: BootstrapMade.com
          License: https://bootstrapmade.com/license/
        ======================================================= -->
        
       



    </head>

    <body>

        <!--==========================
          Header
        ============================-->
        <header id="header">
            <div class="container">

                <div id="logo" class="pull-left">
                    <!-- Uncomment below if you prefer to use a text logo -->
                    <!-- <h1><a href="#main">C<span>o</span>nf</a></h1>-->
                    <a href="#intro" class="scrollto"><img src="img/logo1.png" alt="" title=""></a>
                </div>

                <nav id="nav-menu-container">
                    <ul class="nav-menu">
                        <li class="menu-active"><a href="#intro">HOME</a></li>
                        <li><a href="#about">ABOUT</a></li>
                        <li><a href="#speakers">MAIN EVENTS</a></li>
                        <li><a href="#schedule">SCHEDULE</a></li>
                        <li><a href="#venue">VENUE</a></li>
                        <li><a href="#gallery">GALLERY</a></li>
                       <li><a href="#contact">CONTACT</a></li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true"> <span class="nav-label">SIGNUP</span> <span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li><a href="sd_signup.php">SUBDISTRICT</a></li>
                                <li><a href="sc_signup.php">SCHOOL</a></li>
                                <li><a href="stage_signup.php">STAGE</a></li>
                                <li><a href="st_signup.php">STUDENT</a></li>


                            </ul>
                        </li>
                        <!-- <li class="buy-tickets"><button onclick="document.getElementById('id01').style.display='block'" style="width:auto;">LOGIN</button></li> -->
                       <li> <a class="text-uppercase text-color p-sm-2 py-2 px-0 d-inline-block" href="#" data-toggle="modal" data-target="#loginModal">login</a> </li>
                    </ul>
                </nav><!-- #nav-menu-container -->
            </div>
        </header><!-- #header -->


<!-- Modal -->
<div class="modal fade" id="loginModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content rounded-0 border-0 p-4">
            <div class="modal-header border-0">
               <center> <h3>LOGIN</h3></center>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form  class="row" method="post">
                    <div class="col-12">
                        <input type="text" class="form-control mb-3" id="loginName" name="username" placeholder="User Name" required>
                    </div>
                    <div class="col-12">
                        <input type="password" class="form-control mb-3" id="loginPassword" name="psw" placeholder="Password" required>
                    </div>
                    <div class="col-12">
                        <button type="submit" name="submit" class="btn btn-primary">LOGIN</button>
                        <a href="mails/forgotpassword.php">Forgotpassword</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


        <!--==========================
          Intro Section
        ============================-->
        <section id="intro">
            <div class="intro-container wow fadeIn">
                <h1 class="mb-4 pb-0">District Level<br><span>School</span> Kalolsavam</h1>
                <p class="mb-4 pb-0">10-19 March, KANJIRAPALLY,KOTTAYAM</p>
                <a href="https://www.youtube.com/watch?v=bNKGtZU4dZY" class="venobox play-btn mb-4" data-vbtype="video"
                   data-autoplay="true"></a>
                <a href="#about" class="about-btn scrollto">About The Event</a>
            </div>
        </section>

        <main id="main">

            <!--==========================
              About Section
            ============================-->
            <section id="about">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6">
                            <h2>About The Event</h2>
                            <p>Kerala School Kalolsavam is a festival unique in its structure and organisation.The organisational set up from school level to state level for the conduct of the Kalolsavam is monitored by Education Department as per the manual drafted by experts in the field. 
                                Looking back into the history of School Kalolsavam in the last 51 years it is seen that the Kalolsavam has refined much in letter and spirit Students get opportunity to express their talent in school level, sub district level, district level and at last at state level.</p>

                        </div>
                        <div class="col-lg-3">
                            <h3>Where</h3>
                            <p>KANJIRAPALLY</p>
                        </div>
                        <div class="col-lg-3">
                            <h3>When</h3>
                            <p>Monday to Wednesday<br>10-19 MARCH</p>
                        </div>
                    </div>
                </div>
            </section>
<br><br><br><br><br><br><br><br><br><br><br><br>
            <!--==========================
              Speakers Section
            ============================-->
            <section id="speakers" class="wow fadeInUp">
                <div class="container">
                    <div class="section-header">
                        <h2>Main Events</h2>
                    </div>

                    <div class="row">
                        <div class="col-lg-4 col-md-6">
                            <div class="speaker">
                                <img src="img/speakers/1.jpg" alt="Speaker 1" class="img-fluid">
                                <div class="details">
                                    <h3><a href="speaker-details.html">KADHAKALI</a></h3>
                                    <div class="social">
                                        <a href=""><i class="fa fa-twitter"></i></a>
                                        <a href=""><i class="fa fa-facebook"></i></a>
                                        <a href=""><i class="fa fa-google-plus"></i></a>
                                        <a href=""><i class="fa fa-linkedin"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6">
                            <div class="speaker">
                                <img src="img/speakers/22.jpg" alt="Speaker 2" class="img-fluid">
                                <div class="details">
                                    <h3><a href="speaker-details.html">Thiruvathira</a></h3>
                                    <div class="social">
                                        <a href=""><i class="fa fa-twitter"></i></a>
                                        <a href=""><i class="fa fa-facebook"></i></a>
                                        <a href=""><i class="fa fa-google-plus"></i></a>
                                        <a href=""><i class="fa fa-linkedin"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6">
                            <div class="speaker">
                                <img src="img/speakers/33.jpg" alt="Speaker 3" class="img-fluid">
                                <div class="details">
                                    <h3><a href="speaker-details.html">MARGAMKALI</a></h3>
                                    <div class="social">
                                        <a href=""><i class="fa fa-twitter"></i></a>
                                        <a href=""><i class="fa fa-facebook"></i></a>
                                        <a href=""><i class="fa fa-google-plus"></i></a>
                                        <a href=""><i class="fa fa-linkedin"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6">
                            <div class="speaker">
                                <img src="img/speakers/44.jpg" alt="Speaker 4" class="img-fluid">
                                <div class="details">
                                    <h3><a href="speaker-details.html">OPPANA</a></h3>
                                   
                                    <div class="social">
                                        <a href=""><i class="fa fa-twitter"></i></a>
                                        <a href=""><i class="fa fa-facebook"></i></a>
                                        <a href=""><i class="fa fa-google-plus"></i></a>
                                        <a href=""><i class="fa fa-linkedin"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6">
                            <div class="speaker">
                                <img src="img/speakers/55.jpg" alt="Speaker 5" class="img-fluid">
                                <div class="details">
                                    <h3><a href="speaker-details.html">KALARIPAYATTE</a></h3>
                                    <div class="social">
                                        <a href=""><i class="fa fa-twitter"></i></a>
                                        <a href=""><i class="fa fa-facebook"></i></a>
                                        <a href=""><i class="fa fa-google-plus"></i></a>
                                        <a href=""><i class="fa fa-linkedin"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6">
                            <div class="speaker">
                                <img src="img/speakers/66.jpg" alt="Speaker 6" class="img-fluid">
                                <div class="details">
                                    <h3><a href="speaker-details.html">MOHINIYATTAM</a></h3>
                                   <div class="social">
                                        <a href=""><i class="fa fa-twitter"></i></a>
                                        <a href=""><i class="fa fa-facebook"></i></a>
                                        <a href=""><i class="fa fa-google-plus"></i></a>
                                        <a href=""><i class="fa fa-linkedin"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </section>

            <!--==========================
              Schedule Section
            ============================-->
            <section id="schedule" class="section-with-bg">
                <div class="container wow fadeInUp">
                    <div class="section-header">
                        <h2>Event Schedule</h2>
                        <p>Here is our event schedule</p>
                    </div>

                    <ul class="nav nav-tabs" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" href="#day-1" role="tab" data-toggle="tab">Day 1</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#day-2" role="tab" data-toggle="tab">Day 2</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#day-3" role="tab" data-toggle="tab">Day 3</a>
                        </li>
                    </ul>

                    <h3 class="sub-heading">Programs appear in different stages</h3>

                    <div class="tab-content row justify-content-center">

                        <!-- Schdule Day 1 -->
                        <div role="tabpanel" class="col-lg-9 tab-pane fade show active" id="day-1">



                            <div class="row schedule-item">
                                <div class="col-md-2"><time>10:00 AM</time></div>
                                <div class="col-md-10">
                                    <div class="speaker">
                                        <img src="img/speakers/1.jpg" alt="Brenden Legros">
                                    </div>
                                    <h4>KADHKALI <span>Boys</span></h4>
                                    <p>Main Stage</p>
                                </div>
                            </div>

                            <div class="row schedule-item">
                                <div class="col-md-2"><time>11:00 AM</time></div>
                                <div class="col-md-10">
                                    <div class="speaker">
                                        <img src="img/speakers/22.jpg" alt="Hubert Hirthe">
                                    </div>
                                    <h4>THIRUBATHIRA <span>Girls</span></h4>
                                </div>
                            </div>

                            <div class="row schedule-item">
                                <div class="col-md-2"><time>12:00 AM</time></div>
                                <div class="col-md-10">
                                    <div class="speaker">
                                        <img src="img/speakers/33.jpg" alt="Cole Emmerich">
                                    </div>
                                    <h4>MARGAMKALI <span>Girls</span></h4>
                                </div>
                            </div>

                            <div class="row schedule-item">
                                <div class="col-md-2"><time>02:00 PM</time></div>
                                <div class="col-md-10">
                                    <div class="speaker">
                                        <img src="img/speakers/44.jpg" alt="Jack Christiansen">
                                    </div>
                                    <h4>OPPANA<span>Boys</span></h4>
                                    <p>Nam ex distinctio voluptatem doloremque suscipit iusto.</p>
                                </div>
                            </div>

                            <div class="row schedule-item">
                                <div class="col-md-2"><time>03:00 PM</time></div>
                                <div class="col-md-10">
                                    <div class="speaker">
                                        <img src="img/speakers/55.jpg" alt="Alejandrin Littel">
                                    </div>
                                    <h4>KALARIPAYATTE <span>Boys</span></h4>
                               </div>
                            </div>

                            <div class="row schedule-item">
                                <div class="col-md-2"><time>04:00 PM</time></div>
                                <div class="col-md-10">
                                    <div class="speaker">
                                        <img src="img/speakers/66.jpg" alt="Willow Trantow">
                                    </div>
                                    <h4>MOHINIYATTAM <span>Girls</span></h4>
                                </div>
                            </div>

                        </div>
                        <!-- End Schdule Day 1 -->

                        <!-- Schdule Day 2 -->
                        <div role="tabpanel" class="col-lg-9  tab-pane fade" id="day-2">

                            

                            <div class="row schedule-item">
                                <div class="col-md-2"><time>10:00 AM</time></div>
                                <div class="col-md-10">
                                    <div class="speaker">
                                        <img src="img/speakers/1.jpg" alt="Brenden Legros">
                                    </div>
                                    <h4>KADHKALI <span>Boys</span></h4>
                                    <p>Main Stage</p>
                                </div>
                            </div>

                            <div class="row schedule-item">
                                <div class="col-md-2"><time>11:00 AM</time></div>
                                <div class="col-md-10">
                                    <div class="speaker">
                                        <img src="img/speakers/22.jpg" alt="Hubert Hirthe">
                                    </div>
                                    <h4>THIRUBATHIRA <span>Girls</span></h4>
                                </div>
                            </div>

                            <div class="row schedule-item">
                                <div class="col-md-2"><time>12:00 AM</time></div>
                                <div class="col-md-10">
                                    <div class="speaker">
                                        <img src="img/speakers/33.jpg" alt="Cole Emmerich">
                                    </div>
                                    <h4>MARGAMKALI <span>Girls</span></h4>
                                </div>
                            </div>

                            <div class="row schedule-item">
                                <div class="col-md-2"><time>02:00 PM</time></div>
                                <div class="col-md-10">
                                    <div class="speaker">
                                        <img src="img/speakers/44.jpg" alt="Jack Christiansen">
                                    </div>
                                    <h4>OPPANA<span>Boys</span></h4>
                                    <p>Nam ex distinctio voluptatem doloremque suscipit iusto.</p>
                                </div>
                            </div>

                            <div class="row schedule-item">
                                <div class="col-md-2"><time>03:00 PM</time></div>
                                <div class="col-md-10">
                                    <div class="speaker">
                                        <img src="img/speakers/55.jpg" alt="Alejandrin Littel">
                                    </div>
                                    <h4>KALARIPAYATTE <span>Boys</span></h4>
                               </div>
                            </div>

                            <div class="row schedule-item">
                                <div class="col-md-2"><time>04:00 PM</time></div>
                                <div class="col-md-10">
                                    <div class="speaker">
                                        <img src="img/speakers/66.jpg" alt="Willow Trantow">
                                    </div>
                                    <h4>MOHINIYATTAM <span>Girls</span></h4>
                                </div>
                            </div>
                        </div>
                        <!-- End Schdule Day 2 -->

                        <!-- Schdule Day 3 -->
                        <div role="tabpanel" class="col-lg-9  tab-pane fade" id="day-3">

                           

                            <div class="row schedule-item">
                                <div class="col-md-2"><time>10:00 AM</time></div>
                                <div class="col-md-10">
                                    <div class="speaker">
                                        <img src="img/speakers/1.jpg" alt="Brenden Legros">
                                    </div>
                                    <h4>KADHKALI <span>Boys</span></h4>
                                    <p>Main Stage</p>
                                </div>
                            </div>

                            <div class="row schedule-item">
                                <div class="col-md-2"><time>11:00 AM</time></div>
                                <div class="col-md-10">
                                    <div class="speaker">
                                        <img src="img/speakers/22.jpg" alt="Hubert Hirthe">
                                    </div>
                                    <h4>THIRUBATHIRA <span>Girls</span></h4>
                                </div>
                            </div>

                            <div class="row schedule-item">
                                <div class="col-md-2"><time>12:00 AM</time></div>
                                <div class="col-md-10">
                                    <div class="speaker">
                                        <img src="img/speakers/33.jpg" alt="Cole Emmerich">
                                    </div>
                                    <h4>MARGAMKALI <span>Girls</span></h4>
                                </div>
                            </div>

                            <div class="row schedule-item">
                                <div class="col-md-2"><time>02:00 PM</time></div>
                                <div class="col-md-10">
                                    <div class="speaker">
                                        <img src="img/speakers/44.jpg" alt="Jack Christiansen">
                                    </div>
                                    <h4>OPPANA<span>Boys</span></h4>
                                    <p>Nam ex distinctio voluptatem doloremque suscipit iusto.</p>
                                </div>
                            </div>

                            <div class="row schedule-item">
                                <div class="col-md-2"><time>03:00 PM</time></div>
                                <div class="col-md-10">
                                    <div class="speaker">
                                        <img src="img/speakers/55.jpg" alt="Alejandrin Littel">
                                    </div>
                                    <h4>KALARIPAYATTE <span>Boys</span></h4>
                               </div>
                            </div>

                            <div class="row schedule-item">
                                <div class="col-md-2"><time>04:00 PM</time></div>
                                <div class="col-md-10">
                                    <div class="speaker">
                                        <img src="img/speakers/66.jpg" alt="Willow Trantow">
                                    </div>
                                    <h4>MOHINIYATTAM <span>Girls</span></h4>
                                </div>
                            </div>

                        </div>
                        <!-- End Schdule Day 2 -->

                    </div>

                </div>

            </section>

            <!--==========================
              Venue Section
            ============================-->
            <section id="venue" class="wow fadeInUp">

                <div class="container-fluid">

                    <div class="section-header">
                        <h2>Event Venue</h2>
                        <p>Event venue location info and gallery</p>
                    </div>

                    <div class="row no-gutters">
                        <div class="col-lg-6 venue-map">
                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d62944.10374388862!2d76.4855728808329!3d9.59470867334748!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3b062ba16c6b435f%3A0xbe2b02f68f8dd06e!2sKottayam%2C+Kerala!5e0!3m2!1sen!2sin!4v1554285958478!5m2!1sen!2sin" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
                           // <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d12097.433213460943!2d-74.0062269!3d40.7101282!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xb89d1fe6bc499443!2sDowntown+Conference+Center!5e0!3m2!1smk!2sbg!4v1539943755621" frameborder="0" style="border:0" allowfullscreen></iframe>
                        </div>

                        <div class="col-lg-6 venue-info">
                            <div class="row justify-content-center">
                                <div class="col-11 col-lg-8">
                                    <h3>Kanjirapalli,Kottayam</h3>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>


            </section>
            <br><br><br><br><br><br><br><br><br>

            <!--==========================
              Gallery Section
            ============================-->
            <section id="gallery" class="wow fadeInUp">

                <div class="container">
                    <div class="section-header">
                        <h2>Gallery</h2>
                        <p>Check our gallery from the recent events</p>
                    </div>
                </div>

                <div class="owl-carousel gallery-carousel">
                    <a href="img/gallery/77.jpg" class="venobox" data-gall="gallery-carousel"><img src="img/gallery/77.jpg" alt=""></a>
                    <a href="img/gallery/22.jpg" class="venobox" data-gall="gallery-carousel"><img src="img/gallery/22.jpg" alt=""></a>
                    <a href="img/gallery/33.jpg" class="venobox" data-gall="gallery-carousel"><img src="img/gallery/33.jpg" alt=""></a>
                    <a href="img/gallery/44.jpg" class="venobox" data-gall="gallery-carousel"><img src="img/gallery/44.jpg" alt=""></a>
                    <a href="img/gallery/55.jpg" class="venobox" data-gall="gallery-carousel"><img src="img/gallery/55.jpg" alt=""></a>
                    <a href="img/gallery/66.jpg" class="venobox" data-gall="gallery-carousel"><img src="img/gallery/66.jpg" alt=""></a>
                    <a href="img/gallery/77.jpg" class="venobox" data-gall="gallery-carousel"><img src="img/gallery/77.jpg" alt=""></a>
                    <a href="img/gallery/88.jpg" class="venobox" data-gall="gallery-carousel"><img src="img/gallery/88.jpg" alt=""></a>
                </div>

            </section>

           
          
            <!--==========================
              Subscribe Section
            ============================-->
            <section id="subscribe">
                <div class="container wow fadeInUp">
                    <div class="section-header">
                        <h2>School kalolsavam</h2>
                        <p></p>
                    </div>

                    <form method="POST" action="#">
                        <div class="form-row justify-content-center">
                            <div class="col-auto">
                                <input type="text" class="form-control" placeholder="Enter your Email">
                            </div>
                            <div class="col-auto">
                                <button type="submit">Subscribe</button>
                            </div>
                        </div>
                    </form>

                </div>
            </section>


            <!--==========================
              Contact Section
            ============================-->
            <section id="contact" class="section-bg wow fadeInUp">

                <div class="container">

                    <div class="section-header">
                        <h2>Contact Us</h2>
                        <p>Subdistrict office,kottayam</p>
                    </div>

                    <div class="row contact-info">

                        <div class="col-md-4">
                            <div class="contact-address">
                                <i class="ion-ios-location-outline"></i>
                                <h3>Address</h3>
                                <address></address>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="contact-phone">
                                <i class="ion-ios-telephone-outline"></i>
                                <h3>Phone Number</h3>
                                <p><a href="tel:+155895548855">+919526194454</a></p>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="contact-email">
                                <i class="ion-ios-email-outline"></i>
                                <h3>Email</h3>
                                <p><a href="mailto:info@example.com">sdschoolkaolsavam@example.com</a></p>
                            </div>
                        </div>

                    </div>

                    <div class="form">
                        <div id="sendmessage">Your message has been sent. Thank you!</div>
                        <div id="errormessage"></div>
                        <form action="" method="post" role="form" class="contactForm">
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                                    <div class="validation"></div>
                                </div>
                                <div class="form-group col-md-6">
                                    <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" data-rule="email" data-msg="Please enter a valid email" />
                                    <div class="validation"></div>
                                </div>
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject" />
                                <div class="validation"></div>
                            </div>
                            <div class="form-group">
                                <textarea class="form-control" name="message" rows="5" data-rule="required" data-msg="Please write something for us" placeholder="Message"></textarea>
                                <div class="validation"></div>
                            </div>
                            <div class="text-center"><button type="submit">Send Message</button></div>
                        </form>
                    </div>

                </div>
            </section><!-- #contact -->

        </main>
                <!-- ##### MODAL ##### -->
<!--         <section id="loginm">        
    <div id="id01" class="modal"> 
	<center> 
        <form class="modal-content animate" method="post"> 
	<div class="imgcontainer"> 
	<span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Login">X</span> 
	</div> 
           
	<div class="container"> 
            <label><b>Username</b></label> <br>
	<input type="text" placeholder="Enter Username" name="username" required> 

        <br><label><b>Password</b></label> 
	<br><input type="password" placeholder="Enter Password" name="psw" required> 
       
        <br>  <button type="submit" name="submit">Login</button> 
	</div> 

	<div class="container" style="background-color:#f1f1f1"> 
	<button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button> 
	<span class="psw">Forgot <a href="#">password?</a></span> 
       </center> </div> 
</form> --> 
</div>


        <!--==========================
          Footer
        ============================-->
        <footer id="footer">
            <div class="footer-top">
                <div class="container">
                    <div class="row">

                        <div class="col-lg-3 col-md-6 footer-info">
                            <img src="img/logo.png" alt="TheEvenet">
                            <p></div>



                        

                    </div>
                </div>
            </div>

            <div class="container">
                <div class="copyright">
                    <strong></strong>
                </div>
                <div class="credits">
                    <!--
                      All the links in the footer should remain intact.
                      You can delete the links only if you purchased the pro version.
                      Licensing information: https://bootstrapmade.com/license/
                      Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=TheEvent
                    -->
                     <a href="https://bootstrapmade.com/"></a>
                </div>
            </div>
        </footer><!-- #footer -->

        <a href="#" class="back-to-top"><i class="fa fa-angle-up"></i></a>

        <!-- JavaScript Libraries -->
        <script src="lib/jquery/jquery.min.js"></script>
        <script src="lib/jquery/jquery-migrate.min.js"></script>
        <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="lib/easing/easing.min.js"></script>
        <script src="lib/superfish/hoverIntent.js"></script>
        <script src="lib/superfish/superfish.min.js"></script>
        <script src="lib/wow/wow.min.js"></script>
        <script src="lib/venobox/venobox.min.js"></script>
        <script src="lib/owlcarousel/owl.carousel.min.js"></script>

        <!-- Contact Form JavaScript File -->
        <script src="contactform/contactform.js"></script>

        <!-- Template Main Javascript File -->
        <script src="js/main.js"></script>
    </body>

</html>
