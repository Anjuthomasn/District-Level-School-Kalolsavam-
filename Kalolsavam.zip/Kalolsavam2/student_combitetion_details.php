<?php
include 'student_header2.php';
include 'connection.php';

$id = $_SESSION['l_id'];
  $dts="PROGRAM REGISTRATION";
   $qry="select * from kalolsavam_tb7_studentinfo where l_id=$id";
     $ans = mysqli_query($con, $qry);
     $r=mysqli_fetch_array($ans);
     $section=$r['section'];
     $gen=$r['gender'];
     $sdid=$r['student_id'];
     $studid=$r['student_id'];
     
     if(isset($_POST['ss']))
    {
           $pgm_id=$_POST['item'];
           
        $file_name = $_FILES['certificate']['name'];
        $file_tmp = $_FILES['certificate']['tmp_name'];
         move_uploaded_file($file_tmp,"uploads/".$file_name);
         $qry2="INSERT INTO `kalolsavam_tb16_comb_details`(`student_id`, `pgm_list_id`, `certificate`, `status`) VALUES ($sdid,$pgm_id,'$file_name',0)";
          $ex = mysqli_query($con, $qry2);
    }
  ?>
 <div class="signup__container">

            <div class="container__child signup__form">

                <form id="search-form"  method="post" enctype="multipart/form-data" name="form1" >



                 
                       
                     <div class="form-group">
                         <br><br>     
                          <select class="form-control" name="item" id="item" >
                           
                              <option value=0 hidden="" >SELECT PROGRAM</option>
        <?php
         $con = mysqli_connect("localhost", "root", "", "kalolsavam");
                                    if (!$con) {
                                        echo "Could not connect..Try again";
                                    } else {
                                        $sdselect = "select * from kalolsavam_tb11_program_list  where section='$section' and gender='$gen'";
                                        $sdresult = mysqli_query($con, $sdselect);
                                        //echo "";
                                        while ($sdrow = mysqli_fetch_array($sdresult)) {
                                            $stname = $sdrow['item'];
                                        
                                            $sid = $sdrow['pgm_list_id'];
                                            echo "<option value='$sid'>$stname </option>";
                                        }
                                    }
                                    mysqli_close($con);
                                    ?>
              </select>
                         <br>
                        <label style="display:none ; color:red"  id="mails"></label>

                   
                               <LABEL>Upload Certificate</LABEL><input type="file" class="form-control"  accept="application/pdf" name="certificate" class="av-image" av-message="addimage" required />  


                           
                               <br>
                    <div class="m-t-lg">
                        <ul class="list-inline">
                            <li>
                                <input type="submit" class="btn btn--form" align="center" name="ss" id="pin" value="Submit your details">


                            </li>

                        </ul>
                    </div>
 </div>

                </form>
           
        </div>
      </div>
       