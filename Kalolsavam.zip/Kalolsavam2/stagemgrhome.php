<?php
include 'stagemgr_header.php';
include 'connection.php';
?>
<?php
include 'student_footer.php';
?> 