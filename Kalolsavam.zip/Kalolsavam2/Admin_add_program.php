
<?php

include 'connection.php';
session_start();
if(!(isset($_SESSION['l_id'])))
{
	header('location:index.php');
}
	
$id=$_SESSION['l_id'];
if(isset($_POST['submit']))
    {
               
        
        $section=strtoupper($_POST['section']);
        $item_code=$_POST['item_code'];
         $item=strtoupper($_POST['item']);
        $gender=strtoupper($_POST['gender']);
        $item_type= $_POST['item_type'];
        $participent=$_POST['participent'];
       
        $timet_limit=$_POST['time_l'];
        $b=$item_code-1;
        $a=$item_code+15;
        
             $tst="select item_code,item from kalolsavam_tb11_program_list where item_code=$item_code";
        $rst=mysqli_query($con,$tst);
         $rows=mysqli_fetch_array($rst);
         $rsts=$rows["item"];
         $rstt=$rows["item_code"];
         // >$b || $rstt<$a
         if(mysqli_num_rows($rst)>=1 && $rstt == $item_code)
         {
            
             echo"<script>alert('Sorry, item code alredy used,use another one');</script>)";
         }
        
          
         
         $un="SELECT * FROM `kalolsavam_tb11_program_list` WHERE `item`='$item' and `gender`='$gender' and section='$section' and category='$item_type'";
         $r1=mysqli_query($con,$un);
         $row=mysqli_fetch_array($r1);
         $rr1=$row["item"];
          $rrr2=$row["section"];
          $rrr3=$row["gender"];
          $rr4=$row["category"];
         if($rr1==$item && $rrr2==$section && $rrr3==$gender)
         {
              echo"<script> alert('Program alredy added ')
                         window.location.href = 'Admin_view_program.php';</script>";

            // echo"<script>alert('Program alredy added');</script>)";
         
             
         }
    
         else {
           $sql1="INSERT INTO `kalolsavam_tb11_program_list`(`section`,`item_code`,`item`,`gender`,`category`,`max_participent`,`time_limit`) VALUES ('$section',$item_code,'$item','$gender','$item_type','$participent','$timet_limit')";
            $result1=mysqli_query($con,$sql1);
       
        
            if($result1)
                    {
                        
                echo"<script> alert('Program Added ')
                         window.location.href = 'Admin_view_program.php';</script>";
                        // echo"<script> alert('Program Added')</script>";
						 
                    }
           

        }
        
      
    }

?>
<!DOCTYPE html>
<html>
	<head>
		<title>School Kalolsavam</title>

		<!-- meta -->
		<meta charset="UTF-8">
	    <meta name="viewport" content="width=device-width, initial-scale=1">

	    <!-- css -->
            <link rel="stylesheet" href="users/css/bootstrap.min_2.css">
            <link rel="stylesheet" href="users/css/ionicons.min.css">
            <link rel="stylesheet" href="users/css/font-awesome.min.css">
            <link rel="stylesheet" href="users/css/owl.carousel.css">
            <link rel="stylesheet" href="users/css/owl.theme.css">
            <link rel="stylesheet" href="users/css/owl.transitions.css">
            <link rel="stylesheet" href="users/css/animate.css">
            <link rel="stylesheet" href="users/css/custom.css">

	    <!-- js -->
            <script src="users/js/jquery.min.js"></script>
            <script src="users/js/bootstrap.min.js"></script>
            <script src="users/js/owl.carousel.min.js"></script>
            <script src="users/js/isotope.pkgd.min.js"></script>
            <script src="users/js/script.js"></script>
            <script src="users/js/wow.min.js"></script>
            <script src="users/js/jquery.actual.min.js"></script>
   
      <link rel="stylesheet" href="css2/s2.css">
      
	</head>

	<body>
        <div id="wrapper">
		
			
				<section id= "navigation">
					<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
	  					<div class="container-fluid">
	    					<div class="navbar-header">
	      						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					        		<span class="ion-navicon"></span>
					      		</button>
					      		<a class="navbar-brand" href="#">School Kalolsavam </a>
					    	</div>
                                                       <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                <ul class="nav navbar-nav navbar-right">
                                    <li><a href="adminhome.php">HOME</a></li>
                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true"> <span class="nav-label">ADD</span> <span class="caret"></span></a>
                                        <ul class="dropdown-menu">
                                            <li><a href="Admin_add_subdistrict.php">ADD SUBDISTRICT</a></li>
                                            <li><a href="Admin_add_program.php">ADD PROGRAM LIST</a></li>
                                            <li> <a href="mails/Admin_add_stagedetails.php">ADD STAGE DETAILS</a></li>



                                        </ul>
                                    </li>

                                   
                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true"> <span class="nav-label">VIEW & UPDATE </span> <span class="caret"></span></a>
                                        <ul class="dropdown-menu">
                                            <li><a href="Admin_view_program.php">PROGRAM LIST</a></li>
                                          


                                        </ul>
                                    </li>

                                     <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true"> <span class="nav-label">CHEST NUMBER</span> <span class="caret"></span></a>
                                    <ul class="dropdown-menu">
                                        <li><a href="Admin_chestnogenerate.php">GENERATE CHEST NUMBER</a></li>
                                        <li><a href="Admin_view_chestno.php">VIEW CHEST NUMBER</a></li>
                                        
                                    



                                    </ul>
                                </li>
                                    
                                    <li><a href="logout.php">LOGOUT</a></li>
                                </ul>
                            </div>

	  					</div>	<!-- container-fluid -->
					</nav>
                                   
                <!-- navbar -->
				</section>	<!-- #navigation -->
			
				<div class="row text-center" id="heading">
					<div class="col-md-6 col-md-offset-3 wow animated zoomInDown" id="heading-text">
						<h3>ADD PROGRAM LIST</h3>
	                	<hr class="full">
	                	<br/>
					</div>

                       
                                
                                
           
                                            </p>
                                            
                                            <br><br>  <br><br>  <br><br>  <br><br>  <br><br>  <br><br>
					</div>

				
                        
                        
                </section><!-- row -->       

<div class="signup__container">
  
  <div class="container__child signup__form">
      <form id="search-form"  method="post" name="myform">
        <div class="form-group">
            <label for="section">Section</label> 
                <br>   <select name="section" id="section" class="form-control" required>
       <option>LP</option>
       <option>UP</option>
       <option>HS</option>
       <option>HSS</option>
   </select>
        
      </div>
        
      <div class="form-group">
        <label for="item code">Item Code</label>
        <input class="form-control" type="number" name="item_code" id="item_code" onChange="code();"  required />
        <label style="display:none ; color:red"  id="code_l"></label>
      </div>
        <div class="form-group">
        <label for="item code">Item</label>
        <input class="form-control" type="text" name="item" id="item" onChange="add();" onkeypress="return onlyAlphabets(event,this);"  required />
        <label style="display:none ; color:red"  id="item_1"></label>
      </div>
          
      <div class="form-group">
        <label for="gender">Gender</label>
        <br>  <br> <input  type="radio" name="gender" id="gender" value="male" required checked onChange=""/>    <label> Male</label>
        <label></label><input  type="radio" name="gender" id="gender" value="female" required onChange=""/> <label> Female</label>
    
      </div>
          <div class="form-group">
        <label for="type">Item Type</label>
        <br><br>   <input  type="radio" name="item_type" id="type" value="Single" required checked onChange=""/>    <label> Single</label>
        <label></label> <input  type="radio" name="item_type" id="gender" value="Group" required onChange=""/> <label> Group</label>
      </div>
          <div class="form-group">
        <label for="participent">Maximum Participent</label>
        <input class="form-control" type="number" name="participent" id="participent" value="1" onChange="code2();"  required />
     <label style="display:none ; color:red"  id="code_2"></label>
          </div>
       

          <div class="form-group">
        <label for="time">Time Limit</label>
        <input class="form-control" type="number" name="time_l" id="time_l" value="5" onChange="code3();"  required />
        <label style="display:none ; color:red"  id="code_3"></label>
      </div>
      <div class="m-t-lg">
        <ul class="list-inline">
          <li>
              <input class="btn btn--form" type="submit" value="Add" id="pin" name="submit" onclick="javascript:validate();"  />
          </li>
         
        </ul>
      </div>
    </form>  
  </div>
 </div>
     <br><br>  <br><br>  <br><br>  <br><br>  <br><br>  <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br>

  
                                

                                            <br><br>  <br><br>  <br><br>  <br><br>  <br><br>  <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br>
		<!-- footer -->
		<section id= "footer" class= "main-footer">
			<div class= "row">
				<div class= "logo text-center">
					<h1>School Kalolsavam</h1>
				</div>
			</div>
			<div class= "row">
				<div class= "copyright text-center">
					</div>
			</div>
		</section><!-- footer -->

		<!-- js -->
		<script>
			$(document).ready(function() {
  				$("#client-speech").owlCarousel({
  					autoPlay: 3000,
      				navigation : false, // Show next and prev buttons
      				slideSpeed : 700,
      				paginationSpeed : 1000,
      				singleItem:true
  				});
			});
                         function onlyAlphabets(e, t) {
            try {
                if (window.event) {
                    var charCode = window.event.keyCode;
                }
                else if (e) {
                    var charCode = e.which;
                }
                else { return true; }
                if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123))
                    return true;
                else
                    return false;
            }
            catch (err) {
                alert(err.Description);
            }
        }
		</script>
		<script>
 			new WOW().init();
		</script>
		<script>
			$( function() {
				  // init Isotope
			  	var $container = $('.isotope').isotope
			  	({
				    itemSelector: '.element-item',
				    layoutMode: 'fitRows'
			  	});


  				// bind filter button click
  				$('#filters').on( 'click', 'button', function() 
  				{
				    var filterValue = $( this ).attr('data-filter');
				    // use filterFn if matches value
				    $container.isotope({ filter: filterValue });
				 });
  
			  // change is-checked class on buttons
			  	$('.button-group').each( function( i, buttonGroup ) 
			  	{
			    	var $buttonGroup = $( buttonGroup );
			    	$buttonGroup.on( 'click', 'button', function() 
			    	{
			      		$buttonGroup.find('.is-checked').removeClass('is-checked');
			      		$( this ).addClass('is-checked');
			    	});
			  	});
			  
			});
		</script>
                <script src="users/js/jquery-ui-1.10.3.min.js"></script>
                <script src="users/js/jquery.knob.js"></script>
                <script src="users/js/daterangepicker.js"></script>
                <script src="users/js/bootstrap3-wysihtml5.all.min.js"></script>
                <script src="users/js/dashboard.js"></script>
                        </div>
            <script>
                function code()
	{
            var val = document.getElementById('item_code').value;
	    if (!val.match(/^[0-9][0-9]{2,2}$/))
	    {
		$("#code_l").html('Only Numbers are allowed and must contain 3 number..!').fadeIn().delay(3000).fadeOut();
		document.getElementById('item_code').value = "";
		item_code.focus();
	        return false;
	    }
	    return true;
            
          
            
	}
               function code2()
	{
            var val = document.getElementById('participent').value;
	    if (!val.match(/^[0-9][0-9]{1,1}$/))
	    {
		$("#code_2").html('Only Numbers are allowed and must contain 2 number..!').fadeIn().delay(3000).fadeOut();
		document.getElementById('participent').value = "";
		participent.focus();
	        return false;
	    }
	    return true;
            
          
            
	}
             function code3()
	{
            var val = document.getElementById('time_l').value;
	    if (!val.match(/^[0-9][0-9]{,1}$/))
	    {
		$("#code_3").html('Only Numbers are allowed and must contain 2 number..!').fadeIn().delay(3000).fadeOut();
		document.getElementById('time_l').value = "";
		time_l.focus();
	        return false;
	    }
	    return true;
            
          
            
	}
               function validate(){
    if (document.getElementById("section").selectedIndex == 0){
       $("#section_l").html('Only Numbers are allowed and must contain 3 number..!').fadeIn().delay(3000).fadeOut();
       
    }
    else {
       alert(document.getElementById("section").options[document.getElementById("section").selectedIndex].value);
    }
}
function add()
            {
                var x = document.getElementById('item').value;


                if ((x === null) || (x.length <= 1))
                {


                    $("#item_1").html('Invalid Item').fadeIn().delay(3000).fadeOut();

                    item.value = "";
                    item.focus();
                    return false;
                }
                var fnam = /^[a-zA-Z ]{4,25}$/;
                if (document.myform.item.value.search(item) == -1)
                {

                    $("#item_1").html('Invalid Item').fadeIn().delay(3000).fadeOut();
                    item.value = "";
                    item.focus();

                    return false;
                }

            }
            </script>
	</body>
</html>
