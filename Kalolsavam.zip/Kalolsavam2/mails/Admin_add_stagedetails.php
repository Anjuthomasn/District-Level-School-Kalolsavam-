
<?php
include 'db.php';
 require 'PHPMailer-master/PHPMailerAutoload.php';
session_start();
if (!(isset($_SESSION['l_id'])) ) {
    header('location:../index.php');
}

$id = $_SESSION['l_id'];


if (isset($_POST['submitss'])) {

    $stagename=strtoupper($_POST['s']);
    $no=$_POST['sno'];
    $mailids=$_POST['mail'];
    $sd = "SELECT `stage_name` FROM `kalolsavam_tb8_stagelist` WHERE `stage_name`='$stagename' or `stage_no`='$no' ";
    $re = mysqli_query($con, $sd);

    $row1 = mysqli_fetch_array($re);
    $rr2 = $row1["stage_name"];
    $rr3 = $row1["stage_no"];
    if ($rr2 == $stagename || $rr2==$no ) {
        echo"<script>alert(' already added  ');</script>)";
    } else {
        $n = 6;
                function generateNumericOTP($n) { 
       $generator = "1357902468"; 
       $result = ""; 
       for ($i = 1; $i <= $n; $i++) { 
           $result .= substr($generator, (rand()%(strlen($generator))), 1); 
       } 
   
       // Return result 
       return $result; 
   }
   // Main program 
  
   $pa=generateNumericOTP($n);
   $p="Your Password is:".$pa;
   $mail = new PHPMailer();
  
  //Enable SMTP debugging.
  $mail->SMTPDebug = 1;
  //Set PHPMailer to use SMTP.
  $mail->isSMTP();
  //Set SMTP host name
  $mail->Host = "smtp.gmail.com";
  $mail->SMTPOptions = array(
                    'ssl' => array(
                        'verify_peer' => false,
                        'verify_peer_name' => false,
                        'allow_self_signed' => true
                    )
                );
  //Set this to true if SMTP host requires authentication to send email
  $mail->SMTPAuth = TRUE;
  //Provide username and password
  $mail->Username = "anjuthomas4454@gmail.com";
  $mail->Password = "pippykochu8713";
  //If SMTP requires TLS encryption then set it
  $mail->SMTPSecure = "tls";
  $mail->Port = 587;
  //Set TCP port to connect to
  
  //$mail->to = "jomiyajohn@mca.ajce.in";
  //$mail->From = "jomiyajohn@mca.ajce.in";
  //$mail->FromName = "noora";
  
$mail->addAddress($mailids);
  
  $mail->isHTML(true);

  $mail->Subject = "Your username and password For login Kalolsavam Site   ";
  $mail->Body = "<i>Username is your email id and this is your Password:</i>".$p;
  $mail->AltBody = "";
  if(!$mail->send())
   {
      echo "<script>alert('Mail not sended Please try again ');window.location='Admin_add_stagedetails.php';</script>";
   //echo "Mailer Error: " . $mail->ErrorInfo;
  }
  else
  {
      $pass=md5($pa);
       $sql="INSERT INTO `kalolsavam_tb1_login`(`username`, `password`, `role`,`status`) VALUES ('$mailids','$pass',3,1) ";
       $r2=mysqli_query($con,$sql);
      echo "<script>alert('Success, Username and Password Send to Stage manager');window.location='Admin_add_stagedetails.php';</script>";
   //echo "Message has been sent successfully";
  }
  if ($r2){
 $l_id= "SELECT `l_id` FROM `kalolsavam_tb1_login` WHERE `username`='$mailids'";
   $result2=mysqli_query($con,$l_id);
            while($n=mysqli_fetch_array($result2))
            {
                
                 $a=$n["l_id"];
                 $sql="INSERT INTO `kalolsavam_tb2_user`(`l_id`,`email`) VALUES($a,'$mailids')";
                 $result3=mysqli_query($con,$sql);
            }
             if($result3)
                    {
                        $sql1 = "INSERT INTO `kalolsavam_tb8_stagelist`(`stage_name`,`stage_no`,sts) VALUES ('$stagename',$no,1)"; 
        $result1 = mysqli_query($con, $sql1);
                    }
               $user_id="SELECT * FROM kalolsavam_tb2_user as usr,kalolsavam_tb8_stagelist as stg WHERE usr.l_id=$a AND stg.stage_name='$stagename'";
            $result4=mysqli_query($con,$user_id);
            while($ids=mysqli_fetch_array($result4))
            {
                $uid=$ids["user_id"];
                $s_id=$ids["stge_id"];
                $insert="INSERT INTO `kalolsavam_tb9_stagemgr_info`(`l_id`,`user_id`,`stge_id`) VALUES($a,$uid,$s_id)";
              
                $result5=mysqli_query($con,$insert);
              //  move_uploaded_file($_FILES["file"]["tmp_name"], $targetFilePath);
              
            }
  }
            

//          
//        if($result1)
//        {
//            
//        echo"<script>alert(' stagelist added  ');</script>)";
//        }
        
    }
}
?>
<!DOCTYPE html>
<html>
    <head>
        <title>School Kalolsavam</title>

        <!-- meta -->
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- css -->
        <link rel="stylesheet" href="../users/css/bootstrap.min_2.css">
        <link rel="stylesheet" href="../users/css/ionicons.min.css">
        <link rel="stylesheet" href="../users/css/font-awesome.min.css">
        <link rel="stylesheet" href="../users/css/owl.carousel.css">
        <link rel="stylesheet" href="../users/css/owl.theme.css">
        <link rel="stylesheet" href="../users/css/owl.transitions.css">
        <link rel="stylesheet" href="../users/css/animate.css">
        <link rel="stylesheet" href="../users/css/custom.css">

        <!-- js -->
        <script src="../users/js/jquery.min.js"></script>
        <script src="../users/js/bootstrap.min.js"></script>
        <script src="../users/js/owl.carousel.min.js"></script>
        <script src="../users/js/isotope.pkgd.min.js"></script>
        <script src="../users/js/script.js"></script>
        <script src="../users/js/wow.min.js"></script>
        <script src="../users/js/jquery.actual.min.js"></script>

        <link rel="stylesheet" href="../css2/s8.css">
        <style>
            table {
                
          background-color: white;
            }
            th,td{
                 font-size: 14px;
                 padding: 0px;
                 font-weight: bold;
                 text-align: center
            }

        </style>
         

    </head>

    <body>
        <div id="wrapper">


            <section id= "navigation">
                <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
                    <div class="container-fluid">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                                <span class="ion-navicon"></span>
                            </button>
                            <a class="navbar-brand" href="#">School Kalolsavam </a>
                        </div>
                       <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                <ul class="nav navbar-nav navbar-right">
                                    <li><a href="../adminhome.php">HOME</a></li>
                                   <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true"> <span class="nav-label">ADD</span> <span class="caret"></span></a>
                                        <ul class="dropdown-menu">
                                            <li><a href="../Admin_add_subdistrict.php">ADD SUBDISTRICT</a></li>
                                            <li><a href="../Admin_add_program.php">ADD PROGRAM LIST</a></li>
                                            <li> <a href="../Admin_add_stagedetails.php">ADD STAGE DETAILS</a></li>



                                        </ul>
                                    </li>

                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true"> <span class="nav-label">BLOCK/UNBLOCK USERS</span> <span class="caret"></span></a>
                                        <ul class="dropdown-menu">
                                            <li><a href="../Admin_view_usersd.php">SUBDISTRICT COORDINATOR</a></li>
                                            <li><a href="../Admin_view_usersc.php">SCHOOL COORDINATOR</a></li>
                                            <li><a href="../Admin_view_userstage.php">STAGE MANAGERS</a></li>



                                        </ul>
                                    </li>
                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true"> <span class="nav-label">VIEW & UPDATE </span> <span class="caret"></span></a>
                                        <ul class="dropdown-menu">
                                            <li><a href="../Admin_view_program.php">PROGRAM LIST</a></li>
                                            <li><a href="../Admin_view_registerprogrram.php">REGISTERD PROGRAMS</a></li>
                                          


                                        </ul>
                                    </li>

                                     <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true"> <span class="nav-label">CHEST NUMBER</span> <span class="caret"></span></a>
                                    <ul class="dropdown-menu">
                                        <li><a href="../Admin_chestnogenerate.php">GENERATE CHEST NUMBER</a></li>
                                        <li><a href="../Admin_view_chestno.php">VIEW CHEST NUMBER</a></li>
                                        
                                    



                                    </ul>
                                </li>
                                    
                                    <li><a href="../logout.php">LOGOUT</a></li>
                                </ul>
                            </div>

                    </div>	<!-- container-fluid -->
                </nav>

                <!-- navbar -->
            </section>	<!-- #navigation -->

            <div class="row text-center" id="heading">
                <div class="col-md-6 col-md-offset-3 wow animated zoomInDown" id="heading-text">
                    <h3>ADD STAGE</h3>
                    <hr class="full">
                    <br/>
                </div>

            </div>




        </section><!-- row -->       


        <br><br><br><br>

        <div class="signup__container">

            <div class="container__child signup__form">

                <form id="search-form"  method="post" name="form1" >



                    <div class="form-group">
                        <br><label>STAGE</label>
                        <input type="text" name="s" id="s" class="form-control" required onChange="add();" onkeypress="return onlyAlphabets(event,this);"/>
                        <label style="display:none ; color:red"  id="aaa"></label>

                    </div>
                    <div class="form-group">
                        <br><label>STAGE NUMBER</label>
                        <input type="number" name="sno" id="sno" class="form-control" required  />
                       
                    </div>
                     <div class="form-group">
                        <br><label>STAGE MANAGER EMAIL</label>
                        <input type="email" name="mail" id="mail" class="form-control" required onChange="ValidateEmail()" />
                        <label style="display:none ; color:red"  id="mails"></label>

                    </div>
                  
<!--                   
                    <div class="form-group">
                        <br><label>year</label>
                         <select name="ss" id="section" class="form-control" required>
                            <option>2019</option>
                            <option>2020</option>
                            <option>2021</option>
                            <option>2021</option>

                        </select>
                        <label style="display:none ; color:red"  id="aaa"></label>

                    </div>-->
                   
                    <div class="m-t-lg">
                        <ul class="list-inline">
                            <li>
                                <input type="submit" class="btn btn--form" align="center" name="submitss" id="pin" value="Add">


                            </li>

                        </ul>
                    </div>


                </form>
            </div>
        </div>
        <?php
        include 'db.php';
        if (isset($_POST['edit'])) {
            $sname=strtoupper($_POST['sname']);
            $times=$_POST['times'];
              $dates=$_POST['dat'];
            
            
            $id = $_POST['sdt'];

            $q = "UPDATE `kalolsavam_tb8_stagelist` SET `stage_name`='$sname' AND `stage_no`='$times'WHERE `stge_id`=$id";
            $query = mysqli_query($con, $q);
        }

//for deletion
        if (isset($_POST['delete'])) {
            $id = $_POST['stge_id'];
            $query = mysqli_query($con, "DELETE FROM `kalolsavam_tb8_stagelist` WHERE `stge_id`=$id");
        }
        ?>
        <center>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
 
            <?php 
            $qs = mysqli_query($con, "select * from kalolsavam_tb8_stagelist");
              if(mysqli_num_rows($qs) < 1)
              {?>
                   <br><br><br><br><br><br><br><br>
                        <label style="color:red;font-size:18px" >STAGE DETAILS NOT ADDED</label>
        <br><br><br><br><br><br><br><br>><br><br><br><br>
      
             <?php }
 else {
            ?>
            <table border="16%"  width="80%" background-color:="white">
                
                <tr>

                    <th >STAGE</th>
                    <th >STAGE NO</th>
                    <th >MAIL ID</th>
                    
                  
                    <th>Update</th>

                    <th>Delete</th>




                </tr>
                <?php
                include 'db.php';
                $querys = mysqli_query($con, "select * from kalolsavam_tb8_stagelist");
                while ($row = mysqli_fetch_array($querys)) {
                    ?><form action="#" method="post">
                        <tr>
                                <label style="display:none ; color:red"  id="aaaa"></label>
                            <td><input class="txt" type="text" name="sname" id="sname" value="<?php echo $row['stage_name']; ?>" required onChange="add2();" onkeypress="return onlyAlphabets(event,this);"/>
                             </td>
                            <td><input class="txt" type="text" name="times" value="<?php echo $row['stage_no']; ?>"></td>
                            
                            
                            <td><input class="txt" type="hidden" name="sdt" hidden value="<?php echo $row['stge_id']; ?>"></td>
                            <td><input type="submit" name="edit" class="btn btn-inverse large" value="UPDATE"></td>
                            <td><input type="submit" name="delete" class="btn btn-inverse large" value="DELETE"></td>


                        </tr></form>
                    <?php
                }
                ?>
            </table>
   <?php
                }
                ?>
        </center>

        <br><br>  <br><br>  <br><br>  <br><br>  <br><br>  <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br>




        <br><br>  <br><br>  <br><br>  <br><br>  <br><br>  <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br>
        <!-- footer -->
        <section id= "footer" class= "main-footer">
            <div class= "row">
                <div class= "logo text-center">
                    <h1>School Kalolsavam</h1>
                </div>
            </div>
            <div class= "row">
                <div class= "copyright text-center">
                </div>
            </div>
        </section><!-- footer -->

        <!-- js -->
        <script>
            $(document).ready(function () {
                $("#client-speech").owlCarousel({
                    autoPlay: 3000,
                    navigation: false, // Show next and prev buttons
                    slideSpeed: 700,
                    paginationSpeed: 1000,
                    singleItem: true
                });
            });
        </script>
        <script>
            new WOW().init();
        </script>
        <script>
            function onlyAlphabets(e, t) {
            try {
                if (window.event) {
                    var charCode = window.event.keyCode;
                }
                else if (e) {
                    var charCode = e.which;
                }
                else { return true; }
                if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123))
                    return true;
                else
                    return false;
            }
            catch (err) {
                alert(err.Description);
            }
        }
            $(function () {
                // init Isotope
                var $container = $('.isotope').isotope
                        ({
                            itemSelector: '.element-item',
                            layoutMode: 'fitRows'
                        });


                // bind filter button click
                $('#filters').on('click', 'button', function ()
                {
                    var filterValue = $(this).attr('data-filter');
                    // use filterFn if matches value
                    $container.isotope({filter: filterValue});
                });

                // change is-checked class on buttons
                $('.button-group').each(function (i, buttonGroup)
                {
                    var $buttonGroup = $(buttonGroup);
                    $buttonGroup.on('click', 'button', function ()
                    {
                        $buttonGroup.find('.is-checked').removeClass('is-checked');
                        $(this).addClass('is-checked');
                    });
                });

            });
        </script>
        <script src="users/js/jquery-ui-1.10.3.min.js"></script>
        <script src="users/js/jquery.knob.js"></script>
        <script src="users/js/daterangepicker.js"></script>
        <script src="users/js/bootstrap3-wysihtml5.all.min.js"></script>
        <script src="users/js/dashboard.js"></script>
    </div>
    <script>
            function add()
            {
                var x = document.getElementById('s').value;


                if ((x === null) || (x.length <= 1))
                {


                    $("#aaa").html('Invalid Stage Name').fadeIn().delay(3000).fadeOut();

                    s.value = "";
                    s.focus();
                    return false;
                }
                var fnam = /^[a-zA-Z ]{4,25}$/;
                if (document.form1.s.value.search(s) == -1)
                {

                    $("#aaa").html('Invalid Stage  Name').fadeIn().delay(3000).fadeOut();
                    s.value = "";
                    s.focus();

                    return false;
                }

            }
             function add2()
            {
                var xx = document.getElementById('sname').value;


                if ((xx === null) || (xx.length <= 1))
                {


                    $("#aaaa").html('Invalid Stage Name').fadeIn().delay(3000).fadeOut();

                    sname.value = "";
                    sname.focus();
                    return false;
                }
                var fnam = /^[a-zA-Z ]{4,25}$/;
                if (document.form1.s.value.search(s) == -1)
                {

                    $("#aaaa").html('Invalid Stage Name').fadeIn().delay(3000).fadeOut();
                    sname.value = "";
                    sname.focus();

                    return false;
                }

            }
            function ValidateEmail(mail) 
{
 if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(myForm.emailAddr.value))
  {
    return (true)
  }
   $("#mails").html('You have entered an invalid email address!').fadeIn().delay(3000).fadeOut();
                    mail.value = "";
                    mail.focus();
    //alert("You have entered an invalid email address!")
    return (false)
}
    </script>

</body>
</html>
