<?php
$con=mysqli_connect("localhost","root","","kalolsavam");
?>