<?php
include 'student_header.php';
include 'connection.php';

$id = $_SESSION['l_id'];
$qry="select * from kalolsavam_tb7_studentinfo where l_id=$id";
     $a = mysqli_query($con, $qry);
     $rest=mysqli_fetch_array($a);
     $sc=$rest['sclist_id'];
     $sections=$rest['section'];
     $gender=$rest['gender'];
     $qtwo="select * from kalolsavam_tb5_schoollist where sclist_id=$sc";
     $qexe= mysqli_query($con, $qtwo);
     $scresult=mysqli_fetch_array($qexe);
     $scl=$scresult['school'];
      $sdids=$scresult['sdt_id'];
      $sub="select * from kalolsavm_tb4_subdistrict where sdt_id=$sdids";
      $subs= mysqli_query($con, $sub);
     $subsst=mysqli_fetch_array($subs);
     $sdist=$subsst['subdistrict'];
     $qmail="select * from kalolsavam_tb2_user where l_id=$id";
     $qm2 = mysqli_query($con, $qmail);
     $qml2=mysqli_fetch_array($qm2);
     $mailid=$qml2['email'];
     $ph=$qml2['phone'];
//     if(isset($_POST['submits']))
//    {
//         $username=$_POST['names'];
//        $studentname=strtoupper($_POST['sname']);
//        $email= $_POST['email'];
//        $phone=$_POST['phone'];
//        $password=$_POST['password1'];
//        $p=md5($password);
//        $subdistrict_id=$_POST['subdistrict'];
//        $school_id=$_POST['school'];
//        $gender=strtoupper($_POST['gender']);
//        $section=$_POST['section'];
//        $aq="UPDATE ";
//    }
    
?>
<div class="signup__container">
     <div class="container__child signup__form">
         <div class="col-md-6">
             <div class="form-group"> 
                 <label>NAME</label>
<input type="text" class="form-control" value="<?php echo $nme; ?>"   />
 </div>
              <div class="form-group">
                                   <label>SECTION</label>
                  <input type="text" class="form-control" value="<?php echo $sections; ?>"   />
   </div>
                 <div class="form-group">
                                      <label>GENDER</label>
                  <input type="text" class="form-control" value="<?php echo $gender; ?>"  />
   </div>
                 <div class="form-group">
                                      <label>MOBILE</label>
                  <input type="text" class="form-control" value="<?php echo $ph; ?>"  />
   </div>
         </div>
         <div class="col-md-6">
              <div class="form-group">
                                   <label>SCHOOL</label>
                  <input type="text" class="form-control" placeholder="<?php echo $scl; ?>"  />
   </div> 
               <div class="form-group">
                                    <label>SECTION</label>
                  <input type="text" class="form-control" placeholder="<?php echo $sdist; ?>"  />
   </div> 
             <div class="form-group">
                                  <label>EMAIL</label>
                 <input type="text" class="form-control" placeholder="<?php echo $mailid; ?>"   />
   </div> 
         <ul class="nav nav-tabs nav-justified" id="myTab" role="tablist">
            <br>
                            <li class="nav-item">
                                <input type="submit" name="submits" value="EDIT PROFILE">
                             </li>
                        </ul>
         </div>
         
     </div>
</div>
<section id="edit"> 

</section>
<?php
include 'student_footer.php';
?>      



