<?php 
include 'student_header2.php';
include 'connection.php';

$id = $_SESSION['l_id'];
$c=$_GET['ids'];
if(isset($_POST['s']))
    { 
    $ct=$_POST['id'];
       $qry="DELETE FROM `kalolsavam_tb12_registerd_program` WHERE pgm_reg_id=$c";
       $qre=mysqli_query($con,$qry);
       if($qre){
           echo"<script> alert('Program registration canceletion successfully completed ')
                         window.location.href = 'student_program_cancelation.php';</script>";
       }
    }
       
   
    
?>
<form method="post" >
    <input type="hidden" name="id" value="<?php $c ?>">
    <br> <center><input type="submit" value="Cancel Program Registration" name="s" style="backgroundcolor:black;color:white;width:200px;height:40px;"></center>
    <br><br><center><a href="student_program_cancelation.php" ><input type="button" value="No, exit Page" name="delete" style="backgroundcolor:black;color:white;width:200px;height:40px;"  ></a></center>
</form>
