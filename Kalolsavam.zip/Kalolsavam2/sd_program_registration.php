

<?php
include 'connection.php';
session_start();
if(!(isset($_SESSION['l_id'])))
{
	header('location:index.php');
}
	
$id=$_SESSION['l_id'];

 $query ="SELECT `subdistrict` FROM `subdistrict_info` WHERE `l_id`='$id' ";
    $r1=mysqli_query($con,$query);
    $row=mysqli_fetch_array($r1);
    $rr1=$row["subdistrict"];
    
   // program registration
    if(isset($_POST['submit']))
    {
        
        $school=$_POST['school'];
        $item=$_POST['item'];
        $section= $_POST['section'];
        $gender=$_POST['gender'];
        $name=strtoupper($_POST['names']);
        $m="SELECT `subdistrict`,`studentname` FROM `program_reg` WHERE `section`='$section' AND `item`='$item' AND `gender`='$gender'";
          $r3=mysqli_query($con,$m);
         $row3=mysqli_fetch_array($r3);
         if(mysqli_num_rows($r3) >=2)
         {
             echo"<script>alert(' 2 student detail enterd for this item..! ');</script>)";
         
         }
 else {
         $rr3=$row["subdistrict"];
         $un="SELECT `item`,`studentname`,`school` FROM `program_reg` WHERE `studentname`='$name' AND `item`='$item' AND `school`='$school'";
         $r1=mysqli_query($con,$un);
         $row=mysqli_fetch_array($r1);
         $rr2=$row["studentname"];
        
         if($rr2==$name)
         {
             echo"<script>alert(' already register..! ');</script>)";
         
             
         }
         
        else {
           $sql1="INSERT INTO `program_reg`(`item`, `section`,`studentname`,`school`,`subdistrict`,`gender`) VALUES ('$item','$section','$name','$school','$rr1','$gender')";
            $result1=mysqli_query($con,$sql1);
       
          
            if($result1)
                    {
                        
                         echo"<script> alert('Registration Successful')
						 window.location.href = 'sd_program_registration.php';</script>";
                    }
           

        }
 }
      
    }

?>
<!DOCTYPE html>
<html>
	<head>
		<title>School Kalolsavam</title>

		<!-- meta -->
		<meta charset="UTF-8">
	    <meta name="viewport" content="width=device-width, initial-scale=1">

	    <!-- css -->
            <link rel="stylesheet" href="users/css/bootstrap.min.css">
            <link rel="stylesheet" href="users/css/ionicons.min.css">
            <link rel="stylesheet" href="users/css/font-awesome.min.css">
            <link rel="stylesheet" href="users/css/owl.carousel.css">
            <link rel="stylesheet" href="users/css/owl.theme.css">
            <link rel="stylesheet" href="users/css/owl.transitions.css">
            <link rel="stylesheet" href="users/css/animate.css">
            <link rel="stylesheet" href="users/css/custom.css">

	    <!-- js -->
            <script src="users/js/jquery.min.js"></script>
            <script src="users/js/bootstrap.min.js"></script>
            <script src="users/js/owl.carousel.min.js"></script>
            <script src="users/js/isotope.pkgd.min.js"></script>
            <script src="users/js/script.js"></script>
            <script src="users/js/wow.min.js"></script>
            <script src="users/js/jquery.actual.min.js"></script>
   
      <link rel="stylesheet" href="css2/style5.css">
	</head>

	<body>
        <div id="wrapper">
		
			
				<section id= "navigation">
					<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
	  					<div class="container-fluid">
	    					<div class="navbar-header">
	      						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					        		<span class="ion-navicon"></span>
					      		</button>
					      		<a class="navbar-brand" href="#">Scholl Kalolsavam </a>
					    	</div>
	    					<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
		      					<ul class="nav navbar-nav navbar-right">
                                                            <li><a href="sdhome.php">HOME</a></li>
                                                           <li><a href="sd_program_registration.php">PROGRAM REGISTRATION </a></li>
                                   
                                    <li><a href="sd_add_school.php">ADD SCHOOL </a></li>
                                    <li><a href="sd_view_regpgm.php">REGISTRED PROGRAMS</a></li>
                                   
                                                            <li><a href="logout.php">LOGOUT</a></li>
							    </ul>
	    					</div>	<!-- collapse navbar-collapse -->
	  					</div>	<!-- container-fluid -->
					</nav>
                                   
                <!-- navbar -->
				</section>	<!-- #navigation -->
			
				<div class="row text-center" id="heading">
					<div class="col-md-6 col-md-offset-3 wow animated zoomInDown" id="heading-text">
						<h3>PROGRAM REGISTRATION</h3>
	                	<hr class="full">
	                	<br/>
					</div>

                       
                                
                                
           
                                            </p>
                                            
                                            <br><br>  <br><br>  <br><br>  <br><br>  <br><br>  <br><br>
					</div>

				
                        
                        
                </section><!-- row -->                       
 

  
<div class="signup__container">
  
  <div class="container__child signup__form">
      <form id="search-form"  method="post" name="myform">
           <div class="form-group">
            <label for="item">ITEM</label> 
                <br>   <select name="item" id="item" class="form-control" required>
                     <?php
         $con = mysqli_connect("localhost", "root", "", "kalolsavam");
                                    if (!$con) {
                                        echo "Could not connect..Try again";
                                    } else {
                                        $sql = "Select list_id,item_name from program_list";
                                        $result = mysqli_query($con, $sql);
                                        echo "<option value =></option>";
                                        while ($row = mysqli_fetch_array($result)) {
                                            $itemname = $row['item_name'];
                                            $listid = $row['list_id'];
                                            echo "<option value='$itemname'>$itemname</option>";
                                        }
                                    }
                                    mysqli_close($con);
                                    ?>
    
   </select>
        
        
      </div>
        <div class="form-group">
            <label for="section">SECTION</label> 
                <br>   <select name="section" id="section" class="form-control" required>
       <option>LP</option>
        <option>UP</option>
         <option>HS</option>
          <option>HSS</option>
  
   </select>
        
        
      </div>
        
          
      <div class="form-group">
        <label for="gender">GENDER</label>
        <br>  <br> <input  type="radio" name="gender" id="gender" value="male" required checked onChange=""/>    <label> Male</label>
        <label></label><input  type="radio" name="gender" id="gender" value="female" required onChange=""/> <label> Female</label>
     
      </div>
         
        <div class="form-group">
        <label for="pinnany">STUDENT NAME/LEADER NAME</label>
        <input class="form-control" type="text" name="names" id="names" onchange="add();"  required />
         <label style="display:none ; color:red"  id="aaa"></label>
      </div>
               <div class="form-group">
            <label for="item">SCHOOL</label> 
                <br>   <select name="school" id="school" class="form-control" required>
                     <?php
         $con = mysqli_connect("localhost", "root", "", "kalolsavam");
                                    if (!$con) {
                                        echo "Could not connect..Try again";
                                    } else {
                                        $sql = "Select schoolname from school_list where subdistrictname='$rr1'";
                                        $result = mysqli_query($con, $sql);
                                        echo "<option value =></option>";
                                        while ($row = mysqli_fetch_array($result)) {
                                            $schoolname = $row['schoolname'];
                                         
                                            echo "<option value='$schoolname'>$schoolname</option>";
                                        }
                                    }
                                    mysqli_close($con);
                                    ?>
    
   </select>
        
        
      </div>
          <br><br>
      <div class="m-t-lg">
        <ul class="list-inline">
          <li>
              <input class="btn btn--form" type="submit" value="Add" id="pin" name="submit" />
          </li>
         
        </ul>
      </div>
    </form>  
  </div>
 </div>
    
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br>
	
                                
                                <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br>
		<!-- footer -->
		<section id= "footer" class= "main-footer">
			<div class= "row">
				<div class= "logo text-center">
					<h1>School Kalolsavam</h1>
				</div>
			</div>
			<div class= "row">
				<div class= "copyright text-center">
					</div>
			</div>
		</section><!-- footer -->

		<!-- js -->
		<script>
			$(document).ready(function() {
  				$("#client-speech").owlCarousel({
  					autoPlay: 3000,
      				navigation : false, // Show next and prev buttons
      				slideSpeed : 700,
      				paginationSpeed : 1000,
      				singleItem:true
  				});
			});
		</script>
		<script>
 			new WOW().init();
		</script>
		<script>
			$( function() {
				  // init Isotope
			  	var $container = $('.isotope').isotope
			  	({
				    itemSelector: '.element-item',
				    layoutMode: 'fitRows'
			  	});


  				// bind filter button click
  				$('#filters').on( 'click', 'button', function() 
  				{
				    var filterValue = $( this ).attr('data-filter');
				    // use filterFn if matches value
				    $container.isotope({ filter: filterValue });
				 });
  
			  // change is-checked class on buttons
			  	$('.button-group').each( function( i, buttonGroup ) 
			  	{
			    	var $buttonGroup = $( buttonGroup );
			    	$buttonGroup.on( 'click', 'button', function() 
			    	{
			      		$buttonGroup.find('.is-checked').removeClass('is-checked');
			      		$( this ).addClass('is-checked');
			    	});
			  	});
			  
			});
		</script>
                <script src="users/js/jquery-ui-1.10.3.min.js"></script>
                <script src="users/js/jquery.knob.js"></script>
                <script src="users/js/daterangepicker.js"></script>
                <script src="users/js/bootstrap3-wysihtml5.all.min.js"></script>
                <script src="users/js/dashboard.js"></script>

                        </div>
                            <script>
                function add()
            {
                var x = document.getElementById('names').value;


                if ((x === null) || (x.length <= 1))
                {


                    $("#aaa").html('Invalid Name').fadeIn().delay(3000).fadeOut();

                    names.value = "";
                    names.focus();
                    return false;
                }
                var fnam = /^[a-zA-Z ]{4,25}$/;
                if (document.myform.names.value.search(names) == -1)
                {

                    $("#aaa").html('Invalid Name').fadeIn().delay(3000).fadeOut();
                    names.value = "";
                    names.focus();

                    return false;
                }

            }
                </script>
             </body>
</html>
