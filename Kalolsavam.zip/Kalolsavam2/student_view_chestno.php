<?php
include 'student_header2.php';
include 'connection.php';
$id = $_SESSION['l_id'];
$a="SELECT * FROM kalolsavam_tb7_studentinfo where l_id=$id";
$aa=mysqli_query($con, $a);
 $aaa=mysqli_fetch_array($aa);
     $studentid=$aaa['student_id'];
     $b="SELECT * FROM kalolsavam_tb12_registerd_program where student_id=$studentid";
$bb=mysqli_query($con, $b);
 $bbb=mysqli_fetch_array($bb);
     $pgm_reg_id=$bbb['pgm_reg_id'];
 $uns = "SELECT chest.*,lists.* FROM kalolsavam_tb13_chestno as chest,kalolsavam_tb12_registerd_program as reg,kalolsavam_tb11_program_list as lists where chest.pgm_reg_id=reg.pgm_reg_id AND reg.student_id='$studentid' AND reg.pgm_list_id=lists.pgm_list_id ";
$cre = mysqli_query($con, $uns);
 $r=mysqli_fetch_array($cre);
     $pgmid=$r['pgm_reg_id'];
?>

 <?php
     if(mysqli_num_rows($cre) < 1)
     {?>
<br><br>  <center> <label style="color:red;font-size:18px" >                 CHEST NUMBER NOT GENERATED</label> </center>
    <?php }
 else {
         
     ?>

<table class="container">
   
	<thead>
		<tr>
			<th><h1>PROGRAM</h1></th>
			<th><h1>CHEST NUMBER</h1></th>
			
			
		</tr>
	</thead>
        <?php
        while ($row = mysqli_fetch_array($cre)) { ?>
	<tbody>
		<tr>
			<td><?php echo $row["item"]; ?></td>
			<td><?php echo $row["chest_no"]; ?></td>
			
			
		</tr>
	
   

    
	</tbody>
        <?php } ?>
</table>
  <?php
 }
 ?>
  



<?php
include 'student_footer.php';
?> 