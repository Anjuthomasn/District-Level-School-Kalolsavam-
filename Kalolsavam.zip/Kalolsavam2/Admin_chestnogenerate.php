<?php
include 'connection.php';
session_start();
if (!(isset($_SESSION['l_id'])) ) {
header('location:index.php');
}

$id = $_SESSION['l_id'];




?>
<!DOCTYPE html>
<html>
    <head>
        <title>School Kalolsavam</title>

        <!-- meta -->
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- css -->
        <link rel="stylesheet" href="users/css/bootstrap.min_2.css">
        <link rel="stylesheet" href="users/css/ionicons.min.css">
        <link rel="stylesheet" href="users/css/font-awesome.min.css">
        <link rel="stylesheet" href="users/css/owl.carousel.css">
        <link rel="stylesheet" href="users/css/owl.theme.css">
        <link rel="stylesheet" href="users/css/owl.transitions.css">
        <link rel="stylesheet" href="users/css/animate.css">
        <link rel="stylesheet" href="users/css/custom.css">

        <!-- js -->
        <script src="users/js/jquery.min.js"></script>
        <script src="users/js/bootstrap.min.js"></script>
        <script src="users/js/owl.carousel.min.js"></script>
        <script src="users/js/isotope.pkgd.min.js"></script>
        <script src="users/js/script.js"></script>
        <script src="users/js/wow.min.js"></script>
        <script src="users/js/jquery.actual.min.js"></script>

        <link rel="stylesheet" href="css2/s6.css">

         <style>
            table {
                
          background-color: white;
            }
            th,td{
                 font-size: 14px;
                 padding: 0px;
                 font-weight: bold;
                 text-align: center
            }

        </style>

    </head>

    <body>
        <div id="wrapper">


            <section id= "navigation">
                <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
                    <div class="container-fluid">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                                <span class="ion-navicon"></span>
                            </button>
                            <a class="navbar-brand" href="#">School Kalolsavam </a>
                        </div>
                       <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                <ul class="nav navbar-nav navbar-right">
                                    <li><a href="adminhome.php">HOME</a></li>
                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true"> <span class="nav-label">ADD</span> <span class="caret"></span></a>
                                        <ul class="dropdown-menu">
                                            <li><a href="Admin_add_subdistrict.php">ADD SUBDISTRICT</a></li>
                                            <li><a href="Admin_add_program.php">ADD PROGRAM LIST</a></li>
                                            <li> <a href="mails/Admin_add_stagedetails.php">ADD STAGE DETAILS</a></li>



                                        </ul>
                                    </li>

                                  
                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true"> <span class="nav-label">VIEW & UPDATE </span> <span class="caret"></span></a>
                                        <ul class="dropdown-menu">
                                            <li><a href="Admin_view_program.php">PROGRAM LIST</a></li>
                                           


                                        </ul>
                                    </li>

                                     <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true"> <span class="nav-label">CHEST NUMBER</span> <span class="caret"></span></a>
                                    <ul class="dropdown-menu">
                                        <li><a href="Admin_chestnogenerate.php">GENERATE CHEST NUMBER</a></li>
                                        <li><a href="Admin_view_chestno.php">VIEW CHEST NUMBER</a></li>
                                        
                                    



                                    </ul>
                                </li>
                                    
                                    <li><a href="logout.php">LOGOUT</a></li>
                                </ul>
                            </div>
	<!-- collapse navbar-collapse -->
                    </div>	<!-- container-fluid -->
                </nav>

                <!-- navbar -->
            </section>	<!-- #navigation -->
            <br><br>
            <div class="row text-center" id="heading">
                <div class="col-md-6 col-md-offset-3 wow animated zoomInDown" id="heading-text">
                    <h3>CREATE CHEST NUMBER</h3>
                    <hr class="full">
                    <br/>
                </div>

            </div>




        </section><!-- row -->       


        <br><br><br><br><br><br>


        

                <form id="search-form"  method="post" name="form1" >

                   <center>
                    <div class="m-t-lg">
                        <ul class="list-inline">
                            <li>
                                <input type="submit" class="btn btn--form" align="center" name="submit" id="pin" value="GENERATE CHEST NUMBER">


                            </li>

                        </ul>
                    </div>
                   </center>


                </form>
            </div>
        </div>
        <br><br><br><br><br><br><br><br><br><br><br><br>
        <center>
        <?php
        if (isset($_POST['submit'])) {


 $uns = "SELECT * FROM `kalolsavam_tb13_chestno`";

$results = mysqli_query($con, $uns);

    if (mysqli_num_rows($results) > 0)
    {
        
                         echo"<script> alert('Alredy generated');</script>";
    }
    else {
 $un = "SELECT l.*,p.* from kalolsavam_tb11_program_list as l,kalolsavam_tb12_registerd_program as p where p.status=1 and l.pgm_list_id=p.pgm_list_id";

 

$result = mysqli_query($con, $un);
    if (mysqli_num_rows($result) > 0) 
    {
       $ct=0;
        while($rowss = mysqli_fetch_array($result))
        {
           $a = $rowss["pgm_reg_id"];
          
           $cts= $rowss["item_code"];
           $lis=$rowss["pgm_list_id"];
            $nnn="SELECT cs.*,pgs.* FROM kalolsavam_tb13_chestno as cs,kalolsavam_tb12_registerd_program as pgs where cs.pgm_reg_id!=pgs.pgm_reg_id AND cs.chest_no=$cts";
             $nnn2=mysqli_query($con,$nnn);
         $nnn3=mysqli_fetch_array($nnn2);
         if (mysqli_num_rows($nnn2) == 0)
         {
             $ct= $rowss["item_code"];
         }
         else {
             $qs="SELECT c.*,ls.*,pg.* FROM kalolsavam_tb13_chestno as c,kalolsavam_tb11_program_list as ls,kalolsavam_tb12_registerd_program as pg where c.pgm_reg_id=pg.pgm_reg_id  AND pg.pgm_list_id='$lis' AND pg.pgm_list_id=ls.pgm_list_id";
             $qst=mysqli_query($con,$qs);
             $num = mysqli_num_rows($qst);
             $counter = 0;
             while ($rno = mysqli_fetch_array($qst)) {
                 if (++$counter == $num) {
                     $ct=$rno["chest_no"]+1;
        // last row
                }
             }
            // $ct= $rowss["item_code"]+1;
             
         }
//Insert Data to chestno table
            $sql1="INSERT INTO `kalolsavam_tb13_chestno`(`pgm_reg_id`,`chest_no`) VALUES ($a,$ct)";
           $result3=mysqli_query($con,$sql1);
//            echo $a;
//          $nn="SELECT c.*,ls.*,pg.* FROM kalolsavam_tb13_chestno as c,kalolsavam_tb11_program_list as ls,kalolsavam_tb12_registerd_program as pg where c.pgm_reg_id=$a AND pg.pgm_reg_id=$a AND pg.pgm_list_id='$lis' AND pg.pgm_list_id=ls.pgm_list_id";
//             $nn2=mysqli_query($con,$nn);
//         $nn3=mysqli_fetch_array($nn2);
//         if (mysqli_num_rows($nn2) == 0)
//         {
//             $ct= $nn3["item_code"];
//         }
//        else {
//     $c=$nn3["chest_no"];
//     $ct=$c+1;
     
 //}
          
       
        }
                   if ($result3) {
                       echo"<script> alert('chest number created successfully')
                         window.location.href = 'Admin_view_chestno.php';</script>";
                } 
        
    


//             else {
//                
//                         echo"<script> alert('error')
//						 </script>";
//            }
    }
    
 
 }
        }
 ?>
 
            </center>
        <br><br><br><br><br><br><br><br><br><br><br><br>


        <br>


        <br><br>  <br><br>  <br><br>  <br><br>  <br><br>  <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br>




        <br><br>  <br><br>  <br><br>  <br><br>  <br><br>  <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br> <br><br>
        <!-- footer -->
        <section id= "footer" class= "main-footer">
            <div class= "row">
                <div class= "logo text-center">
                    <h1>School Kalolsavam</h1>
                </div>
            </div>
            <div class= "row">
                <div class= "copyright text-center">
                </div>
            </div>
        </section><!-- footer -->

        <!-- js -->
        <script>
            $(document).ready(function () {
                $("#client-speech").owlCarousel({
                    autoPlay: 3000,
                    navigation: false, // Show next and prev buttons
                    slideSpeed: 700,
                    paginationSpeed: 1000,
                    singleItem: true
                });
            });
        </script>
        <script>
            new WOW().init();
        </script>
        <script>
            $(function () {
                // init Isotope
                var $container = $('.isotope').isotope
                        ({
                            itemSelector: '.element-item',
                            layoutMode: 'fitRows'
                        });


                // bind filter button click
                $('#filters').on('click', 'button', function ()
                {
                    var filterValue = $(this).attr('data-filter');
                    // use filterFn if matches value
                    $container.isotope({filter: filterValue});
                });

                // change is-checked class on buttons
                $('.button-group').each(function (i, buttonGroup)
                {
                    var $buttonGroup = $(buttonGroup);
                    $buttonGroup.on('click', 'button', function ()
                    {
                        $buttonGroup.find('.is-checked').removeClass('is-checked');
                        $(this).addClass('is-checked');
                    });
                });

            });
        </script>
        <script src="users/js/jquery-ui-1.10.3.min.js"></script>
        <script src="users/js/jquery.knob.js"></script>
        <script src="users/js/daterangepicker.js"></script>
        <script src="users/js/bootstrap3-wysihtml5.all.min.js"></script>
        <script src="users/js/dashboard.js"></script>
    </div>
    <script>
            function add()
            {
                var x = document.getElementById('subdistricts').value;


                if ((x === null) || (x.length <= 1))
                {


                    $("#aaa").html('Invalid Name').fadeIn().delay(3000).fadeOut();

                    subdistricts.value = "";
                    subdistricts.focus();
                    return false;
                }
                var fnam = /^[a-zA-Z ]{4,25}$/;
                if (document.form1.subdistricts.value.search(subdistricts) == -1)
                {

                    $("#aaa").html('Invalid Name').fadeIn().delay(3000).fadeOut();
                    subdistricts.value = "";
                    subdistricts.focus();

                    return false;
                }

            }
    </script>

</body>
</html>
